﻿param([int]$Port = 7788, [string]$Key = '')
# 시스템 트레이 아이콘 + 자체 알림창(카톡 스타일) + 윈도우 알림센터 + 알림음. 서버가 사라지면 스스로 종료.
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @"
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
public class PopupForm : Form {
  [DllImport("gdi32.dll")] static extern IntPtr CreateRoundRectRgn(int a, int b, int c, int d, int e, int f);
  protected override bool ShowWithoutActivation { get { return true; } }
  protected override CreateParams CreateParams { get { CreateParams cp = base.CreateParams; cp.ExStyle |= 0x08000000 | 0x80; return cp; } }
  public void Round(int r) { Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width + 1, Height + 1, r, r)); }
}
"@
[System.Windows.Forms.Application]::EnableVisualStyles()
$base = "http://127.0.0.1:$Port"
$script:fails = 0
$script:url = $base
$script:paused = $false
$script:popups = New-Object System.Collections.ArrayList
$script:player = $null

# ── 절전 방지 (SetThreadExecutionState). UI 스레드에서 호출해야 유지됨 → 상태 갱신 타이머에서 적용 ──
Add-Type -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);' -Name Pwr -Namespace AcWin
$script:ka = ''
function Set-KeepAwake([string]$mode) {
  if ($mode -eq $script:ka) { return }
  $script:ka = $mode
  # ES_CONTINUOUS=2147483648, +ES_SYSTEM_REQUIRED(1), +ES_DISPLAY_REQUIRED(2)
  $flags = switch ($mode) { 'system' { [uint32]2147483649 } 'display' { [uint32]2147483651 } default { [uint32]2147483648 } }
  $prev = [AcWin.Pwr]::SetThreadExecutionState($flags)
  try { Add-Content -Path $script:logFile -Value ((Get-Date -Format 's') + ' keepAwake=' + $mode + ' applied=' + ($prev -ne 0)) -Encoding UTF8 } catch {}
}

function New-DotIcon([string]$hex) {
  $bmp = New-Object System.Drawing.Bitmap 32, 32
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = 'AntiAlias'
  $g.Clear([System.Drawing.Color]::Transparent)
  $g.FillEllipse((New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#2b2150'))), 1, 1, 30, 30)
  $g.FillEllipse((New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml($hex))), 7, 7, 18, 18)
  $g.Dispose()
  return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
}
$icons = @{ ok = New-DotIcon '#22c55e'; warn = New-DotIcon '#f59e0b'; bad = New-DotIcon '#ef4444'; off = New-DotIcon '#9ca3af' }

function Call([string]$path) {
  # 한글 깨짐 방지: 응답 바이트를 직접 UTF-8로 해석(PowerShell 5.1 기본 해석은 환경에 따라 달라짐)
  try {
    $r = Invoke-WebRequest -Uri "$base$path" -UseBasicParsing -TimeoutSec 4
    $txt = [System.Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
    if ([string]::IsNullOrWhiteSpace($txt)) { return $null }
    return ($txt | ConvertFrom-Json)
  } catch { return $null }
}

$appScript = Join-Path $PSScriptRoot 'desktop.pyw'
$script:logFile = Join-Path $PSScriptRoot 'data\tray.log'
function Open-App {
  $pw = (Get-Command pythonw.exe -ErrorAction SilentlyContinue).Source
  if ($pw -and (Test-Path $appScript)) { Start-Process $pw -ArgumentList "`"$appScript`"" } else { Start-Process $script:url }
}

# ── 알림음 ──
$soundFiles = @{
  default = 'C:\Windows\Media\Windows Notify System Generic.wav'
  soft    = 'C:\Windows\Media\Windows Notify Messaging.wav'
  alert   = 'C:\Windows\Media\Windows Exclamation.wav'
}
function Play-Sound([string]$name) {
  if (-not $name -or $name -eq 'none') { return }
  try {
    $f = $soundFiles[$name]
    if ($f -and (Test-Path $f)) { $script:player = New-Object System.Media.SoundPlayer $f; $script:player.Play() }
    else { [System.Media.SystemSounds]::Asterisk.Play() }
  } catch {}
}

# ── 윈도우 알림센터(토스트). 소리는 위에서 따로 재생하므로 토스트는 무음 ──
$ni = New-Object System.Windows.Forms.NotifyIcon
$ni.Icon = $icons.off
$ni.Text = '경제교실 오토'
$ni.Visible = $true
function Show-Toast([string]$title, [string]$body) {
  try {
    [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
    [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
    $t = [System.Security.SecurityElement]::Escape($title); $b = [System.Security.SecurityElement]::Escape($body)
    $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $xml.LoadXml("<toast><visual><binding template='ToastGeneric'><text>$t</text><text>$b</text></binding></visual><audio silent='true'/></toast>")
    $toast = New-Object Windows.UI.Notifications.ToastNotification $xml
    [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe').Show($toast)
  } catch {
    try { $ni.ShowBalloonTip(8000, $title, $body, [System.Windows.Forms.ToolTipIcon]::Info) } catch {}
  }
}

# ── 자체 알림창(화면 오른쪽 아래, 포커스를 뺏지 않음) ──
# 색 이모지는 알림창에서 깨져 보일 수 있어, 어디서나 같게 보이는 기본 기호(Segoe UI Symbol)를 사용
$emoji = @{ login_lost = [string][char]0x26A0; error = [string][char]0x26A0; job = [string][char]0x2611; matured = [string][char]0x20A9; order = [string][char]0x21C4; advice = [string][char]0x2726; site_changed = [string][char]0x21BB; store = [string][char]0x2666; action = [string][char]0x26A1; system = [string][char]0x2699 }
function Layout-Popups {
  $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
  $n = $script:popups.Count
  for ($i = 0; $i -lt $n; $i++) {
    $f = $script:popups[$i]
    $f.Location = New-Object System.Drawing.Point(($wa.Right - $f.Width - 16), ($wa.Bottom - 16 - ($n - $i) * ($f.Height + 10) + 10))
  }
}
function Close-Popup($f) {
  try { $script:popups.Remove($f); $f.Close(); $f.Dispose() } catch {}
  Layout-Popups
}
function Show-Popup($n) {
  while ($script:popups.Count -ge 4) { Close-Popup $script:popups[0] }
  $f = New-Object PopupForm
  $f.FormBorderStyle = 'None'; $f.StartPosition = 'Manual'; $f.TopMost = $true; $f.ShowInTaskbar = $false
  $f.Size = New-Object System.Drawing.Size(372, 96)
  $f.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#1e1a3a')
  $accent = if ($n.urgent) { '#ef4444' } elseif ($n.event -eq 'job') { '#f59e0b' } else { '#8e6dff' }
  $bar = New-Object System.Windows.Forms.Panel
  $bar.Size = New-Object System.Drawing.Size(6, 96); $bar.Location = New-Object System.Drawing.Point(0, 0)
  $bar.BackColor = [System.Drawing.ColorTranslator]::FromHtml($accent)
  $ic = New-Object System.Windows.Forms.Label
  $ic.Text = $(if ($emoji[$n.event]) { $emoji[$n.event] } else { [string][char]0x2605 }); $ic.Font = New-Object System.Drawing.Font('Segoe UI Symbol', 20)
  $ic.ForeColor = [System.Drawing.Color]::White; $ic.Location = New-Object System.Drawing.Point(16, 22); $ic.Size = New-Object System.Drawing.Size(44, 44)
  $t = New-Object System.Windows.Forms.Label
  $t.Text = [string]$n.title; $t.Font = New-Object System.Drawing.Font('Malgun Gothic', 10.5, [System.Drawing.FontStyle]::Bold)
  $t.ForeColor = [System.Drawing.Color]::White; $t.Location = New-Object System.Drawing.Point(64, 12); $t.Size = New-Object System.Drawing.Size(274, 22); $t.AutoEllipsis = $true
  $b = New-Object System.Windows.Forms.Label
  $b.Text = [string]$n.body; $b.Font = New-Object System.Drawing.Font('Malgun Gothic', 9)
  $b.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#c9c4e6'); $b.Location = New-Object System.Drawing.Point(64, 36); $b.Size = New-Object System.Drawing.Size(296, 52); $b.AutoEllipsis = $true
  $x = New-Object System.Windows.Forms.Label
  $x.Text = '✕'; $x.Font = New-Object System.Drawing.Font('Segoe UI', 9); $x.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#8e89b2')
  $x.Location = New-Object System.Drawing.Point(348, 6); $x.Size = New-Object System.Drawing.Size(18, 18); $x.Cursor = [System.Windows.Forms.Cursors]::Hand
  foreach ($c in @($bar, $ic, $t, $b, $x)) { $f.Controls.Add($c) }
  $x.add_Click({ Close-Popup $this.Parent }.GetNewClosure())
  $open = { Open-App; Close-Popup $this.FindForm() }.GetNewClosure()
  foreach ($c in @($f, $ic, $t, $b)) { $c.add_Click($open); $c.Cursor = [System.Windows.Forms.Cursors]::Hand }
  $life = if ($n.urgent) { 15000 } else { 9000 }
  $tm = New-Object System.Windows.Forms.Timer; $tm.Interval = $life
  $tm.add_Tick({ $this.Stop(); Close-Popup $f }.GetNewClosure())
  $f.Round(18)
  [void]$script:popups.Add($f)
  Layout-Popups
  $f.Show()
  $tm.Start()
}

# ── 메뉴 ──
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miApp = $menu.Items.Add('앱 창 열기')
$miOpen = $menu.Items.Add('브라우저로 열기')
$miPause = $menu.Items.Add('일시정지')
$miRefresh = $menu.Items.Add('지금 확인')
$miLogin = $menu.Items.Add('로그인 창 열기')
$null = $menu.Items.Add('-')
$miQuit = $menu.Items.Add('종료')
$ni.ContextMenuStrip = $menu
$miApp.add_Click({ Open-App })
$miOpen.add_Click({ Start-Process $script:url })
$ni.add_DoubleClick({ Open-App })
$miPause.add_Click({ if ($script:paused) { $null = Call "/tray/cmd?k=$Key&c=resume" } else { $null = Call "/tray/cmd?k=$Key&c=pause" } })
$miRefresh.add_Click({ $null = Call "/tray/cmd?k=$Key&c=refresh" })
$miLogin.add_Click({ $null = Call "/tray/cmd?k=$Key&c=login" })
$miQuit.add_Click({
  $null = Call "/tray/cmd?k=$Key&c=quit"
  $ni.Visible = $false; $ni.Dispose(); [System.Windows.Forms.Application]::Exit()
})

# ── 상태 갱신(5초) ──
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 5000
$timer.add_Tick({
  $s = Call "/tray/status?k=$Key"
  if (-not $s) {
    $script:fails++
    $ni.Icon = $icons.off; $ni.Text = '경제교실 오토 - 연결 끊김'
    if ($script:fails -ge 6) { $ni.Visible = $false; $ni.Dispose(); [System.Windows.Forms.Application]::Exit() }
    return
  }
  $script:fails = 0
  $script:url = $s.url
  $script:paused = [bool]$s.paused
  Set-KeepAwake ([string]$s.keepAwake)
  $miPause.Text = $(if ($script:paused) { '재개' } else { '일시정지' })
  $label = switch ($s.state) { 'ok' { '정상' } 'paused' { '일시정지' } 'logged_out' { '로그아웃됨' } 'error' { '오류' } 'safe_mode' { '안전모드' } default { $s.state } }
  $ico = switch ($s.state) { 'ok' { 'ok' } 'paused' { 'warn' } 'starting' { 'warn' } default { 'bad' } }
  $ni.Icon = $icons[$ico]
  $cash = if ($null -ne $s.cash) { ' · ' + ([int]$s.cash).ToString('N0') + '원' } else { '' }
  $t = "경제교실 오토 - $label$cash"
  $ni.Text = $t.Substring(0, [Math]::Min(63, $t.Length))
})
$timer.Start()

# ── 알림 수신(1.5초): 서버 대기열에서 가져와 창·알림센터·소리로 표시 ──
$ptimer = New-Object System.Windows.Forms.Timer
$ptimer.Interval = 700
$ptimer.add_Tick({
  $items = Call "/tray/popups?k=$Key"
  if (-not $items) { return }
  foreach ($n in @($items)) {
    try {
      if ($n.system) { Show-Toast ([string]$n.title) ([string]$n.body) }
      if ($n.popup) { Show-Popup $n }
      Play-Sound ([string]$n.sound)
      Add-Content -Path $script:logFile -Value ((Get-Date -Format 's') + ' shown event=' + $n.event + ' popup=' + $n.popup + ' system=' + $n.system + ' sound=' + $n.sound) -Encoding UTF8
    } catch {
      try { Add-Content -Path $script:logFile -Value ((Get-Date -Format 's') + ' ' + $_.Exception.Message + ' @' + $_.InvocationInfo.ScriptLineNumber) -Encoding UTF8 } catch {}
    }
  }
})
$ptimer.Start()
# 첫 알림이 느려지지 않게 미리 준비(윈도우 알림 API·알림창 글꼴 로드)
try { [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null; [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null } catch {}
try { $warm = New-Object PopupForm; $f0 = New-Object System.Drawing.Font('Segoe UI Symbol', 20); $f1 = New-Object System.Drawing.Font('Malgun Gothic', 10.5, [System.Drawing.FontStyle]::Bold); $warm.Dispose() } catch {}
[System.Windows.Forms.Application]::Run()
