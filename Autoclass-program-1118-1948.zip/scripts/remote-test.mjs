// 휴대폰(원격) 접속 보안 시험. 프로그램이 켜진 상태에서:  node scripts/remote-test.mjs
import http from 'node:http';
import fs from 'node:fs';
const TOKEN = fs.readFileSync(new URL('../data/token', import.meta.url), 'utf8').trim();
const req = (path, { method = 'GET', host = '127.0.0.1:7788', headers = {}, body } = {}) => new Promise((resolve, reject) => {
  const r = http.request({ host: '127.0.0.1', port: 7788, path, method, headers: { host, ...headers, ...(body ? { 'content-type': 'application/json' } : {}) } }, (res) => {
    let t = ''; res.on('data', (c) => (t += c)); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: t }));
  });
  r.on('error', reject); if (body) r.write(JSON.stringify(body)); r.end();
});
const local = (p, o = {}) => req(p, { ...o, headers: { 'x-token': TOKEN, ...(o.headers || {}) } });
const REMOTE = 'app.example.com';
const ok = (c, m) => console.log((c ? 'PASS ' : 'FAIL ') + m);

// 0) 원래 설정 기억 후 켜기
const before = JSON.parse((await local('/api/state')).text).cfg.remote;
let r = await req('/', { host: REMOTE }); ok(r.status === 401, `원격 + 접속 꺼짐 → 401 (실제 ${r.status})`);
await local('/api/config', { method: 'POST', body: { remote: { enabled: true } } });
r = await req('/', { host: REMOTE }); ok(r.status === 401 && /링크/.test(r.text), `원격 + 켜짐 + 링크 없음 → 401 안내 (실제 ${r.status})`);
const link = JSON.parse((await local('/api/remote/link', { method: 'POST', body: {} })).text);
ok(link.ok && /^\/m\/[\w-]{20,}$/.test(link.path), `링크 생성 ${link.path.slice(0, 12)}…`);
r = await req('/m/' + 'x'.repeat(32), { host: REMOTE }); ok(r.status === 401, `틀린 링크 → 401 (실제 ${r.status})`);
r = await req(link.path, { host: REMOTE }); ok(r.status === 302 && /ac_s=/.test(r.headers['set-cookie']?.[0] || ''), `맞는 링크 → 302 + 쿠키 (실제 ${r.status})`);
const cookie = (r.headers['set-cookie']?.[0] || '').split(';')[0];
ok(/HttpOnly/.test(r.headers['set-cookie']?.[0] || '') && /SameSite=Lax/.test(r.headers['set-cookie']?.[0] || ''), '쿠키 HttpOnly + SameSite');
r = await req('/', { host: REMOTE, headers: { cookie } }); ok(r.status === 200 && /manifest/.test(r.text), `쿠키로 화면 열기 → 200 (실제 ${r.status})`);
r = await req('/api/state', { host: REMOTE, headers: { cookie } }); ok(r.status === 401, `쿠키만으로 API → 401 (화면의 토큰 필요) (실제 ${r.status})`);
const tok = (await req('/', { host: REMOTE, headers: { cookie } })).text.match(/__TOKEN__='([a-f0-9]+)'/)?.[1];
r = await req('/api/state', { host: REMOTE, headers: { cookie, 'x-token': tok } }); ok(r.status === 200 && JSON.parse(r.text).cfg, `쿠키 + 화면 토큰으로 API → 200 (실제 ${r.status})`);
r = await req('/api/remote/link', { method: 'POST', host: REMOTE, headers: { cookie, 'x-token': tok }, body: {} }); ok(r.status === 403, `원격에서 링크 재발급 시도 → 403 (실제 ${r.status})`);
r = await req('/', { headers: { 'x-forwarded-for': '1.2.3.4' } }); ok(r.status === 401, `프록시 헤더(x-forwarded-for)가 붙은 요청은 원격 취급 → 인증 필요 (실제 ${r.status})`);
r = await req('/api/state', { headers: { 'x-token': TOKEN } }); ok(r.status === 200, `이 PC에서 직접 → 링크 없이 정상 (실제 ${r.status})`);
r = await req('/manifest.webmanifest', { host: REMOTE }); ok(r.status === 200, `원격에서도 앱 설치 파일(manifest)은 인증 없이 → 200 (실제 ${r.status})`);
// 무작위 대입 차단
let last; for (let i = 0; i < 12; i++) last = await req('/m/' + String(i).repeat(30), { host: REMOTE }); ok(last.status === 429, `틀린 링크 반복 → 429 차단 (실제 ${last.status})`);
// 복원
await local('/api/remote/revoke', { method: 'POST', body: {} });
await local('/api/config', { method: 'POST', body: { remote: { enabled: !!before?.enabled } } });
r = await req(link.path, { host: REMOTE, headers: { 'x-forwarded-for': '9.9.9.9' } }); ok(r.status === 401, `폐기 후 이전 링크 → 401 (실제 ${r.status})`);
console.log('복원: remote.enabled =', JSON.parse((await local('/api/state')).text).cfg.remote.enabled);
