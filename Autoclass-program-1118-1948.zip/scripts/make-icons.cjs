// 앱 아이콘(PNG) 생성기: 보라색 그라데이션 + 흰색 ₩ 모양. node scripts/make-icons.cjs
const fs = require('fs');
const zlib = require('zlib');
const path = require('path');

function crc32(buf) { let c, crc = ~0; for (let n = 0; n < buf.length; n++) { c = (crc ^ buf[n]) & 0xff; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1; crc = (crc >>> 8) ^ c; } return ~crc >>> 0; }
function chunk(type, data) { const len = Buffer.alloc(4); len.writeUInt32BE(data.length); const td = Buffer.concat([Buffer.from(type), data]); const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td)); return Buffer.concat([len, td, crc]); }
function png(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) { raw[y * (w * 4 + 1)] = 0; rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}
const distSeg = (px, py, ax, ay, bx, by) => { const dx = bx - ax, dy = by - ay, t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy))); return Math.hypot(px - (ax + t * dx), py - (ay + t * dy)); };
const sm = (e0, e1, x) => { const t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); };

// ₩ 글리프: W 모양 + 가로 막대 두 개 (0~1 좌표)
const W = [[0.24, 0.28, 0.37, 0.70], [0.37, 0.70, 0.50, 0.40], [0.50, 0.40, 0.63, 0.70], [0.63, 0.70, 0.76, 0.28]];
const BARS = [[0.18, 0.46, 0.82, 0.46], [0.18, 0.575, 0.82, 0.575]];

function render(size, { maskable = false, rounded = true } = {}) {
  const buf = Buffer.alloc(size * size * 4);
  const scale = maskable ? 0.74 : 1, off = (1 - scale) / 2;        // maskable 은 안전영역 안에 그림
  const stroke = 0.034 * scale, r = 0.22;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const u = (x + 0.5) / size, v = (y + 0.5) / size;
    // 배경: 둥근 사각형 + 대각선 그라데이션
    let a = 1;
    if (rounded && !maskable) { const cx = Math.min(Math.max(u, r), 1 - r), cy = Math.min(Math.max(v, r), 1 - r); a = 1 - sm(r - 0.004, r + 0.004, Math.hypot(u - cx, v - cy)); }
    const g = (u + v) / 2;
    let R = 91 + (142 - 91) * g, G = 63 + (109 - 63) * g, B = 224 + (255 - 224) * g;
    // 글리프(흰색)
    const gx = (u - off) / scale, gy = (v - off) / scale;
    let d = 9;
    for (const [ax, ay, bx, by] of W) d = Math.min(d, distSeg(gx, gy, ax, ay, bx, by));
    for (const [ax, ay, bx, by] of BARS) d = Math.min(d, distSeg(gx, gy, ax, ay, bx, by));
    const ink = 1 - sm(stroke / scale - 0.006, stroke / scale + 0.006, d);
    R = R + (255 - R) * ink; G = G + (255 - G) * ink; B = B + (255 - B) * ink;
    const i = (y * size + x) * 4; buf[i] = R; buf[i + 1] = G; buf[i + 2] = B; buf[i + 3] = Math.round(a * 255);
  }
  return png(size, size, buf);
}
const out = path.join(__dirname, '..', 'ui', 'icons'); fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'icon-192.png'), render(192));
fs.writeFileSync(path.join(out, 'icon-512.png'), render(512));
fs.writeFileSync(path.join(out, 'maskable-512.png'), render(512, { maskable: true }));
fs.writeFileSync(path.join(out, 'apple-touch-icon.png'), render(180, { rounded: false }));
console.log('icons written');
