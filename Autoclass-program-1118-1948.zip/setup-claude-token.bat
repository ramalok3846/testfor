@echo off
rem One-time setup: long-lived Claude token so the AI login does not expire every day.
rem NOTE: "claude" is a .cmd file, so it MUST be started with CALL, otherwise this script ends right after it.
setlocal
echo.
echo  [1/2] A browser opens. Approve the login there.
echo        A long token (starts with sk-ant-oat01-) is printed. Copy it.
echo.
call claude setup-token
echo.
echo  ------------------------------------------------------------
set "TOKEN="
set /p "TOKEN= [2/2] Paste the token here and press Enter: "
if not defined TOKEN (
  echo  No token entered. Nothing was changed.
  pause
  exit /b 1
)
setx CLAUDE_CODE_OAUTH_TOKEN "%TOKEN%" >nul
if errorlevel 1 (
  echo  Failed to save the token.
  pause
  exit /b 1
)
echo.
echo  Saved to your Windows user environment (this PC only).
echo  Now restart the program: run stop.bat, then start-hidden.vbs (or sign out and in).
echo.
pause
