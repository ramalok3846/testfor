@echo off
start "" pythonw "%~dp0desktop.pyw"
