"""경제교실 오토 - 데스크톱 창 (pywebview).
로컬호스트 대시보드와 같은 UI를 네이티브 창으로 보여준다. 서버가 안 떠 있으면 먼저 띄운다.
"""
import os
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
URL = "http://127.0.0.1:7788"


def server_up() -> bool:
    try:
        urllib.request.urlopen(URL + "/", timeout=2).read(10)
        return True
    except Exception:
        return False


def ensure_server() -> bool:
    if server_up():
        return True
    subprocess.Popen(
        ["wscript.exe", os.path.join(HERE, "start-hidden.vbs")],
        creationflags=0x08000000,  # CREATE_NO_WINDOW
    )
    for _ in range(40):
        time.sleep(1)
        if server_up():
            return True
    return False


def main() -> None:
    if not ensure_server():
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, "서버를 시작하지 못했습니다. data\\console.log 를 확인하세요.", "경제교실 오토", 0x10)
        sys.exit(1)
    try:
        import webview
    except ImportError:
        os.startfile(URL)  # pywebview 없으면 브라우저로 대체
        return
    webview.create_window(
        "경제교실 오토", URL, width=1320, height=860, min_size=(980, 640), text_select=True
    )
    webview.start(private_mode=False, storage_path=os.path.join(HERE, "data", "webview"))


if __name__ == "__main__":
    main()
