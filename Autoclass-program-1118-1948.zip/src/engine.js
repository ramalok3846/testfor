import { spawn } from 'node:child_process';
import { state, touch, log } from './store.js';
import { AuthError } from './session.js';
import { unitPrice, planDeposits, planStocks, botPositions, botPositionsLedger, quotePrice } from './strategy.js';
import { fingerprint, diff, schemaProblems } from './watcher.js';
import { think, buildContext, validate } from './ai.js';
import { runSelfTest } from './selftest.js';
import { runAnalysis } from './analysis.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };

export class Engine {
  constructor({ getCfg, session, api, notify }) {
    Object.assign(this, { getCfg, session, api, notify });
    this.snap = null;
    this.ai = null; this.aiBusy = false; this.aiActions = [];
    this.job = null; this.feeCheck = null;
    this.reg = null; this.regBusy = false; this.startedAt = Date.now();
    this.analysis = state.analysis || null; this.analysisBusy = false;
    this.status = { state: 'starting', detail: '', lastOk: null, lastTick: null, errors: 0 };
    this.running = false;
    this.loginInFlight = false;
    this.wake = null;
    this.stopped = false;
  }

  setStatus(s, detail = '') { this.status = { ...this.status, state: s, detail, lastTick: new Date().toISOString() }; }

  async loop() {
    while (!this.stopped) {
      try { await this.tick(); }
      catch (e) { this.onError(e); }
      // 거래 창이 열려 있는 동안은 더 자주 확인(창이 10분처럼 짧을 수 있음)
      const base = (this.snap?.rt?.open ? Math.min(this.getCfg().pollSeconds, 20) : this.getCfg().pollSeconds) * 1000;
      const wait = this.status.errors ? Math.min(base * 2 ** Math.min(this.status.errors, 5), 15 * 60_000) : base;
      await Promise.race([sleep(wait), new Promise((r) => (this.wake = r))]);
    }
  }
  poke() { this.wake?.(); }

  onError(e) {
    if (e instanceof AuthError) {
      this.setStatus('logged_out', e.message);
      this.notify('login_lost', '경제교실 로그아웃됨', '로그인 창을 열었습니다. 로그인하면 자동으로 재개됩니다.', 'login_lost');
      this.relogin();
      return;
    }
    this.status.errors++;
    this.setStatus('error', String(e.message || e));
    log('error', String(e.stack || e));
    if (this.status.errors === 3) this.notify('error', '경제교실 감시 오류', String(e.message || e).slice(0, 200), 'err3');
  }

  async relogin() {
    if (this.loginInFlight) return;
    this.loginInFlight = true;
    try {
      const ok = await this.session.interactiveLogin(20);
      this.setStatus(ok ? 'starting' : 'logged_out', ok ? '' : '로그인 시간 초과. 대시보드에서 다시 시도하세요.');
    } catch (e) { log('error', 'relogin 실패: ' + e.message); }
    finally { this.loginInFlight = false; this.poke(); }
  }

  async tick() {
    if (this.running || this.loginInFlight) return;
    this.running = true;
    try {
      const cfg = this.getCfg();
      const api = this.api;
      const user = await api.user();
      const [investments, deposits, products, sbRaw, settings, items, bundle, forecast] = await Promise.all([
        api.investments(), api.deposits(), api.products(), api.stockBatch().catch(() => ({ orders: [], lots: [] })), api.settings(),
        api.items().catch(() => []), api.bundleName().catch(() => null), api.forecast().catch(() => null),
      ]);
      const [purchases, categories, jobs, meals, work, rt, holdingsRaw] = await Promise.all([api.purchases().catch(() => []), api.categories().catch(() => []),
        api.jobs().catch(() => []), api.meals().catch(() => null), api.workSummary().catch(() => null),
        api.stockRealtime().catch(() => null), api.holdings().catch(() => [])]);
      const now = Date.now();

      // ── 주식: 사이트가 회차 방식 → 즉시 체결 방식(stock-realtime)으로 바뀜. 예전 sb 모양으로 맞춰 나머지 코드가 그대로 동작하게 함 ──
      const open = rt ? rt.enabled !== false && !rt.paused && !!rt.open : !sbRaw.blocked;
      const kstNow = new Date(now + 9 * 3600e3);
      const quotes = {};
      for (const q of rt?.quotes || []) quotes[q.investmentId] = { valid: !!q.valid, displayStatus: q.displayStatus, price: num(q.rawPrice) * (num(q.multiplier) || 1), reason: q.reason, quotedAt: q.quotedAt, version: q.version, feeRate: num(q.feeRate) };
      const wd = kstNow.getUTCDay();
      const rtSnap = rt ? { enabled: rt.enabled !== false, paused: !!rt.paused, open, nextOpenAt: rt.nextOpenAt, windows: rt.windows || [], windowsToday: (rt.windows || []).filter((w) => w.weekday === wd), quotes } : null;
      const hold = (Array.isArray(holdingsRaw) ? holdingsRaw : []).map((h) => ({ investment_id: h.investmentId ?? h.investment_id ?? h.id, remaining_shares: num(h.shares ?? h.quantity ?? h.remaining_shares ?? h.remainingShares) })).filter((h) => h.investment_id != null && h.remaining_shares > 0);
      const lots = hold.length ? hold : (sbRaw.lots || []);
      const heldMap = {}; for (const l of lots) heldMap[l.investment_id] = (heldMap[l.investment_id] || 0) + num(l.remaining_shares);
      const nextIso = open ? new Date(now).toISOString() : (rt?.nextOpenAt || sbRaw.nextSessions?.KRX || null);
      const sb = { enabled: rt ? rt.enabled !== false : sbRaw.enabled, blocked: !open, policy: { paused: !!rt?.paused }, classroomTradingEnabled: sbRaw.classroomTradingEnabled,
        nextSessions: nextIso ? { KRX: nextIso, US: nextIso } : sbRaw.nextSessions, notice: sbRaw.notice, orders: sbRaw.orders || [], lots, viewerId: undefined, rt, scheduledTradingRetired: sbRaw.scheduledTradingRetired };
      const positions = botPositionsLedger(state.botTrades || [], heldMap);
      const problems = schemaProblems({ user, investments, deposits, products, sb, rt });
      const orders = (sb.orders || []).filter((o) => !sbRaw.viewerId || o.user_id === sbRaw.viewerId);

      this.recordPrices(investments, now);
      this.maybeAnalyze(investments, settings, now);
      this.watchChanges({ settings, products, items, sb: sbRaw, bundle, investments, rt, jobs });
      this.watchOrders(orders, investments);

      this.snap = { at: new Date(now).toISOString(), user: { name: user.name ?? user.username ?? user.firstName ?? '', balance: num(user.balance) },
        purchases, categories, jobs: Array.isArray(jobs) ? jobs : [],
        meals: meals ? { date: meals.day?.mealDate, status: meals.day?.status, total: (meals.records || []).length, filled: (meals.records || []).filter((r) => r.result != null).length } : null,
        work: work ? { currentJobId: work.job?.id, jobTitle: work.job?.title, today: work.today, previous: work.previousWorkday } : null,
        investments, deposits, products, rt: rtSnap, analysis: this.analysis,
        dividend: sbRaw.policy ? { enabled: !!sbRaw.policy.dividendEnabled, ratePct: num(sbRaw.policy.dividendRateBps) / 100, nextAt: sbRaw.nextDividendAt || sbRaw.policy.anchorAt || null, holdHoursRequired: 168 } : null,
        sb: { enabled: sb.enabled, blocked: sb.blocked, paused: sb.policy.paused, nextSessions: sb.nextSessions, notice: sb.notice, lots },
        orders, settings, items, positions, botTrades: (state.botTrades || []).slice(-40) };

      this.status.errors = 0;
      if (problems.length) {
        this.setStatus('safe_mode', '응답 형식 변경 감지 → 자동 실행 중지: ' + problems.join(', '));
        this.notify('site_changed', '경제교실 구조 변경 감지', '자동 실행을 멈췄습니다: ' + problems.join(', '), 'schema');
        return;
      }
      if (cfg.paused) { this.setStatus('paused', '사용자가 일시정지함'); this.status.lastOk = this.snap.at; return; }

      this.maybeSelfTest(now);
      this.recordHistory(user, deposits, investments, sb, now);
      this.watchStore(items);
      this.checkJob(forecast, now, meals, work, jobs);
      this.checkFee(settings, orders, now);
      this.maybeThink(now);

      const ctx = { cfg, user, deposits, products, orders, investments, prices: state.prices, settings, sb, now, positions, analysis: this.analysis };
      const aiLive = cfg.ai.mode !== 'off' && this.ai && !this.ai.error && now - Date.parse(this.ai.at) < Math.max(cfg.ai.intervalMinutes * 3, 120) * 60_000;
      // AI가 정상 동작 중이면 AI가 신규 예금/주식 판단을 맡고, 규칙 엔진은 만기 수령·알림만 담당(AI 장애 시 규칙 엔진이 대신함)
      let actions = aiLive
        ? [...planDeposits(ctx).filter((a) => a.kind !== 'deposit'), ...this.aiActions.filter((a) => now - a.t < cfg.ai.intervalMinutes * 60_000 * 1.5)]
        : [...planDeposits(ctx), ...planStocks(ctx)];
      actions = [...actions, ...this.planJob(work, meals, now)];
      await this.dispatch(actions, cfg);
      this.setStatus('ok', '');
      this.status.lastOk = this.snap.at;
    } finally { this.running = false; touch(); }
  }

  // 직업 점검: 오늘 활동일인데 아직 체크 안 했으면 알림. 기록 자체는 사용자가 직접 해야 함(대신 입력하지 않음)
  // 현재 직업은 work-logs(내 직업)를 기준으로 판단. 직업이 바뀌면(예: 급식 관리 → 식품의약품안전처) 즉시 따라감
  checkJob(f, now, meals, work, jobs) {
    const cfg = this.getCfg();
    if (!work?.job) { this.job = null; return; }
    const kst = new Date(now + 9 * 3600e3);
    const today = kst.toISOString().slice(0, 10);
    const cur = work.job;
    const meta = (Array.isArray(jobs) ? jobs : []).find((j) => j.id === cur.id) || {};
    const target = num(meta.weeklyTarget) || num(f?.student?.items?.find((i) => i.jobId === cur.id)?.adjustedTarget) || 5;
    const doneDates = (work.week || []).filter((d) => d.status === 'completed').map((d) => d.date);
    const fi = f?.student?.items?.find((i) => i.jobId === cur.id);
    const done = doneDates.length;
    const expected = fi ? num(fi.amount) : Math.round(num(cur.salary) * Math.min(1, done / target));
    const items = [{ title: cur.title, salary: num(cur.salary), target, done, todayDone: work.today?.status === 'completed',
      pct: Math.round(Math.min(1, done / target) * 100), expected, remaining: Math.max(0, target - done), doneDates, jobId: cur.id }];
    const isWorkday = f?.activityDates ? f.activityDates.includes(today) : (kst.getUTCDay() >= 1 && kst.getUTCDay() <= 5);
    const notes = { multiple_job_assignments: '직업 배정 기록이 여러 개라 선생님 확인을 기다리는 중이에요(주급 지급이 보류될 수 있어요)' };
    const legacy = (f?.student?.items || []).filter((i) => i.jobId !== cur.id).map((i) => i.jobTitle);
    this.job = { today, isWorkday, weekStart: f?.weekStart || work.week?.[0]?.date, status: f?.student?.status || null, payrollNote: f?.student?.status === 'held' ? (notes[f.student.reason] || '급여 확인 대기 중') : null,
      legacyJobs: legacy, expectedPay: expected, items, mealAccess: !!meals };
    // 직업이 바뀌었으면 알림
    if (state.jobId != null && state.jobId !== cur.id) {
      this.notify('job', '직업이 바뀌었어요', `${state.jobTitle || '이전 직업'} → ${cur.title} (주급 ${num(cur.salary).toLocaleString()}원, 주 ${target}일). 이번 주 급여는 선생님이 정산해요.`, 'jobchg' + cur.id);
      log('change', `직업 변경: ${state.jobTitle} → ${cur.title}`);
    }
    state.jobId = cur.id; state.jobTitle = cur.title; touch();
    // 급식 기록 진행도(급식 관리 직업일 때만 접근 가능). 대신 입력하지는 않음
    const recs = meals?.records || [];
    if (recs.length) {
      const filled = recs.filter((r) => r.result != null).length;
      this.job.meals = { date: meals.day?.mealDate, status: meals.day?.status, total: recs.length, filled };
    }
    // 매일 직업 "완료" 체크 감시(체크는 사용자가 직접). 놓치면 주급 비율이 깎이므로 완료될 때까지 매시간 알림
    const hour = kst.getUTCHours();
    const t = work?.today, p = work?.previousWorkday;
    this.job.watch = {
      todayStatus: t?.status ?? null, todayCutoff: t?.cutoffAt ?? null,
      prevStatus: p?.status ?? null, prevEditable: !!p?.previousWorkdayEditable || !!p?.isEditable, prevDate: p?.date ?? null,
    };
    if (cfg.job.remind && isWorkday) {
      const title = items[0]?.title || '직업';
      const doneToday = t ? t.status === 'completed' : items.every((it) => it.todayDone);
      if (!doneToday && hour >= cfg.job.remindHour) {
        const left = t?.cutoffAt ? Math.max(0, Math.round((Date.parse(t.cutoffAt) - now) / 3600e3)) : null;
        this.notify('job', `오늘 ${title} 체크 아직이에요`, `이번 주 ${items[0]?.done ?? '?'}/${items[0]?.target ?? '?'}일. 하루라도 빠지면 주급이 깎여요.${left != null ? ` 마감까지 약 ${left}시간.` : ''}`, `job-${today}-h${hour}`);
      }
    }
    // 어제(직전 근무일)가 미완료인데 아직 수정 가능한 시간이면 알림
    if (cfg.job.remind && p && p.status !== 'completed' && p.isEditable) {
      this.notify('job', `직전 근무일(${p.date}) 체크가 비어 있어요`, '아직 수정 가능한 시간입니다. 마감 전에 처리하세요.', `jobprev-${p.date}-h${hour}`);
    }
  }

  // 외부 시세 분석(백테스트 포함): 시작 직후 한 번, 이후 refreshHours 마다. 백그라운드로 돌려 감시를 막지 않음
  maybeAnalyze(investments, settings, now) {
    const c = this.getCfg().analysis;
    if (!c?.enabled || this.analysisBusy) return;
    const age = this.analysis ? now - Date.parse(this.analysis.at) : Infinity;
    if (age < c.refreshHours * 3600e3) return;
    this.analysisBusy = true;
    const fee = num(settings?.stockTradingFeeRate) || 0.005;
    runAnalysis({ investments, fee }).then((r) => {
      const prevSig = new Set(Object.entries(this.analysis?.stocks || {}).filter(([, s]) => s.passing?.length).map(([id]) => id));
      this.analysis = r; state.analysis = r; touch();
      const fresh = Object.entries(r.stocks).filter(([id, s]) => s.passing.length && !prevSig.has(id));
      if (fresh.length) this.notify('advice', '검증된 매수 신호', fresh.map(([id, s]) => `${investments.find((i) => i.id === +id)?.name}: 기대 +${s.expectedNetPct}% (${s.passing.join('+')})`).join('\n'), 'sig' + fresh.map(([id]) => id).join(','));
    }).catch((e) => log('error', '시세 분석 실패: ' + e.message)).finally(() => { this.analysisBusy = false; });
  }

  // 전체 회귀 점검: 시작 2분 뒤 첫 실행, 이후 정해진 간격으로 반복(읽기 전용)
  maybeSelfTest(now) {
    const c = this.getCfg().selfTest;
    if (!c?.enabled || this.regBusy) return;
    const last = this.reg ? Date.parse(this.reg.at) : this.startedAt + 2 * 60_000 - c.intervalMinutes * 60_000;
    if (now - last >= c.intervalMinutes * 60_000) this.runSelfTestNow('정기');
  }

  async runSelfTestNow(why = '수동') {
    if (this.regBusy) return this.reg;
    this.regBusy = true;
    try {
      const r = await runSelfTest({ api: this.api, getCfg: this.getCfg });
      r.why = why;
      this.reg = r;
      const bad = r.checks.filter((x) => !x.ok);
      log('selftest', `[${why}] 회귀 점검 ${r.passed}/${r.total} 통과${bad.length ? ' · 실패: ' + bad.map((b) => `${b.name}(${b.detail})`).join('; ') : ''}`);
      const sig = bad.map((b) => b.name).sort().join('|');
      if (sig && sig !== state.regSig) this.notify('error', `회귀 점검 실패 ${bad.length}건`, bad.slice(0, 3).map((b) => `${b.name}: ${b.detail}`).join('\n'), 'reg' + sig);
      else if (!sig && state.regSig) this.notify('action', '회귀 점검 복구', `${r.total}개 항목 모두 통과`, 'regok' + r.at);
      state.regSig = sig; touch();
    } catch (e) {
      log('error', '회귀 점검 실행 실패: ' + e.message);
    } finally { this.regBusy = false; }
    return this.reg;
  }

  // 직업 완료 체크: 실제 일(오늘 급식 기록 전원 입력)이 끝난 것이 확인될 때만 제안/자동 실행. 일이 안 된 날은 체크하지 않음
  planJob(work, meals, now) {
    const cfg = this.getCfg();
    if (cfg.job.mode === 'off' || !work?.today || !this.job?.isWorkday) return [];
    const t = work.today;
    if (t.status === 'completed' || !t.isEditable) return [];
    const recs = meals?.records || [];
    const done = recs.length > 0 && recs.every((r) => r.result != null);
    if (!done) return [];
    return [{ key: `jobmark:${t.date}`, kind: 'jobmark', module: 'job', date: t.date,
      desc: `직업 완료 체크: ${t.date} (급식 기록 ${recs.length}/${recs.length}명 입력 확인됨)` }];
  }

  // 수수료 점검(하루 1회 + 변경 시): 설정값과 실제 체결 주문의 수수료율 대조
  checkFee(settings, orders, now) {
    const day = new Date(now + 9 * 3600e3).toISOString().slice(0, 10);
    const fee = num(settings?.stockTradingFeeRate);
    const filled = orders.filter((o) => !['pending', 'cancelled', 'rejected', 'failed'].includes(o.status) && o.fee_rate != null);
    const last = filled[0];
    const mismatch = last && Math.abs(num(last.fee_rate) - fee) > 1e-9;
    this.feeCheck = { day, ratePerSide: fee, roundTripPct: +(fee * 200).toFixed(2), lastOrderRate: last ? num(last.fee_rate) : null, mismatch: !!mismatch,
      transferFee: num(settings?.transferFeeRate), transferEnabled: !!settings?.transferEnabled };
    if (state.feeDay !== day) {
      state.feeDay = day;
      log('check', `수수료 점검: 주식 편도 ${(fee * 100).toFixed(2)}% (왕복 ${(fee * 200).toFixed(2)}%), 송금 ${settings?.transferEnabled ? num(settings.transferFeeRate) + '%' : '비활성'}${mismatch ? ' · 최근 주문 수수료율과 불일치!' : ''}`);
      touch();
    }
    if (mismatch) this.notify('site_changed', '수수료 불일치', `설정 ${fee} vs 최근 주문 ${last.fee_rate}`, 'feemm' + last.fee_rate);
  }

  maybeThink(now) {
    const cfg = this.getCfg();
    if (cfg.ai.mode === 'off' || this.aiBusy || cfg.paused) return;
    const ns = this.snap?.sb?.nextSessions || {};
    const next = Math.min(...Object.values(ns).filter(Boolean).map((t) => Date.parse(t)));
    const sKey = Number.isFinite(next) ? 'ai-session-' + next : null;
    const preDue = sKey && next - now > 0 && next - now <= cfg.ai.preSessionMinutes * 60_000 && !state.seen[sKey];
    const lastAt = this.ai ? Date.parse(this.ai.at) : 0;
    const retryOk = !this.ai?.error || now - lastAt > 30 * 60_000; // 인증 실패 등은 30분마다만 재시도
    const due = now - lastAt >= cfg.ai.intervalMinutes * 60_000;
    // 즉시 체결 방식: 거래 창이 열릴 때마다 한 번 판단(창마다 1회)
    let winKey = null;
    const rt = this.snap?.rt;
    if (rt?.open) {
      const day = new Date(now + 9 * 3600e3).toISOString().slice(0, 10);
      for (const w of rt.windowsToday || []) {
        const s = Date.parse(`${day}T${w.start}:00+09:00`), e = Date.parse(`${day}T${w.end}:00+09:00`);
        if (now >= s && now < e) { winKey = 'ai-win-' + s; break; }
      }
    }
    const winDue = winKey && !state.seen[winKey];
    if (!(preDue || due || winDue) || !retryOk) return;
    if (sKey && preDue) { state.seen[sKey] = now; touch(); }
    if (winDue) { state.seen[winKey] = now; touch(); }
    this.aiBusy = true;
    this.runThink(now, winDue ? '거래 창 열림' : preDue ? '거래 창 직전' : '정기').finally(() => { this.aiBusy = false; });
  }

  // Claude 로그인이 풀리면 스스로 로그인 창(브라우저)을 띄움. 승인 클릭만 사용자가 하면 됨. 6시간에 한 번만
  claudeRelogin() {
    const last = state.lastClaudeLogin || 0;
    if (Date.now() - last < 6 * 3600_000 || this.getCfg().ai.provider !== 'claude-cli' || this.getCfg().ai.autoRelogin === false) return;
    state.lastClaudeLogin = Date.now(); touch();
    try {
      const p = spawn('claude', ['auth', 'login'], { shell: true, detached: true, stdio: 'ignore' });
      p.unref();
      log('auth', 'Claude 로그인이 풀려 로그인 창을 자동으로 열었습니다');
      this.notify('error', 'Claude 로그인이 필요해요', '브라우저가 열리면 승인만 눌러 주세요. (오래 유지하려면 setup-claude-token.bat 를 한 번 실행)', 'claudelogin' + Math.floor(Date.now() / 6 / 3600e3));
    } catch (e) { log('error', 'Claude 자동 로그인 실패: ' + e.message); }
  }

  async runThink(now, why) {
    const cfg = this.getCfg();
    const snap = this.snap;
    const fee = num(snap.settings?.stockTradingFeeRate) || 0.005;
    try {
      const ctx = buildContext({ cfg, snap, prices: state.prices, positions: snap.positions, fee, now });
      const decision = await think(ctx, cfg);
      const v = validate(decision, { cfg, snap, positions: snap.positions, fee, analysis: this.analysis });
      this.aiActions = v.actions.map((a) => ({ ...a, t: Date.now() }));
      // AI가 판단 때 본 핵심 상황(화면 표시용) + 판단 기록(최근 40개 보관)
      const tradable = (ctx.stocks || []).filter((s) => s.tradable);
      const movers = (ctx.stocks || []).slice().sort((a, b) => Math.abs(b.dayChangePct) - Math.abs(a.dayChangePct)).slice(0, 4).map((s) => ({ name: s.name, pct: s.dayChangePct, tradable: s.tradable }));
      const seen = { cash: ctx.cash, reserve: ctx.cashReserve, tradingOpen: !!ctx.trading?.open, nextOpenAt: ctx.trading?.nextOpenAt || null, tradableCount: tradable.length, stockCount: (ctx.stocks || []).length, depositTotal: (ctx.deposits || []).reduce((s, d) => s + d.principal, 0), feeRoundTripPct: ctx.roundTripFeePct, movers };
      this.ai = { at: new Date().toISOString(), why, decision, rejected: v.rejected, error: null, seen };
      (state.aiHistory ??= []).push({ at: this.ai.at, why, summary: decision.summary, forecast: decision.forecast, confidence: decision.confidence, watch: decision.watch, actions: decision.actions, accepted: v.actions.map((a) => a.desc), rejected: v.rejected.map((r) => ({ action: r.action, why: r.why })), seen });
      if (state.aiHistory.length > 40) state.aiHistory.splice(0, state.aiHistory.length - 40);
      touch();
      log('ai', `[${why}] ${decision.summary} (제안 ${v.actions.length}, 거부 ${v.rejected.length})`);
      for (const r of v.rejected) log('ai', `AI 제안 거부: ${JSON.stringify(r.action).slice(0, 120)} → ${r.why}`);
      this.poke();
    } catch (e) {
      this.ai = { at: new Date().toISOString(), why, decision: this.ai?.decision || null, rejected: [], error: e.message };
      log('error', 'AI 실패: ' + e.message);
      if (/authenticate|OAuth|로그인|login/i.test(e.message)) this.claudeRelogin();
      this.notify('error', 'AI 판단 실패(규칙 엔진으로 대체)', e.message.slice(0, 200), 'aierr');
    }
  }

  // 총자산 추이(차트용): 10분마다 1점, 30일 보관
  recordHistory(user, deposits, investments, sb, now) {
    const h = (state.history ??= []);
    if (h.length && now - h[h.length - 1][0] < 10 * 60_000) return;
    const byId = new Map(investments.map((i) => [i.id, i]));
    const dep = deposits.filter((d) => !d.isEarlyTerminated).reduce((s, d) => s + num(d.principal), 0);
    const stk = (sb.lots || []).filter((l) => !sb.viewerId || l.user_id === sb.viewerId)
      .reduce((s, l) => s + (byId.get(l.investment_id) ? unitPrice(byId.get(l.investment_id)) * num(l.remaining_shares) : 0), 0);
    h.push([now, Math.round(num(user.balance)), Math.round(dep), Math.round(stk)]);
    while (h.length && h[0][0] < now - 30 * 86400_000) h.shift();
    touch();
  }

  // 상점은 자동 구매하지 않음. 관심 상품(wishlist)의 재입고/가격 인하만 알림
  watchStore(items) {
    if (!Array.isArray(items)) return;
    const prev = (state.itemSeen ??= {});
    const wish = new Set((this.getCfg().store.wishlist || []).map(Number));
    for (const i of items) {
      const p = prev[i.id];
      if (p && wish.has(i.id)) {
        if (p.stock <= 0 && num(i.stock) > 0) this.notify('store', '관심 상품 재입고', `${i.name} 재고 ${i.stock}개 · ${num(i.price).toLocaleString()}원`, 'restock' + i.id + i.stock);
        if (num(i.price) < p.price) this.notify('store', '관심 상품 가격 인하', `${i.name} ${p.price.toLocaleString()} → ${num(i.price).toLocaleString()}원`, 'drop' + i.id + i.price);
      }
      prev[i.id] = { stock: num(i.stock), price: num(i.price) };
    }
    touch();
  }

  recordPrices(investments, now) {
    for (const inv of investments) {
      const s = (state.prices[inv.id] ??= []);
      const last = s[s.length - 1];
      if (!last || now - last[0] >= 5 * 60_000) s.push([now, unitPrice(inv)]);
      const cut = now - 8 * 86400_000;
      while (s.length && s[0][0] < cut) s.shift();
    }
    touch();
  }

  watchChanges(f) {
    const cur = fingerprint(f);
    const prev = state.baseline;
    if (prev && prev.apiKeys) {
      const d = diff(prev, cur);
      if (d.length) {
        for (const x of d.slice(0, 20)) log('change', `${x.path}: ${JSON.stringify(x.from)} → ${JSON.stringify(x.to)}`);
        const store = d.filter((x) => x.path.startsWith('items'));
        const other = d.filter((x) => !x.path.startsWith('items') && !x.path.startsWith('stocks'));
        if (store.length) this.notify('store', '상점 변경', `${store.length}건 변경 (상점은 자동 구매하지 않습니다)`, 'store' + store.length + store[0].path);
        if (other.length) this.notify('site_changed', '경제교실 설정/상품 변경', other.slice(0, 3).map((x) => `${x.path}: ${x.from}→${x.to}`).join('\n'), 'chg' + other[0].path + other[0].to);
      }
    }
    state.baseline = cur;
    touch();
  }

  watchOrders(orders, investments) {
    const names = new Map(investments.map((i) => [i.id, i.name]));
    for (const o of orders) {
      const k = 'o' + o.id;
      if (state.seen[k] && state.seen[k] !== o.status) {
        this.notify('order', '주문 상태 변경', `${names.get(o.investment_id) || o.investment_name} ${o.side === 'buy' ? '매수' : '매도'} ${num(o.shares)}주: ${state.seen[k]} → ${o.status}`, k + o.status);
      }
      state.seen[k] = o.status;
    }
  }

  async dispatch(actions, cfg) {
    const keys = new Set(actions.map((a) => a.key));
    for (const k of Object.keys(state.suggestions)) if (!keys.has(k)) delete state.suggestions[k];
    const today = new Date().toISOString().slice(0, 10);
    state.daily = state.daily?.day === today ? state.daily : { day: today, n: 0 };
    const cap = cfg.maxAutoActionsPerDay ?? 10;

    for (const a of actions) {
      if (a.kind === 'alert') { this.notify(a.event, '알림', a.desc, a.key); continue; }
      let mode = cfg[a.module]?.mode;
      if (cfg.role === 'monitor' && mode === 'auto') mode = 'advice'; // 감시 전용 인스턴스는 자동 실행하지 않음(다른 곳이 주 실행)
      if (mode === 'auto') {
        if (state.daily.n >= cap) { this.notify('error', '일일 자동 실행 한도 도달', `${cap}건`, 'cap' + today); continue; }
        if (state.seen['done:' + a.key] && Date.now() - state.seen['done:' + a.key] < 10 * 60_000) continue; // 중복 실행 방지
        state.seen['done:' + a.key] = Date.now();
        state.daily.n++;
        await this.execute(a, 'auto');
        await sleep(1500);
      } else if (mode === 'advice' && !state.suggestions[a.key]) {
        state.suggestions[a.key] = { ...a, at: new Date().toISOString() };
        this.notify('advice', '제안', a.desc, a.key);
        log('advice', a.desc);
      } else if (mode === 'advice') state.suggestions[a.key] = { ...state.suggestions[a.key], ...a };
    }
    touch();
  }

  async execute(a, by = 'manual') {
    try {
      let res;
      if (a.kind === 'collect') res = await this.api.terminateDeposit(a.id);
      else if (a.kind === 'deposit') res = await this.api.createDeposit({ productId: a.productId, name: this.getCfg().botPrefix + new Date().toISOString().slice(2, 16).replace(/[-:T]/g, ''), amount: a.amount });
      else if (a.kind === 'jobmark') res = await this.api.markWork(a.date, true);
      else if (a.kind === 'order') {
        res = await this.api.placeOrder({ investmentId: a.investmentId, side: a.side, shares: a.shares });
        const st = String(res.order?.status || res.status || '').toLowerCase();
        const q = res.quote;
        // 프로그램이 낸 주문 기록(자동 매수분 판별용). 직접 낸 주문은 기록하지 않음 → 건드리지 않음
        (state.botTrades ??= []).push({ t: Date.now(), investmentId: a.investmentId, side: a.side, shares: a.shares, status: st, price: quotePrice(q), fee: num(q?.feeRate), orderId: res.order?.id ?? null });
        if (state.botTrades.length > 500) state.botTrades.splice(0, state.botTrades.length - 500);
        if (st !== 'filled') throw new Error(`주문이 체결되지 않았습니다 (상태: ${st || '알 수 없음'})`);
      }
      else throw new Error('알 수 없는 액션 ' + a.kind);
      log('action', `[${by}] ${a.desc}`, { result: typeof res === 'object' ? res : undefined });
      this.notify('action', by === 'auto' ? '자동 실행' : '실행 완료', a.desc, a.key + Date.now());
      delete state.suggestions[a.key];
      this.aiActions = this.aiActions.filter((x) => x.key !== a.key);
      touch();
      this.poke();
      return { ok: true, res };
    } catch (e) {
      log('error', `[${by}] 실패: ${a.desc} → ${e.message}`);
      this.notify('error', '실행 실패', `${a.desc}\n${e.message}`.slice(0, 250), 'fail' + a.key);
      return { ok: false, error: e.message };
    }
  }
}
