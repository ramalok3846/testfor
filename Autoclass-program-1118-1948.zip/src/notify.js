import { spawn } from 'node:child_process';
import { log } from './store.js';

// 자체 알림창·윈도우 알림은 트레이 프로세스(tray.ps1)가 이 큐를 받아 보여줌
const queue = [];
let lastTrayPoll = 0;
export function takePopups() { lastTrayPoll = Date.now(); return queue.splice(0, queue.length); }
const trayAlive = () => Date.now() - lastTrayPoll < 20_000;
export const trayStats = () => ({ alive: trayAlive(), queued: queue.length, lastPollAgoSec: lastTrayPoll ? Math.round((Date.now() - lastTrayPoll) / 1000) : null });

const URGENT = new Set(['login_lost', 'error']);
const FALLBACK_PS = `
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
$n = New-Object System.Windows.Forms.NotifyIcon
$n.Icon = [System.Drawing.SystemIcons]::Information
$n.Visible = $true
$n.ShowBalloonTip(8000, $env:AC_TITLE, $env:AC_BODY, [System.Windows.Forms.ToolTipIcon]::Info)
Start-Sleep -Seconds 9
$n.Dispose()
`;

// 링크 종류 자동 인식: Discord / Slack / ntfy / 그 외(일반 JSON)
export function linkKind(url) {
  if (!url) return null;
  if (/discord(app)?\.com\/api\/webhooks\//i.test(url)) return 'discord';
  if (/hooks\.slack\.com\//i.test(url)) return 'slack';
  if (/(^|\/\/)ntfy\.[a-z0-9.-]+\/[^/?#]+/i.test(url) || /\/\/[^/]*ntfy[^/]*\/[^/?#]+/i.test(url)) return 'ntfy';
  return 'generic';
}

async function sendPhone(url, title, body, urgent) {
  const kind = linkKind(url);
  try {
    let res;
    if (kind === 'ntfy') {
      const u = new URL(url);
      res = await fetch(u.origin + '/', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ topic: u.pathname.replace(/^\//, '').split('/')[0], title, message: body, priority: urgent ? 4 : 3, tags: urgent ? ['warning'] : ['bell'] }),
      });
    } else if (kind === 'discord') {
      res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ content: `**${title}**\n${body}` }) });
    } else if (kind === 'slack') {
      res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text: `*${title}*\n${body}` }) });
    } else {
      res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ title, body, message: body, content: `${title}\n${body}`, text: `${title}\n${body}` }) });
    }
    if (!res.ok) log('error', `폰 알림 전송 실패 ${res.status} (${kind})`);
    return res.ok;
  } catch (e) { log('error', '폰 알림 전송 실패: ' + e.message); return false; }
}

const inQuiet = (q, now = new Date()) => {
  if (!q?.enabled) return false;
  const m = (s) => { const [h, mi] = String(s).split(':').map(Number); return h * 60 + (mi || 0); };
  const cur = (now.getUTCHours() + 9) % 24 * 60 + now.getUTCMinutes();
  const a = m(q.from), b = m(q.to);
  return a <= b ? cur >= a && cur < b : cur >= a || cur < b;
};

export function createNotifier(getCfg) {
  const lastSent = new Map();
  // opts.force: 테스트 알림(중복 방지·조용한 시간 무시), opts.override: {popup,system,phone,sound}
  function notify(event, title, body, key = title + body, opts = {}) {
    const cfg = getCfg().notify;
    const now = Date.now();
    if (!opts.force && now - (lastSent.get(key) || 0) < 30 * 60_000) return; // 같은 알림 30분 내 재전송 방지
    lastSent.set(key, now);
    log('notify', `[${event}] ${title} ${body}`);
    if (!cfg.master && !opts.force) return;

    // 예전 설정(toast:false)은 끈 것으로 간주
    const legacyOff = cfg.toast && cfg.toast[event] === false;
    const e = { popup: true, system: false, phone: false, sound: 'default', ...(cfg.events?.[event] || {}), ...(opts.override || {}) };
    if (legacyOff && !opts.override) { e.popup = false; e.system = false; }
    const urgent = URGENT.has(event);
    let sound = e.sound || 'none';
    if (!opts.force && inQuiet(cfg.quiet) && !(urgent && cfg.quiet.allowUrgent)) sound = 'none';

    if (e.popup || e.system) {
      queue.push({ id: now + Math.random(), event, title, body, popup: !!e.popup, system: !!e.system, sound, urgent });
      if (queue.length > 20) queue.shift();
      // 트레이가 없으면 시스템 알림만 직접 띄움
      if (e.system && !trayAlive() && process.platform === 'win32') {
        setTimeout(() => {
          if (trayAlive()) return;
          try {
            const p = spawn('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', FALLBACK_PS],
              { env: { ...process.env, AC_TITLE: title, AC_BODY: body }, stdio: 'ignore', windowsHide: true, detached: true });
            p.unref();
          } catch {}
        }, 3000);
      }
    }
    const url = (cfg.phoneUrl || '').trim();
    if (url && e.phone) sendPhone(url, title, body, urgent);
  }
  notify.sendPhone = sendPhone;
  return notify;
}
