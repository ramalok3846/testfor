// 순수 계산: 지표·신호 규칙·수수료 차감 백테스트. 네트워크 없음(테스트 가능).
// 목적: "오를 것 같은" 느낌이 아니라, 과거 1년 데이터에서 수수료를 뺀 뒤에도 실제로 이득이었던 조건만 골라 쓰기.
const n0 = (v) => (Number.isFinite(v) ? v : null);

export function prep(c) {
  const n = c.length, sma = (k) => c.map((_, i) => (i >= k - 1 ? c.slice(i - k + 1, i + 1).reduce((s, x) => s + x, 0) / k : null));
  const rsi = Array(n).fill(null);
  let g = 0, l = 0;
  for (let i = 1; i < n; i++) {
    const d = c[i] - c[i - 1], up = Math.max(d, 0), dn = Math.max(-d, 0);
    if (i <= 14) { g += up / 14; l += dn / 14; if (i === 14) rsi[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l); }
    else { g = (g * 13 + up) / 14; l = (l * 13 + dn) / 14; rsi[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l); }
  }
  const hi20 = c.map((_, i) => (i >= 20 ? Math.max(...c.slice(i - 20, i)) : null)); // 직전 20일 최고가
  return { c, rsi, sma20: sma(20), sma50: sma(50), sma100: sma(100), hi20 };
}

// 신호 규칙(5거래일 보유 가정). 규칙 수를 일부러 적게 유지해 "우연히 맞은 조건 찾기"(과적합)를 줄임
export const RULES = [
  { id: 'mom', label: '모멘텀: 20일 상승 + 50일선 위 + 5일 상승', H: 5, test: (p, i) => p.sma50[i] != null && i >= 20 && p.c[i] > p.c[i - 20] && p.c[i] > p.sma50[i] && p.c[i] > p.c[i - 5] },
  { id: 'pull', label: '눌림목: 100일선 위 상승추세 + RSI 35 미만', H: 5, test: (p, i) => p.sma100[i] != null && p.rsi[i] != null && p.c[i] > p.sma100[i] && p.rsi[i] < 35 },
  { id: 'rev', label: '과매도 반등: RSI 25 미만', H: 5, test: (p, i) => p.rsi[i] != null && p.rsi[i] < 25 },
  { id: 'brk', label: '돌파: 직전 20일 최고가 갱신', H: 5, test: (p, i) => p.hi20[i] != null && p.c[i] > p.hi20[i] },
];

const mean = (a) => a.reduce((s, x) => s + x, 0) / (a.length || 1);
const std = (a) => { if (a.length < 2) return 0; const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };

// seriesMap: { key: closes[] } → 규칙별 풀링 통계. roundTrip = 왕복 수수료율(예: 0.01)
export function backtest(seriesMap, roundTrip, rules = RULES) {
  const preps = Object.values(seriesMap).filter((c) => c && c.length > 140).map(prep);
  return rules.map((rule) => {
    const rs = [], first = [], second = [], base = [];
    for (const p of preps) {
      const n = p.c.length;
      let next = 0;
      for (let i = 100; i < n - rule.H; i++) {
        const gross = p.c[i + rule.H] / p.c[i] - 1;
        base.push(gross - roundTrip);                       // 조건 없이 아무 때나 산 경우(시장 흐름 기준선)
        if (i < next || !rule.test(p, i)) continue;
        const r = gross - roundTrip;
        rs.push(r); (i < n / 2 ? first : second).push(r);
        next = i + rule.H;                                  // 같은 구간 겹침 방지(독립에 가깝게)
      }
    }
    const m = mean(rs), s = std(rs), t = rs.length > 1 && s > 0 ? m / (s / Math.sqrt(rs.length)) : 0, bm = mean(base);
    const pass = rs.length >= 25 && m > 0.004 && t >= 2 && mean(first) > 0 && mean(second) > 0 && m - bm > 0.002;
    return { id: rule.id, label: rule.label, H: rule.H, n: rs.length, meanNetPct: +(m * 100).toFixed(2), hitPct: rs.length ? +((rs.filter((x) => x > 0).length / rs.length) * 100).toFixed(0) : 0,
      t: +t.toFixed(2), halves: [+(mean(first) * 100).toFixed(2), +(mean(second) * 100).toFixed(2)], baselinePct: +(bm * 100).toFixed(2), pass };
  });
}

export function featuresOf(c) {
  const n = c.length; if (n < 25) return null;
  const p = prep(c), i = n - 1, last = c[i];
  const ret = (k) => n10(last / c[i - k] - 1);
  const rets = c.slice(-21).map((x, j, a) => (j ? x / a[j - 1] - 1 : 0)).slice(1);
  return { last: +last.toFixed(2), ret1: ret(1), ret5: ret(5), ret20: ret(20), rsi: p.rsi[i] != null ? +p.rsi[i].toFixed(0) : null,
    distSma20: p.sma20[i] ? n10(last / p.sma20[i] - 1) : null, distSma50: p.sma50[i] ? n10(last / p.sma50[i] - 1) : null, vol20: n10(std(rets)),
    firing: RULES.filter((r) => r.test(p, i)).map((r) => r.id) };
}
function n10(v) { return Number.isFinite(v) ? +(v * 100).toFixed(2) : null; }
export { n0 };
