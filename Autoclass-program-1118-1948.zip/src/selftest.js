// 전체 회귀 점검: 사이트 API 계약(읽기 전용) + 이 프로그램의 판단 로직(고정 시나리오) + 연동(AI 로그인, 저장소).
// 사이트 상태를 바꾸는 요청은 절대 보내지 않는다.
import fs from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { DATA, DEFAULTS, merge } from './config.js';
import { planDeposits, planStocks, botPositions, botPositionsLedger, stockKeepOf } from './strategy.js';
import { validate, parseDecision } from './ai.js';
import { fingerprint, diff, schemaProblems } from './watcher.js';
import { backtest, prep, featuresOf } from './signals.js';
import { daily } from './market.js';

const run = promisify(execFile);
const isNum = (v) => Number.isFinite(parseFloat(v));

async function check(out, name, group, fn) {
  const t0 = Date.now();
  try {
    const detail = await fn();
    out.push({ name, group, ok: true, detail: detail ?? '', ms: Date.now() - t0 });
  } catch (e) {
    out.push({ name, group, ok: false, detail: String(e.message || e).slice(0, 240), ms: Date.now() - t0 });
  }
}
const must = (c, msg) => { if (!c) throw new Error(msg); };
const hasKeys = (o, keys) => { const miss = keys.filter((k) => !(k in (o || {}))); must(!miss.length, '필드 없음: ' + miss.join(', ')); };

export async function runSelfTest({ api, getCfg }) {
  const out = [];
  const cfg = merge(DEFAULTS, { stocks: { mode: 'auto', cashForStocks: 0 }, deposits: { mode: 'auto' } });
  let user, investments, deposits, products, sb, settings, rt;

  // ── 1. 사이트 API 계약 (읽기 전용) ──
  await check(out, '로그인 세션 유지', 'site', async () => { user = await api.user(); hasKeys(user, ['balance']); must(isNum(user.balance), 'balance 숫자 아님'); return `현금 ${user.balance}`; });
  await check(out, '투자 종목 목록', 'site', async () => { investments = await api.investments(); must(Array.isArray(investments) && investments.length, '목록 비어 있음'); hasKeys(investments[0], ['id', 'currentPrice', 'priceMultiplier', 'market', 'type']); must(isNum(investments[0].currentPrice), '가격 숫자 아님'); return `${investments.length}종목`; });
  await check(out, '주식 실시간 거래 정보(즉시 체결)', 'site', async () => {
    rt = await api.stockRealtime(); hasKeys(rt, ['enabled', 'open', 'windows', 'quotes']);
    must(Array.isArray(rt.quotes) && rt.quotes.length, '시세 목록 없음'); hasKeys(rt.quotes[0], ['investmentId', 'rawPrice', 'version', 'valid']);
    const v = rt.quotes.filter((q) => q.valid).length;
    return `거래 ${rt.open ? '창 열림' : '창 닫힘'} · 유효 시세 ${v}/${rt.quotes.length} · 다음 ${rt.nextOpenAt || '-'}`;
  });
  await check(out, '보유 주식(내 포트폴리오)', 'site', async () => { const h = await api.holdings(); must(Array.isArray(h), '배열 아님'); sb = await api.stockBatch().catch(() => ({ orders: [], lots: [] })); return `보유 ${h.length}종목`; });
  await check(out, '교실 설정·수수료', 'site', async () => { settings = await api.settings(); hasKeys(settings, ['stockTradingFeeRate']); const f = parseFloat(settings.stockTradingFeeRate); must(f >= 0 && f < 0.2, '수수료율 비정상 ' + f); return `주식 편도 ${(f * 100).toFixed(2)}%`; });
  await check(out, '예금 목록', 'site', async () => { deposits = await api.deposits(); must(Array.isArray(deposits), '배열 아님'); if (deposits[0]) hasKeys(deposits[0], ['id', 'principal', 'interestRate', 'maturityDate', 'isMatured']); return `${deposits.length}건`; });
  await check(out, '예금 상품', 'site', async () => { products = await api.products(); must(Array.isArray(products) && products.length, '상품 없음'); hasKeys(products[0], ['id', 'interestRate', 'termDays']); return products.map((p) => `${p.name} ${+p.interestRate}%/${p.termDays}일`).join(' · '); });
  await check(out, '상점 아이템', 'site', async () => { const it = await api.items(); must(Array.isArray(it), '배열 아님'); if (it[0]) hasKeys(it[0], ['id', 'name', 'price', 'stock']); return `${it.length}개`; });
  await check(out, '상점 분류·구매 이력', 'site', async () => { const c = await api.categories(); const p = await api.purchases(); must(Array.isArray(c) && Array.isArray(p), '배열 아님'); return `분류 ${c.length} · 이력 ${p.length}`; });
  await check(out, '직업 목록', 'site', async () => { const j = await api.jobs(); must(Array.isArray(j) && j.length, '직업 없음'); hasKeys(j[0], ['id', 'title', 'salary', 'weeklyTarget']); return `${j.length}개`; });
  await check(out, '내 직업 체크 현황', 'site', async () => { const w = await api.workSummary(); hasKeys(w, ['today', 'job']); hasKeys(w.today, ['date', 'status']); return `${w.today.date} ${w.today.status}`; });
  await check(out, '주급 예상', 'site', async () => { const f = await api.forecast(); hasKeys(f, ['activityDates', 'student']); return `상태 ${f.student?.status}`; });
  await check(out, '급식 기록 화면 (급식 관리 직업일 때만)', 'site', async () => {
    try { const m = await api.meals(); hasKeys(m, ['day', 'records']); return `${m.records.filter((r) => r.result != null).length}/${m.records.length}명 · ${m.day?.status}`; }
    catch (e) { if (/403|권한/.test(e.message)) return '권한 없음 — 현재 직업이 급식 관리가 아니라서 정상'; throw e; }
  });
  await check(out, '벌금 내역', 'site', async () => { const r = await api.get('/api/fines?page=1&limit=3&scope=received'); must(Array.isArray(r.data), 'data 배열 없음'); return `내 벌금 기록 ${r.data.length}건 확인`; });
  await check(out, '기부 목표', 'site', async () => { const g = await api.get('/api/donation-goals'); must(Array.isArray(g), '배열 아님'); return `목표 ${g.length}개`; });
  await check(out, '게시판', 'site', async () => { const p = await api.get('/api/posts'); must(Array.isArray(p.data), 'data 배열 없음'); return `글 ${p.data.length}개`; });
  await check(out, '학급 친구 목록(선물·송금용)', 'site', async () => { const u = await api.get('/api/users/simple'); must(Array.isArray(u) && u.length, '목록 없음'); return `${u.length}명`; });
  await check(out, '자리 경매·좌석', 'site', async () => { const s = await api.get('/api/seats'); must(Array.isArray(s), '좌석 배열 아님'); return `좌석 ${s.length}개`; });
  await check(out, '내 거래 내역(전체)', 'site', async () => { const r = await api.get('/api/my-transaction-logs?page=1&limit=5'); must(Array.isArray(r.data) && r.total !== undefined, 'data/total 없음'); hasKeys(r.data[0] || {}, ['transactionType', 'amount', 'balanceAfter', 'createdAt']); return `전체 ${r.total}건`; });
  await check(out, '내 급식 요약(이번 달)', 'site', async () => { const m = new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 7); const r = await api.get(`/api/meals/me/summary?month=${m}`); hasKeys(r, ['participationDays', 'cleanPlateCount']); return `참여 ${r.participationDays}일 · 다 먹음 ${r.cleanPlateCount}번`; });
  await check(out, '내 직업 정보', 'site', async () => { const j = await api.get('/api/user/job'); must(j && j.jobId !== undefined, 'jobId 없음'); return j.job?.title || '-'; });
  await check(out, '사이트 번들(화면 코드) 변경 여부', 'site', async () => { const b = await api.bundleName(); must(b, '번들 이름 못 찾음'); return b; });
  await check(out, '응답 형식 종합 검사', 'site', async () => { const p = schemaProblems({ user, investments, deposits, products, sb, rt }); must(!p.length, p.join(', ')); return '이상 없음'; });

  await check(out, '외부 시세 접속(Yahoo 일봉)', 'site', async () => { const r = await daily('005930.KS', 6); must(r.length > 150, '일봉 부족 ' + r.length); return `삼성전자 일봉 ${r.length}개`; });
  await check(out, '시세 분석 결과(최신)', 'site', async () => { const a = (await import('./store.js')).state.analysis; must(a, '분석 결과 없음(시작 직후엔 몇 초 걸려요)'); const age = (Date.now() - Date.parse(a.at)) / 3600e3; must(age < 30, '분석이 오래됨 ' + age.toFixed(0) + '시간'); return `종목 ${a.universe}개 · 통과 규칙 ${a.passingRules.length}/${a.rules.length} · 지금 신호 ${a.signalsNow}종목`; });

  // ── 2. 판단 로직 고정 시나리오 ──
  const inv = (o) => ({ id: 1, name: 'T', market: 'KRX', type: 'stock', currentPrice: '1000', priceMultiplier: '1', tradingEnabled: true, isActive: true, changePercent: '0', ...o });
  const now = Date.now();
  const baseSb = { enabled: true, blocked: false, policy: { paused: false }, nextSessions: { KRX: new Date(now + 3600e3).toISOString(), US: new Date(now + 3600e3).toISOString() }, orders: [], lots: [] };
  const series = (arr) => arr.map((p, i) => [now - (arr.length - i) * 3600e3, p]);

  await check(out, '로직: 예금은 일 복리가 높은 상품 선택', 'logic', () => {
    const r = planDeposits({ cfg, user: { balance: 10000 }, deposits: [], products: [{ id: 8, name: 's', interestRate: '3', termDays: 7, isActive: true }, { id: 9, name: 'l', interestRate: '10', termDays: 30, isActive: true }], orders: [], now });
    const d = r.find((a) => a.kind === 'deposit'); must(d && d.productId === 8, '선택 상품 ' + d?.productId); return '7일 3% 선택(일 복리 우위)';
  });
  await check(out, '로직: 직접 만든 예금은 자동 해지 안 함', 'logic', () => {
    const past = new Date(now - 86400e3).toISOString();
    const r = planDeposits({ cfg, user: { balance: 0 }, deposits: [{ id: 1, name: '직접', principal: 100, interestRate: 3, maturityDate: past, isMatured: true, productName: 'x', createdAt: past }, { id: 2, name: 'auto-1', principal: 100, interestRate: 3, maturityDate: past, isMatured: true, productName: 'x', createdAt: past }], products: [], orders: [], now });
    must(!r.some((a) => a.kind === 'collect' && a.id === 1), '직접 예금을 수령하려 함'); must(r.some((a) => a.kind === 'collect' && a.id === 2), '자동 예금 수령 누락'); return '직접=알림만, auto-=수령';
  });
  await check(out, '로직: 만기 전 예금은 건드리지 않음', 'logic', () => {
    const fut = new Date(now + 86400e3).toISOString();
    const r = planDeposits({ cfg, user: { balance: 0 }, deposits: [{ id: 3, name: 'auto-1', principal: 100, interestRate: 3, maturityDate: fut, isMatured: false, productName: 'x', createdAt: fut }], products: [], orders: [], now });
    must(!r.length, '만기 전인데 동작 생성'); return '동작 없음';
  });
  const T_AM = Date.parse('2026-11-18T01:00:00Z'), T_PM = Date.parse('2026-11-18T05:45:00Z'); // 한국시간 10:00 / 14:45
  const prod = [{ id: 8, name: 's', interestRate: '3', termDays: 7, isActive: true, minDeposit: null, maxDeposit: null }];
  const dep = (n) => Array.from({ length: n }, (_, i) => ({ id: 100 + i, name: 'auto-' + i, principal: 1000, interestRate: 3, maturityDate: '2026-12-30T00:00:00Z', isMatured: false, productName: 'x', createdAt: '2026-11-18T00:30:00Z' }));
  await check(out, '예금 묶기: 하루 한도(2개)에 닿으면 더 넣지 않음', 'logic', () => {
    const r = planDeposits({ cfg, user: { balance: 50000 }, deposits: dep(2), products: prod, orders: [], now: T_PM, analysis: null });
    must(!r.some((a) => a.kind === 'deposit'), '한도 초과 예금 생성'); return '오늘 2개 → 추가 0개';
  });
  await check(out, '예금 묶기: 소액은 모아 두었다가 오후에 한 번에', 'logic', () => {
    const early = planDeposits({ cfg, user: { balance: 6000 }, deposits: [], products: prod, orders: [], now: T_AM, analysis: null });
    const late = planDeposits({ cfg, user: { balance: 6000 }, deposits: dep(1), products: prod, orders: [], now: T_PM, analysis: null });
    must(!early.some((a) => a.kind === 'deposit'), '소액을 오전에 바로 가입'); must(late.some((a) => a.kind === 'deposit' && a.amount === 6000), '오후 묶음 가입 안 됨(마지막 칸)'); return '오전 보류 · 오후 묶음';
  });
  await check(out, '예금 묶기: 큰 금액은 바로 가입(첫 칸)', 'logic', () => {
    const r = planDeposits({ cfg, user: { balance: 40000 }, deposits: [], products: prod, orders: [], now: T_AM, analysis: null });
    must(r.some((a) => a.kind === 'deposit'), '큰 금액인데 보류'); return '1만 원 이상 → 바로';
  });
  await check(out, '현금 배분: 검증 신호가 없으면 주식용 현금 비율 축소', 'logic', () => {
    const cfg2 = merge(cfg, { stocks: { cashForStocks: 0.5, cashForStocksIdle: 0.1 }, cashReserve: 0 });
    const k1 = stockKeepOf({ cfg: cfg2, balance: 10000, analysis: { signalsNow: 0 } }), k2 = stockKeepOf({ cfg: cfg2, balance: 10000, analysis: { signalsNow: 2 } });
    must(k1 < k2 && k1 === 1000 && k2 === 5000, `비율 이상 ${k1}/${k2}`); return '신호 없음 10% · 신호 있음 50%';
  });
  await check(out, 'AI 안전장치: 하루 예금 개수 한도 초과 거부', 'guard', () => {
    const snap = { user: { balance: 90000 }, investments: [], products: prod, deposits: dep(2), orders: [], sb: { blocked: false } };
    const v = validate({ actions: [{ kind: 'deposit', productId: 8, amount: 5000, why: 'x' }] }, { cfg, snap, positions: {}, fee: 0.005 });
    must(v.actions.length === 0 && /한도/.test(v.rejected[0]?.why || ''), '한도 초과가 통과: ' + JSON.stringify(v.rejected)); return '거부';
  });
  await check(out, '로직: 주식 거래 차단 시 주문 없음', 'logic', () => {
    const inv1 = inv({}); const h = series(Array.from({ length: 12 }, (_, i) => (i < 6 ? 1200 : 1000 + i)));
    const r = planStocks({ cfg, user: { balance: 100000 }, investments: [inv1], orders: [], prices: { 1: h }, settings: { stockTradingFeeRate: '0.005' }, sb: { ...baseSb, blocked: true }, now });
    must(!r.length, '차단 중인데 주문 생성'); return '차단 시 0건';
  });
  await check(out, '로직: 하락 후 반등 종목만 매수 후보', 'logic', () => {
    const inv1 = inv({ currentPrice: '960' });
    const flat = series(Array.from({ length: 14 }, () => 1000));
    const dip = series([1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 940, 930, 935, 945, 955]);
    const a = planStocks({ cfg, user: { balance: 100000 }, investments: [inv1], orders: [], prices: { 1: flat }, settings: { stockTradingFeeRate: '0.005' }, sb: baseSb, now });
    const b = planStocks({ cfg, user: { balance: 100000 }, investments: [inv1], orders: [], prices: { 1: dip }, settings: { stockTradingFeeRate: '0.005' }, sb: baseSb, now });
    must(!a.length, '횡보인데 매수'); must(b.some((x) => x.side === 'buy'), '하락 후 반등인데 매수 없음'); return '횡보=무, 반등=매수';
  });
  const dipSeries = series([1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 940, 930, 935, 945, 955]);
  const q1 = (valid) => ({ investmentId: 1, valid, rawPrice: '960', multiplier: '1', feeRate: '0.005', version: 'v' });
  const planRt = (rtObj) => planStocks({ cfg, user: { balance: 100000 }, investments: [inv({ currentPrice: '960' })], orders: [], prices: { 1: dipSeries }, settings: { stockTradingFeeRate: '0.005' }, sb: { ...baseSb, rt: rtObj }, now, positions: {} });
  await check(out, '즉시 체결: 거래 창이 닫혀 있으면 주문 없음', 'logic', () => {
    must(!planRt({ enabled: true, paused: false, open: false, quotes: [q1(true)] }).length, '창이 닫혔는데 주문 생성'); return '닫힘=0건';
  });
  await check(out, '즉시 체결: 시세가 잠긴 종목은 거래 안 함', 'logic', () => {
    must(!planRt({ enabled: true, paused: false, open: true, quotes: [q1(false)] }).length, '시세 잠금인데 주문 생성'); return '시세 잠금=0건';
  });
  await check(out, '즉시 체결: 창 열림 + 시세 유효 + 신호면 매수 후보', 'logic', () => {
    must(planRt({ enabled: true, paused: false, open: true, quotes: [q1(true)] }).some((a) => a.side === 'buy'), '정상 조건인데 매수 없음'); return '매수 후보 생성';
  });
  await check(out, '즉시 체결: 프로그램 주문 기록만 집계·실제 보유 초과분 보정', 'logic', () => {
    const p = botPositionsLedger([{ investmentId: 1, side: 'buy', shares: 10, status: 'filled', price: 100, fee: 0.005 }, { investmentId: 2, side: 'buy', shares: 5, status: 'cancelled', price: 100, fee: 0.005 }], { 1: 4 });
    must(p[1]?.shares === 4 && !p[2], '집계/보정 오류 ' + JSON.stringify(p)); return '체결분만, 보유 4주로 보정';
  });
  await check(out, '백테스트: 무작위 흐름에서는 통과 규칙이 없어야 함(과적합 방지)', 'logic', () => {
    let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const map = {}; for (let k = 0; k < 12; k++) { let p = 100; map['r' + k] = Array.from({ length: 250 }, () => (p *= 1 + (rnd() - 0.5) * 0.04)); }
    const res = backtest(map, 0.01); must(!res.some((r) => r.pass), '무작위 데이터에서 통과 규칙 발생: ' + res.filter((r) => r.pass).map((r) => r.id)); return '무작위=통과 0개';
  });
  await check(out, '백테스트: 뚜렷한 상승 추세 데이터는 통과할 수 있어야 함', 'logic', () => {
    const map = {}; for (let k = 0; k < 12; k++) { let p = 100; map['u' + k] = Array.from({ length: 250 }, (_, i) => (p *= 1.006 + Math.sin(i / 3 + k) * 0.01)); }
    const res = backtest(map, 0.01); must(res.some((r) => r.n > 0 && r.meanNetPct > 0), '상승 추세인데 양의 평균 없음'); return '상승=양의 평균 확인';
  });
  await check(out, '지표: RSI·특징 계산', 'logic', () => {
    const f = featuresOf(Array.from({ length: 60 }, (_, i) => 100 + i)); must(f && f.rsi === 100 && f.ret5 > 0, '지표 이상 ' + JSON.stringify(f)); return 'RSI/수익률 정상';
  });
  const snapSig = () => ({ user: { balance: 100000 }, investments: [inv({ currentPrice: '1000' })], products: [], deposits: [], orders: [], sb: baseSb });
  await check(out, 'AI 안전장치: 검증된 신호 없는 종목 매수 거부', 'guard', () => {
    const analysis = { stocks: { 1: { passing: [], firing: [] } } };
    const v = validate({ actions: [{ kind: 'order', investmentId: 1, side: 'buy', shares: 5, expectedGainPct: 9, why: 'x' }] }, { cfg, snap: snapSig(), positions: {}, fee: 0.005, analysis });
    must(v.actions.length === 0 && /신호/.test(v.rejected[0]?.why || ''), '신호 없는데 통과: ' + JSON.stringify(v.rejected)); return '거부';
  });
  await check(out, 'AI 안전장치: 검증된 신호가 있으면 매수 통과', 'guard', () => {
    const analysis = { stocks: { 1: { passing: ['mom'], firing: ['mom'], expectedNetPct: 1.2 } } };
    const v = validate({ actions: [{ kind: 'order', investmentId: 1, side: 'buy', shares: 5, expectedGainPct: 1.2, why: 'x' }] }, { cfg, snap: snapSig(), positions: {}, fee: 0.005, analysis });
    must(v.actions.length === 1, '정상 신호가 막힘: ' + JSON.stringify(v.rejected)); return '통과';
  });

  await check(out, '로직: 수수료 반영 후 손실 구간은 매도 안 함', 'logic', () => {
    const inv1 = inv({ currentPrice: '1020' });
    const orders = [{ id: 1, request_key: 'auto-x', status: 'completed', side: 'buy', investment_id: 1, shares: '10', gross: 10000, fee: 50 }];
    const r = planStocks({ cfg, user: { balance: 0 }, investments: [inv1], orders, prices: { 1: [] }, settings: { stockTradingFeeRate: '0.005' }, sb: baseSb, now });
    must(!r.some((a) => a.side === 'sell'), '수수료 포함 +1%대에서 매도 시도'); return '왕복 수수료 미달 시 보유';
  });
  await check(out, '로직: 사용자가 직접 산 주식은 포지션에서 제외', 'logic', () => {
    const p = botPositions([{ request_key: 'man-1', status: 'completed', side: 'buy', investment_id: 1, shares: '5', gross: 5000, fee: 25 }, { request_key: 'auto-1', status: 'completed', side: 'buy', investment_id: 2, shares: '3', gross: 3000, fee: 15 }]);
    must(!p[1] && p[2]?.shares === 3, '직접 매수분이 포함됨'); return 'auto- 만 집계';
  });
  const snapFx = (extra = {}) => ({ user: { balance: 100000 }, investments: [inv({ currentPrice: '1000' })], products: [{ id: 8, name: 's', interestRate: '3', termDays: 7, isActive: true, minDeposit: null, maxDeposit: null }], deposits: [], orders: [], sb: baseSb, ...extra });
  await check(out, 'AI 안전장치: 수수료 미달 기대수익 거부', 'guard', () => {
    const v = validate({ actions: [{ kind: 'order', investmentId: 1, side: 'buy', shares: 10, expectedGainPct: 1.0, why: 'x' }] }, { cfg, snap: snapFx(), positions: {}, fee: 0.005 });
    must(v.actions.length === 0 && v.rejected.length === 1, '거부되지 않음'); return '1% < 왕복1%+1.5% → 거부';
  });
  await check(out, 'AI 안전장치: 충분한 기대수익은 통과', 'guard', () => {
    const v = validate({ actions: [{ kind: 'order', investmentId: 1, side: 'buy', shares: 10, expectedGainPct: 6, why: 'x' }] }, { cfg, snap: snapFx(), positions: {}, fee: 0.005 });
    must(v.actions.length === 1, '정상 제안이 막힘: ' + JSON.stringify(v.rejected)); return '통과';
  });
  await check(out, 'AI 안전장치: 자동 매수분 이상 매도 거부', 'guard', () => {
    const v = validate({ actions: [{ kind: 'order', investmentId: 1, side: 'sell', shares: 5, why: '손절' }] }, { cfg, snap: snapFx(), positions: {}, fee: 0.005 });
    must(v.actions.length === 0, '보유 없는데 매도 허용'); return '거부';
  });
  await check(out, 'AI 안전장치: 비중 한도 초과 거부', 'guard', () => {
    const v = validate({ actions: [{ kind: 'order', investmentId: 1, side: 'buy', shares: 90, expectedGainPct: 8, why: 'x' }] }, { cfg, snap: snapFx(), positions: {}, fee: 0.005 });
    must(v.actions.length === 0, '비중 25% 초과 허용'); return '거부';
  });
  await check(out, 'AI 안전장치: 허용 안 된 행동(상점 등) 거부', 'guard', () => {
    const v = validate({ actions: [{ kind: 'purchase', itemId: 1 }, { kind: 'transfer', amount: 100 }] }, { cfg, snap: snapFx(), positions: {}, fee: 0.005 });
    must(v.actions.length === 0 && v.rejected.length === 2, '허용 안 된 행동 통과'); return '거부';
  });
  await check(out, 'AI 응답 파서', 'guard', () => {
    const d = parseDecision('설명 {"summary":"s","forecast":"f","confidence":0.5,"actions":[{"type":"deposit","productId":8,"amount":1000}],"watch":[]} 끝');
    must(d.actions[0].kind === 'deposit', 'type→kind 변환 실패'); let bad = false; try { parseDecision('{"forecast":"x"}'); } catch { bad = true; } must(bad, 'summary 없는 응답 허용'); return '정상';
  });
  await check(out, '변경 감시 엔진', 'logic', () => {
    const a = fingerprint({ settings: { stockTradingFeeRate: '0.005' }, products: [], items: [], sb: baseSb, bundle: 'a', investments: [] });
    const b = fingerprint({ settings: { stockTradingFeeRate: '0.010' }, products: [], items: [], sb: baseSb, bundle: 'a', investments: [] });
    must(diff(a, b).some((x) => x.path === 'fee'), '수수료 변경 감지 실패'); return '수수료 변경 감지';
  });

  // ── 3. 연동·저장소 ──
  await check(out, 'AI 연결(Claude 로그인)', 'infra', async () => {
    if (getCfg().ai.mode === 'off') return 'AI 꺼짐';
    if (getCfg().ai.provider === 'api') { must(process.env.ANTHROPIC_API_KEY || getCfg().ai.apiKey, 'API 키 없음'); return 'API 키 있음'; }
    // claude CLI 는 처음 부를 때 10초 넘게 걸릴 수 있어 제한을 넉넉히 두고, 실패하면 한 번 더 시도
    let stdout = '', lastErr;
    for (let i = 0; i < 2 && !stdout; i++) {
      try { ({ stdout } = await run('claude', ['auth', 'status'], { shell: true, timeout: 60000, windowsHide: true })); } catch (e) { lastErr = e; stdout = e.stdout || ''; }
    }
    if (!stdout) throw lastErr || new Error('claude auth status 응답 없음');
    must(/"loggedIn":\s*true/.test(stdout), 'Claude 로그인 필요(설정 → 연결·유지 에서 로그인)'); return /oauth_token/.test(stdout) ? '로그인됨 (장기 토큰)' : '로그인됨';
  });
  await check(out, '데이터 폴더 쓰기', 'infra', () => { const f = DATA + '\\.selftest'; fs.writeFileSync(f, String(Date.now())); fs.unlinkSync(f); return 'OK'; });
  await check(out, '세션 쿠키 보관', 'infra', () => { const c = JSON.parse(fs.readFileSync(DATA + '\\cookies.json', 'utf8')); must(c.some((x) => x.name === 'connect.sid'), '로그인 쿠키 없음'); return `${c.length}개`; });
  await check(out, '로그 용량', 'infra', () => { const s = fs.existsSync(DATA + '\\activity.jsonl') ? fs.statSync(DATA + '\\activity.jsonl').size : 0; must(s < 40e6, '로그가 너무 큼'); return `${(s / 1e6).toFixed(1)}MB`; });

  const failed = out.filter((c) => !c.ok);
  return { at: new Date().toISOString(), total: out.length, passed: out.length - failed.length, failed: failed.length, checks: out };
}
