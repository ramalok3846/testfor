// 경제교실의 나머지 기능(상점 구매·사용·환불·선물, 기부, 벌금 조회, 자리 경매, 게시판, 송금, 직업 지원)을
// 사이트와 같은 API로 호출. 자동으로는 절대 실행하지 않고, 대시보드에서 사용자가 직접 누를 때만 호출됨.
import { log } from './store.js';

const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };
const int = (v) => Math.floor(num(v));
const fail = (m) => { throw new Error(m); };

export function createServices({ api, notifyAction }) {
  const s = api.s;
  const req = async (method, path, body, okMsg) => {
    const r = await s.request(method, path, body);
    if (r.status >= 300) {
      let m = r.text.slice(0, 200);
      try { m = JSON.parse(r.text).message || JSON.parse(r.text).error || m; } catch {}
      fail(`${m} (${r.status})`);
    }
    return r.json ?? {};
  };
  const done = (msg) => { log('action', `[manual] ${msg}`); notifyAction?.(msg); };
  const balance = async () => num((await api.user()).balance);

  return {
    // ── 읽기 ──
    async data(name, q = {}) {
      switch (name) {
        case 'fines': return api.get(`/api/fines?page=${int(q.page) || 1}&limit=${Math.min(50, int(q.limit) || 20)}&scope=received`);
        case 'goals': return { goals: await api.get('/api/donation-goals'), progress: await api.get('/api/donation-goals/progress').catch(() => []), recent: await api.get('/api/donations/recent').catch(() => []), ranking: await api.get('/api/donations/ranking').catch(() => []), stats: await api.get('/api/donations/stats').catch(() => null) };
        case 'posts': return api.get('/api/posts');
        case 'auction': {
          const sess = await api.get('/api/auction-sessions/active').catch(() => null);
          const seats = await api.get('/api/seats').catch(() => []);
          const auctions = sess?.id ? await api.get(`/api/seat-auctions/active?sessionId=${sess.id}`).catch(() => []) : [];
          return { session: sess || null, seats, auctions: Array.isArray(auctions) ? auctions : [] };
        }
        case 'users': return api.get('/api/users/simple');
        case 'transactions': return api.get('/api/my-transaction-logs');
        // 내 거래 내역(사이트 "내 종합 상태"의 전체 내역과 같은 데이터). page/limit 지원
        case 'mylogs': return api.get(`/api/my-transaction-logs?page=${int(q.page) || 1}&limit=${Math.min(100, int(q.limit) || 50)}`);
        // 내 급식 요약(급식 관리 권한과 무관하게 누구나 볼 수 있음): 최근 N개월
        case 'meals': {
          const n = Math.min(12, int(q.months) || 4), out = [];
          const kst = new Date(Date.now() + 9 * 3600e3);
          for (let i = 0; i < n; i++) {
            const d = new Date(Date.UTC(kst.getUTCFullYear(), kst.getUTCMonth() - i, 1));
            const month = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
            const r = await api.get(`/api/meals/me/summary?month=${month}`).catch(() => null);
            if (r && !r.message) out.push(r);
          }
          return { months: out };
        }
        default: fail('알 수 없는 조회');
      }
    },

    // ── 상점 ──
    async buy({ itemId, quantity = 1 }) {
      const q = Math.max(1, int(quantity));
      const items = await api.items();
      const it = items.find((x) => x.id === Number(itemId));
      if (!it || it.isActive === false) fail('없는 아이템입니다');
      if (num(it.stock) < q) fail(`재고가 부족합니다 (재고 ${it.stock}개)`);
      const total = num(it.price) * q;
      if ((await balance()) < total) fail(`잔액이 부족합니다 (필요 ${total.toLocaleString()}원)`);
      const r = await req('POST', `/api/items/${Number(itemId)}/purchase`, { quantity: q });
      done(`상점 구매: ${it.name} ×${q} (${total.toLocaleString()}원)`);
      return r;
    },
    async useItem({ purchaseId, quantity = 1 }) {
      const r = await req('PUT', `/api/user/purchases/${Number(purchaseId)}/use`, { quantity: Math.max(1, int(quantity)) });
      done(`아이템 사용: #${purchaseId} ×${quantity}`);
      return r;
    },
    async refundItem({ purchaseId }) {
      const r = await req('POST', `/api/user/purchases/${Number(purchaseId)}/refund`, {});
      done(`아이템 환불: #${purchaseId} (+${num(r.refundAmount).toLocaleString()}원)`);
      return r;
    },
    async sendItem({ purchaseId, toUserId, message = '', quantity = 1 }) {
      if (!toUserId) fail('받는 사람을 골라 주세요');
      const r = await req('POST', `/api/user/purchases/${Number(purchaseId)}/send`, { toUserId, message: String(message).slice(0, 200), quantity: Math.max(1, int(quantity)) });
      done(`아이템 선물: #${purchaseId} → ${toUserId}`);
      return r;
    },

    // ── 기부 ──
    async donate({ amount, goalId = null, message = '', isAnonymous = false }) {
      const a = int(amount);
      if (a <= 0) fail('기부 금액을 입력해 주세요');
      if ((await balance()) < a) fail('잔액이 부족합니다');
      const r = await req('POST', '/api/donations', { amount: String(a), message: String(message).trim().slice(0, 200) || null, isAnonymous: !!isAnonymous, goalId: goalId && goalId !== 'none' ? Number(goalId) : null });
      done(`기부: ${a.toLocaleString()}원${isAnonymous ? ' (익명)' : ''}`);
      return r;
    },

    // ── 자리 경매 ──
    async bid({ seatAuctionId, amount }) {
      const a = int(amount);
      if (a <= 0) fail('입찰 금액을 입력해 주세요');
      if ((await balance()) < a) fail('잔액이 부족합니다');
      const r = await req('POST', '/api/bids', { seatAuctionId: Number(seatAuctionId), amount: String(a) });
      done(`자리 경매 입찰: ${a.toLocaleString()}원`);
      return r;
    },

    // ── 게시판 ──
    async post({ content }) {
      const c = String(content || '').trim();
      if (!c) fail('내용을 입력해 주세요');
      const r = await req('POST', '/api/posts', { content: c.slice(0, 2000), imageUrl: null });
      done('게시글 작성');
      return r;
    },
    async comment({ postId, content }) {
      const c = String(content || '').trim();
      if (!c) fail('내용을 입력해 주세요');
      const r = await req('POST', `/api/posts/${Number(postId)}/comments`, { content: c.slice(0, 500) });
      done('댓글 작성');
      return r;
    },
    async like({ postId }) { return req('POST', `/api/posts/${Number(postId)}/like`, {}); },

    // ── 송금 (교사가 켜 둔 경우에만) ──
    async transfer({ toUserId, amount }) {
      const settings = await api.settings();
      if (settings.transferEnabled === false) fail('지금은 송금이 막혀 있습니다 (교사 설정)');
      const a = int(amount);
      if (a <= 0 || !toUserId) fail('받는 사람과 금액을 확인해 주세요');
      const fee = Math.round(Math.max(a * num(settings.transferFeeRate || 0.01), num(settings.transferFeeMin || 100)));
      if ((await balance()) < a + fee) fail(`잔액이 부족합니다 (필요 ${(a + fee).toLocaleString()}원, 수수료 ${fee.toLocaleString()}원 포함)`);
      const r = await req('POST', '/api/transactions', { toUserId, amount: String(a), type: 'transfer', description: '송금' });
      done(`송금: ${a.toLocaleString()}원 → ${toUserId} (수수료 ${fee.toLocaleString()}원)`);
      return r;
    },

    // ── 직업 지원 (직업이 바뀌면 급여 정산에 영향 → 대시보드에서 확인 창을 거침) ──
    async applyJob({ jobId }) {
      const r = await req('POST', `/api/jobs/${Number(jobId)}/assign`, {});
      done(`직업 지원: #${jobId}`);
      return r;
    },
    async markJob({ date, completed = true }) {
      const r = await api.markWork(date, !!completed);
      done(`직업 체크: ${date} ${completed ? '완료' : '미완료'}`);
      return r;
    },
  };
}
