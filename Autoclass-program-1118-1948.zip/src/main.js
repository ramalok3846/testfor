import path from 'node:path';
import { loadConfig, DATA, ROOT, CLOUD } from './config.js';
import { state, flush, log } from './store.js';
import { Session, HttpSession } from './session.js';
import { Api } from './api.js';
import { Engine } from './engine.js';
import { createNotifier } from './notify.js';
import { startServer, TRAY_KEY } from './server.js';
import { spawn } from 'node:child_process';

const cfgRef = { cfg: loadConfig() };
const getCfg = () => cfgRef.cfg;
if (CLOUD && (process.env.DASHBOARD_PASSWORD || '').length < 8) { console.error('클라우드 모드에는 8자 이상의 DASHBOARD_PASSWORD 환경변수가 필요합니다. (인터넷에 열리는 화면을 보호합니다)'); process.exit(2); }
const session = CLOUD ? new HttpSession(getCfg) : new Session(getCfg);
const api = new Api(session);
const notify = createNotifier(getCfg);
const engine = new Engine({ getCfg, session, api, notify });

process.on('uncaughtException', (e) => log('error', 'uncaught: ' + (e.stack || e)));
process.on('unhandledRejection', (e) => log('error', 'unhandled: ' + (e?.stack || e)));

async function shutdown() {
  engine.stopped = true;
  flush();
  await session.close().catch(() => {});
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

if (process.argv.includes('--login')) {
  const ok = await session.interactiveLogin(20);
  console.log(ok ? '로그인 확인 및 저장 완료' : '시간 초과');
  await session.close();
  process.exit(ok ? 0 : 1);
}

try {
  await startServer({ cfgRef, engine, session, api, onQuit: shutdown });
} catch (e) {
  if (e.code === 'EADDRINUSE') { console.log('이미 실행 중입니다 (포트 ' + cfgRef.cfg.port + ').'); process.exit(0); }
  throw e;
}
log('start', `시작 http://127.0.0.1:${cfgRef.cfg.port} · 데이터 ${DATA}`);
console.log(`경제교실 자동화 실행 중: http://127.0.0.1:${cfgRef.cfg.port}`);
if (process.argv.includes('--open')) spawn('cmd', ['/c', 'start', '', `http://127.0.0.1:${cfgRef.cfg.port}`], { stdio: 'ignore', detached: true }).unref();

if (!CLOUD && process.platform === 'win32' && !process.argv.includes('--no-tray')) {
  const tray = spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', path.join(ROOT, 'tray.ps1'), '-Port', String(cfgRef.cfg.port), '-Key', TRAY_KEY],
    { stdio: 'ignore', windowsHide: true });
  tray.on('error', (e) => log('error', '트레이 실행 실패: ' + e.message));
  process.on('exit', () => { try { tray.kill(); } catch {} });
}

// 하트비트: 1분마다 외부 감시 서비스(healthchecks.io 등)에 "살아 있음"을 알림.
// 서비스가 신호를 못 받으면 그쪽에서 폰으로 알려 주므로, 서버가 통째로 꺼져도 알 수 있어요.
const hbUrl = (process.env.HEARTBEAT_URL || '').trim();
if (hbUrl) {
  setInterval(async () => {
    const st = engine.status || {};
    const age = st.lastTick ? Date.now() - Date.parse(st.lastTick) : 0;
    if (age > 600000) return; // 감시가 멈췄으면 신호를 보내지 않음 → 외부에서 경보
    try { await fetch(hbUrl, { signal: AbortSignal.timeout(10000) }); } catch {}
  }, 60000).unref();
}

await session.open(false).catch((e) => log('error', '브라우저 시작 실패: ' + e.message));
engine.loop();
notify('system', '경제교실 오토 시작됨', `프로그램이 시작됐어요 (${new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul', hour12: false })}). PC가 다시 켜졌거나 재시작됐다는 뜻이에요.`, 'start' + Date.now());
