// 외부 시세(Yahoo Finance 차트 API, 사이트가 쓰는 네이버·Yahoo 시세와 같은 시장 데이터).
// 일봉은 하루 몇 번만 받아 파일에 캐시하고, 장중(5분봉)은 필요할 때만 짧게 캐시한다. 공개 데이터 조회만 하며 로그인 정보는 보내지 않는다.
import fs from 'node:fs';
import path from 'node:path';
import { DATA } from './config.js';

const DIR = path.join(DATA, 'market');
fs.mkdirSync(DIR, { recursive: true });
const HDR = { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36' };

export function symbolOf(inv) {
  const code = String(inv.stockCode || inv.ticker || inv.symbol || '').trim();
  if (!code) return null;
  const m = String(inv.market || '').toUpperCase();
  if (m === 'KRX' || m === 'KOSPI') return code + '.KS';
  if (m === 'KOSDAQ') return code + '.KQ';
  return code;
}

// 코스피/코스닥 구분이 사이트와 다를 수 있어 둘 다 시도(첫 번째가 404면 다음)
export function candidatesOf(inv) {
  const code = String(inv.stockCode || inv.ticker || inv.symbol || '').trim(); if (!code) return [];
  const mk = String(inv.market || '').toUpperCase();
  if (mk === 'KOSDAQ') return [code + '.KQ', code + '.KS'];
  if (mk === 'KRX' || mk === 'KOSPI') return [code + '.KS', code + '.KQ'];
  return [code];
}

async function yf(sym, range, interval) {
  let last;
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?range=${range}&interval=${interval}`, { headers: HDR, signal: AbortSignal.timeout(15000) });
      if (r.status === 429) { await new Promise((x) => setTimeout(x, 1500 * (i + 1))); last = new Error('HTTP 429'); continue; }
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const res = (await r.json()).chart?.result?.[0];
      if (!res) throw new Error('데이터 없음');
      const q = res.indicators.quote[0], ts = res.timestamp || [], rows = [];
      for (let k = 0; k < ts.length; k++) if (q.close[k] != null) rows.push([ts[k] * 1000, q.open[k], q.high[k], q.low[k], q.close[k], q.volume[k]]);
      return { rows, meta: res.meta };
    } catch (e) { last = e; await new Promise((x) => setTimeout(x, 800)); }
  }
  throw new Error(`${sym}: ${last?.message || last}`);
}

const safe = (s) => s.replace(/[^\w.^-]/g, '_');
// 일봉: 캐시가 maxAgeH 시간보다 오래되면 새로 받음(장 마감 후에만 값이 바뀌므로 하루 몇 번이면 충분)
export async function daily(sym, maxAgeH = 6) {
  const f = path.join(DIR, `d-${safe(sym)}.json`);
  try { const c = JSON.parse(fs.readFileSync(f, 'utf8')); if (Date.now() - c.at < maxAgeH * 3600e3) return c.rows; } catch {}
  const { rows } = await yf(sym, '1y', '1d');
  try { fs.writeFileSync(f, JSON.stringify({ at: Date.now(), rows })); } catch {}
  return rows;
}
const mem = new Map();
export async function intraday(sym, maxAgeMin = 3) {
  const c = mem.get(sym);
  if (c && Date.now() - c.at < maxAgeMin * 60e3) return c.rows;
  const { rows } = await yf(sym, '5d', '5m');
  mem.set(sym, { at: Date.now(), rows });
  return rows;
}
export async function pool(items, n, fn) {
  const out = []; let i = 0;
  await Promise.all(Array.from({ length: n }, async () => { while (i < items.length) { const k = i++; try { out[k] = await fn(items[k]); } catch (e) { out[k] = { error: String(e.message || e) }; } } }));
  return out;
}
