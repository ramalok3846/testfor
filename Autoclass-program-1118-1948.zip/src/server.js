import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes, createHash } from 'node:crypto';
import os from 'node:os';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { ROOT, DATA, CLOUD, merge, saveConfig } from './config.js';
import { timingSafeEqual } from 'node:crypto';
import { state, recentLog, log, touch } from './store.js';
import { takePopups, linkKind, trayStats } from './notify.js';
import { createServices } from './services.js';

// 재시작해도 열려 있는 화면이 끊기지 않도록 토큰을 파일에 보관(이 PC에서만 접근 가능한 로컬 서버)
const TOKEN = (() => {
  const f = path.join(DATA, 'token');
  try { const t = fs.readFileSync(f, 'utf8').trim(); if (/^[a-f0-9]{32}$/.test(t)) return t; } catch {}
  const t = randomBytes(16).toString('hex');
  try { fs.writeFileSync(f, t); } catch {}
  return t;
})();
export const TRAY_KEY = randomBytes(16).toString('hex');
const UI = path.join(ROOT, 'ui', 'index.html');
const execFileP = promisify(execFile);
// 오래된 기록은 듬성듬성, 최근은 촘촘하게 최대 n개로 줄여 보냄(차트용)
const thin = (a, n) => { if (a.length <= n) return a; const step = a.length / n; const out = []; for (let i = 0; i < n; i++) out.push(a[Math.floor(i * step)]); out.push(a[a.length - 1]); return out; };
const START = Date.now();
const fails = new Map();
const sha = (x) => createHash('sha256').update(String(x)).digest('hex');
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && timingSafeEqual(x, y); };
const LOOP = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);
// 이 PC 안에서 직접 연결한 요청인지(프록시·터널·같은 와이파이의 다른 기기는 '원격'으로 취급)
const isLocal = (req, port) => LOOP.has(req.socket.remoteAddress || '') && [`127.0.0.1:${port}`, `localhost:${port}`].includes(req.headers.host)
  && !req.headers['x-forwarded-for'] && !req.headers['cf-connecting-ip'] && !req.headers['x-real-ip'] && !req.headers.forwarded;
const cookieOf = (req, name) => { const m = new RegExp('(?:^|; )' + name + '=([^;]+)').exec(req.headers.cookie || ''); return m ? decodeURIComponent(m[1]) : ''; };
const lanIps = () => Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
const PWA_TYPES = { '.webmanifest': 'application/manifest+json; charset=utf-8', '.png': 'image/png', '.js': 'text/javascript; charset=utf-8' };

export function startServer({ cfgRef, engine, session, api, onQuit }) {
  const send = (res, code, body, type = 'application/json; charset=utf-8') => {
    res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store' });
    res.end(typeof body === 'string' ? body : JSON.stringify(body));
  };
  const readBody = (req) => new Promise((resolve) => {
    let b = '';
    req.on('data', (c) => { b += c; if (b.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(b || '{}')); } catch { resolve({}); } });
  });

  const startedAt = Date.now();
  const svc = createServices({ api, notifyAction: (m) => engine.notify('action', '실행 완료', m, 'svc' + Date.now()) });
  const server = http.createServer(async (req, res) => {
    try {
      const port = cfgRef.cfg.port;
      const url = new URL(req.url, 'http://x');
      // 앱 설치(PWA)용 파일은 비밀이 없고, 브라우저가 쿠키 없이 가져가므로 인증 없이 제공
      if (req.method === 'GET' && (url.pathname === '/manifest.webmanifest' || url.pathname === '/sw.js' || /^\/icons\/[\w.-]+\.png$/.test(url.pathname))) {
        const pf = url.pathname === '/manifest.webmanifest' ? path.join(ROOT, 'ui', 'manifest.webmanifest') : url.pathname === '/sw.js' ? path.join(ROOT, 'ui', 'sw.js') : path.join(ROOT, 'ui', 'icons', path.basename(url.pathname));
        if (!fs.existsSync(pf)) return send(res, 404, { error: 'not found' });
        res.writeHead(200, { 'content-type': PWA_TYPES[path.extname(pf)] || 'application/octet-stream', 'cache-control': 'no-cache', ...(url.pathname === '/sw.js' ? { 'service-worker-allowed': '/' } : {}) });
        return res.end(fs.readFileSync(pf));
      }
      // 헬스체크: 비밀 없이 "살아 있나"만 알려 줌 (systemd·감시 서비스용). 감시가 10분 넘게 멈추면 503
      if (req.method === 'GET' && url.pathname === '/healthz') {
        const st = engine.status || {};
        const lastMs = st.lastTick ? Date.parse(st.lastTick) : 0;
        const age = lastMs ? Math.round((Date.now() - lastMs) / 1000) : null;
        const ok = age != null ? age < 600 : (Date.now() - startedAt) < 300000;
        return send(res, ok ? 200 : 503, { ok, state: st.state, ageSec: age, uptimeSec: Math.round((Date.now() - startedAt) / 1000) });
      }
      const ip = String(req.headers['x-forwarded-for'] || req.headers['cf-connecting-ip'] || req.socket.remoteAddress || '').split(',')[0].trim();
      const f = fails.get(ip) || { n: 0, t: Date.now() };
      if (Date.now() - f.t > 10 * 60_000) { f.n = 0; f.t = Date.now(); }
      const tooMany = () => send(res, 429, { error: '너무 많이 틀렸어요. 10분 뒤에 다시 시도하세요' });
      if (CLOUD) {
        // 인터넷에 열려 있으므로 대시보드 암호(Basic 인증) 필수. 틀린 시도가 많으면 잠시 차단
        if (f.n >= 10) return tooMany();
        const m = /^Basic (.+)$/.exec(req.headers.authorization || '');
        const given = m ? Buffer.from(m[1], 'base64').toString().split(':').slice(1).join(':') : '';
        const want = process.env.DASHBOARD_PASSWORD || '';
        if (!(want.length >= 8 && safeEq(given, want))) { f.n++; fails.set(ip, f); res.writeHead(401, { 'www-authenticate': 'Basic realm="Autoclass", charset="UTF-8"' }); return res.end('Login required'); }
      } else if (!isLocal(req, port)) {
        // 휴대폰·같은 와이파이·터널(내 도메인)에서 오는 요청: 설정에서 켠 경우에만, 접속 링크(토큰)로 한 번 로그인한 기기만 허용
        const r = cfgRef.cfg.remote || {};
        const page = (t) => send(res, 401, `<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>경제교실 오토</title><body style="font-family:system-ui;padding:40px 24px;text-align:center"><h2>🔒 경제교실 오토</h2><p>${t}</p>`, 'text/html; charset=utf-8');
        if (!r.enabled || !r.tokenHash) return page('휴대폰 접속이 꺼져 있어요. PC에서 설정 → 휴대폰 접속을 켜고 접속 링크를 만들어 주세요.');
        if (f.n >= 10) return tooMany();
        const mm = /^\/m\/([\w-]{20,})$/.exec(url.pathname);
        if (mm) {
          if (safeEq(sha(mm[1]), r.tokenHash)) {
            const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
            res.writeHead(302, { location: '/', 'set-cookie': `ac_s=${mm[1]}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${90 * 86400}${secure}`, 'cache-control': 'no-store' });
            return res.end();
          }
          f.n++; fails.set(ip, f); return page('접속 링크가 맞지 않아요. PC에서 새 링크를 만들어 주세요.');
        }
        const ck = cookieOf(req, 'ac_s');
        if (!(ck && safeEq(sha(ck), r.tokenHash))) { f.n++; fails.set(ip, f); return page('접속 링크로 먼저 들어와 주세요. (PC의 설정 → 휴대폰 접속에서 링크를 만들 수 있어요)'); }
      }
      if (req.method === 'GET' && url.pathname === '/') {
        return send(res, 200, fs.readFileSync(UI, 'utf8').replace('%%TOKEN%%', TOKEN), 'text/html; charset=utf-8');
      }
      if (req.method === 'GET' && /^\/static\/[\w.-]+$/.test(url.pathname)) {
        const f = path.join(ROOT, 'ui', path.basename(url.pathname));
        if (!fs.existsSync(f)) return send(res, 404, { error: 'not found' });
        const type = f.endsWith('.css') ? 'text/css; charset=utf-8' : f.endsWith('.js') ? 'text/javascript; charset=utf-8' : 'application/octet-stream';
        return send(res, 200, fs.readFileSync(f, 'utf8'), type);
      }
      // 트레이 아이콘 전용(별도 비밀키). 최소 정보만 노출
      if (url.pathname.startsWith('/tray/')) {
        if (url.searchParams.get('k') !== TRAY_KEY) return send(res, 401, { error: 'key' });
        if (url.pathname === '/tray/status') {
          const sn = engine.snap;
          return send(res, 200, { state: engine.status.state, detail: engine.status.detail, paused: !!cfgRef.cfg.paused, keepAwake: cfgRef.cfg.system.keepAwake, cash: sn?.user.balance ?? null, url: `http://127.0.0.1:${cfgRef.cfg.port}` });
        }
        if (url.pathname === '/tray/popups') return send(res, 200, takePopups());
        const c = url.searchParams.get('c');
        if (c === 'pause' || c === 'resume') { cfgRef.cfg.paused = c === 'pause'; saveConfig(cfgRef.cfg); engine.poke(); }
        else if (c === 'login') engine.relogin();
        else if (c === 'refresh') engine.poke();
        else if (c === 'quit') { send(res, 200, { ok: true }); setTimeout(() => onQuit?.(), 200); return; }
        return send(res, 200, { ok: true });
      }
      if (req.headers['x-token'] !== TOKEN) return send(res, 401, { error: 'token' });

      if (url.pathname === '/api/state') {
        const snap = engine.snap;
        const spark = {};
        for (const [id, s] of Object.entries(state.prices)) { const t = s.slice(-96); spark[id] = t.map((x) => x[1]); }
        return send(res, 200, { cfg: cfgRef.cfg, status: engine.status, snap, suggestions: Object.values(state.suggestions), log: recentLog().slice(-300).reverse(),
          daily: state.daily || null, history: thin(state.history || [], 1600), aiHistory: (state.aiHistory || []).slice(-30).reverse(), reg: engine.reg, regBusy: engine.regBusy, tray: trayStats(), ai: engine.ai, aiBusy: engine.aiBusy, job: engine.job, feeCheck: engine.feeCheck, spark });
      }
      // ── 연결·유지: Claude 로그인 / 자동 실행 / 폰 링크 ──
      if (url.pathname === '/api/claude/status') {
        try {
          const { stdout } = await execFileP('claude', ['auth', 'status'], { shell: true, timeout: 25000, windowsHide: true });
          const j = JSON.parse(stdout);
          return send(res, 200, { ok: true, loggedIn: !!j.loggedIn, method: j.authMethod || '', longToken: !!process.env.CLAUDE_CODE_OAUTH_TOKEN });
        } catch (e) { return send(res, 200, { ok: false, loggedIn: false, error: String(e.message).slice(0, 160), longToken: !!process.env.CLAUDE_CODE_OAUTH_TOKEN }); }
      }
      if (url.pathname === '/api/claude/login' && req.method === 'POST') {
        try { spawn('claude', ['auth', 'login'], { shell: true, detached: true, stdio: 'ignore' }).unref(); log('auth', 'Claude 로그인 창을 열었습니다(설정에서 실행)'); return send(res, 200, { ok: true }); }
        catch (e) { return send(res, 200, { ok: false, error: e.message }); }
      }
      if (url.pathname === '/api/claude/token-setup' && req.method === 'POST') {
        try { spawn('cmd', ['/c', 'start', '', path.join(ROOT, 'setup-claude-token.bat')], { detached: true, stdio: 'ignore' }).unref(); return send(res, 200, { ok: true }); }
        catch (e) { return send(res, 200, { ok: false, error: e.message }); }
      }
      if (url.pathname === '/api/system' && process.platform !== 'win32') return send(res, 200, { platform: process.platform, cloud: CLOUD, pid: process.pid, startedAt: START, keepAwake: 'off', autostart: null, watchdog: null });
      if (url.pathname === '/api/system') {
        const has = async (n) => { try { await execFileP('schtasks', ['/Query', '/TN', n], { windowsHide: true, timeout: 8000 }); return true; } catch { return false; } };
        return send(res, 200, { autostart: await has('AutoclassAuto'), watchdog: await has('AutoclassWatchdog'), legacyTask: await has('EconomyClassAuto'), pid: process.pid, startedAt: START, keepAwake: cfgRef.cfg.system.keepAwake, platform: process.platform });
      }
      if (url.pathname === '/api/system/task' && req.method === 'POST') {
        const b = await readBody(req);
        if (!['autostart', 'watchdog'].includes(b.which)) return send(res, 200, { ok: false, error: '알 수 없는 항목' });
        const name = b.which === 'autostart' ? 'AutoclassAuto' : 'AutoclassWatchdog';
        try {
          if (b.on) {
            // 파워쉘 없이 작업 XML을 직접 등록(schtasks). 배터리에서도 실행·시간 제한 없음·놓치면 나중에 시작
            const user = `${process.env.USERDOMAIN || ''}\\${process.env.USERNAME || ''}`.replace(/^\\/, '');
            const trigger = b.which === 'autostart'
              ? `<LogonTrigger><Enabled>true</Enabled><UserId>${user}</UserId></LogonTrigger>`
              : `<TimeTrigger><Repetition><Interval>PT5M</Interval><StopAtDurationEnd>false</StopAtDurationEnd></Repetition><StartBoundary>${new Date(Date.now() + 60000).toISOString().slice(0, 19)}</StartBoundary><Enabled>true</Enabled></TimeTrigger>`;
            const xml = `<?xml version="1.0" encoding="UTF-16"?>\r\n<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"><Triggers>${trigger}</Triggers><Principals><Principal id="Author"><UserId>${user}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>LeastPrivilege</RunLevel></Principal></Principals><Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><AllowHardTerminate>true</AllowHardTerminate><StartWhenAvailable>true</StartWhenAvailable><AllowStartOnDemand>true</AllowStartOnDemand><Enabled>true</Enabled><Hidden>true</Hidden><ExecutionTimeLimit>PT0S</ExecutionTimeLimit><Priority>7</Priority></Settings><Actions Context="Author"><Exec><Command>wscript.exe</Command><Arguments>"${path.join(ROOT, 'start-hidden.vbs')}"</Arguments></Exec></Actions></Task>`;
            const f = path.join(DATA, `task-${name}.xml`);
            fs.writeFileSync(f, Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(xml, 'utf16le')]));
            await execFileP('schtasks', ['/Create', '/TN', name, '/XML', f, '/F'], { windowsHide: true, timeout: 20000 });
          } else {
            await execFileP('schtasks', ['/Delete', '/TN', name, '/F'], { windowsHide: true, timeout: 20000 });
          }
          log('config', `${b.which} ${b.on ? '등록' : '해제'} (${name})`);
          return send(res, 200, { ok: true });
        } catch (e) {
          const msg = String(e.stderr || e.stdout || e.message).trim().slice(0, 300);
          log('error', `${b.which} ${b.on ? '등록' : '해제'} 실패: ${msg}`);
          return send(res, 200, { ok: false, error: /denied|거부/i.test(msg) ? '권한이 없어요(같은 이름의 작업이 관리자 권한으로 만들어져 있을 수 있어요). 관리자 명령 프롬프트에서 schtasks /Delete /TN ' + name + ' /F 후 다시 눌러 주세요' : msg });
        }
      }
      if (url.pathname === '/api/ntfy/send' && req.method === 'POST') {
        const b = await readBody(req);
        const u = String(b.url || cfgRef.cfg.notify.phoneUrl || '').trim();
        if (!u) return send(res, 200, { ok: false, error: '링크를 먼저 입력해 주세요' });
        const ok = await engine.notify.sendPhone(u, String(b.title || '경제교실 오토').slice(0, 80), String(b.message || '').slice(0, 500) || '(내용 없음)', false);
        return send(res, 200, { ok, error: ok ? '' : '전송 실패 — 링크를 확인해 주세요' });
      }
      if (url.pathname === '/api/ntfy/new-link') {
        const id = randomBytes(8).toString('hex');
        return send(res, 200, { url: `https://ntfy.sh/autoclass-${id}` });
      }
      // ── 경제교실 기능(읽기/실행). 실행은 사용자가 대시보드에서 직접 누른 경우에만 ──
      if (url.pathname.startsWith('/api/data/') && req.method === 'GET') {
        try { return send(res, 200, { ok: true, data: await svc.data(url.pathname.split('/').pop(), Object.fromEntries(url.searchParams)) }); }
        catch (e) { return send(res, 200, { ok: false, error: e.message }); }
      }
      if (url.pathname.startsWith('/api/svc/') && req.method === 'POST') {
        const op = url.pathname.split('/').pop();
        const b = await readBody(req);
        const ALLOWED = ['buy', 'useItem', 'refundItem', 'sendItem', 'donate', 'bid', 'post', 'comment', 'like', 'transfer', 'applyJob', 'markJob'];
        if (!ALLOWED.includes(op)) return send(res, 404, { ok: false, error: '알 수 없는 기능' });
        if (!b.confirm) return send(res, 200, { ok: false, error: '확인이 필요한 동작입니다' }); // 화면의 확인 창을 거치지 않은 요청 차단
        try { const r = await svc[op](b); engine.poke(); return send(res, 200, { ok: true, result: r }); }
        catch (e) { log('error', `[manual] ${op} 실패: ${e.message}`); return send(res, 200, { ok: false, error: e.message }); }
      }
      // ── 휴대폰 접속 관리(이 PC 안에서만 가능) ──
      if (url.pathname.startsWith('/api/remote/')) {
        if (!isLocal(req, cfgRef.cfg.port)) return send(res, 403, { ok: false, error: '이 PC에서만 바꿀 수 있어요' });
        if (url.pathname === '/api/remote/status') return send(res, 200, { ok: true, enabled: !!cfgRef.cfg.remote?.enabled, hasLink: !!cfgRef.cfg.remote?.tokenHash, listen: cfgRef.cfg.remote?.listen || 'localhost', port: cfgRef.cfg.port, lan: lanIps(), linkAt: cfgRef.cfg.remote?.tokenAt || null });
        if (url.pathname === '/api/remote/link' && req.method === 'POST') {
          const t = randomBytes(24).toString('base64url');
          cfgRef.cfg.remote = { ...(cfgRef.cfg.remote || {}), tokenHash: sha(t), tokenAt: new Date().toISOString() };
          saveConfig(cfgRef.cfg); log('config', '휴대폰 접속 링크를 새로 만들었어요(이전 링크는 무효)');
          return send(res, 200, { ok: true, path: '/m/' + t, lan: lanIps(), port: cfgRef.cfg.port });
        }
        if (url.pathname === '/api/remote/revoke' && req.method === 'POST') {
          cfgRef.cfg.remote = { ...(cfgRef.cfg.remote || {}), tokenHash: '', tokenAt: null }; saveConfig(cfgRef.cfg); log('config', '휴대폰 접속 링크를 폐기했어요');
          return send(res, 200, { ok: true });
        }
      }
      if (url.pathname === '/api/series') {
        const s = state.prices[url.searchParams.get('id')] || [];
        return send(res, 200, s.slice(-700));
      }
      if (url.pathname === '/api/notify-test' && req.method === 'POST') {
        const b = await readBody(req);
        const n = cfgRef.cfg.notify;
        if (b.kind === 'phone') {
          const u = (b.url || n.phoneUrl || '').trim();
          if (!u) return send(res, 200, { ok: false, error: '폰 알림 링크를 먼저 입력해 주세요' });
          const ok = await engine.notify.sendPhone(u, '테스트 알림', '폰으로 알림이 도착했습니다.', false);
          return send(res, 200, { ok, error: ok ? '' : '전송 실패 — 링크를 확인해 주세요', kind: linkKind(u) });
        }
        const sound = ['none', 'default', 'soft', 'alert'].includes(b.sound) ? b.sound : 'default';
        const sys = b.kind === 'system';
        engine.notify('action', '테스트 알림', sys ? '윈도우 알림센터로 보낸 테스트입니다.' : '자체 알림창 테스트입니다. 클릭하면 대시보드가 열려요.', 'test' + Date.now(),
          { force: true, override: { popup: !sys, system: sys, phone: false, sound } });
        return send(res, 200, { ok: true });
      }
      if (url.pathname === '/api/link-kind') return send(res, 200, { kind: linkKind(url.searchParams.get('u') || '') });
      if (url.pathname === '/api/selftest' && req.method === 'POST') {
        if (engine.regBusy) return send(res, 200, { ok: false, error: '이미 점검 중' });
        engine.runSelfTestNow('수동');
        return send(res, 200, { ok: true });
      }
      if (url.pathname === '/api/think' && req.method === 'POST') {
        if (engine.aiBusy || !engine.snap) return send(res, 200, { ok: false, error: engine.aiBusy ? '이미 생각 중' : '데이터 없음' });
        engine.aiBusy = true;
        engine.runThink(Date.now(), '수동').finally(() => { engine.aiBusy = false; });
        return send(res, 200, { ok: true });
      }
      if (req.method !== 'POST') return send(res, 404, { error: 'not found' });
      const body = await readBody(req);

      switch (url.pathname) {
        case '/api/config':
          cfgRef.cfg = merge(cfgRef.cfg, body);
          cfgRef.cfg.port = Number(cfgRef.cfg.port) || 7788;
          saveConfig(cfgRef.cfg);
          log('config', '설정 변경');
          engine.poke();
          return send(res, 200, { ok: true, cfg: cfgRef.cfg });
        case '/api/pause':
          cfgRef.cfg.paused = !!body.paused; saveConfig(cfgRef.cfg);
          log('config', body.paused ? '일시정지' : '재개'); engine.poke();
          return send(res, 200, { ok: true });
        case '/api/login': engine.relogin(); return send(res, 200, { ok: true });
        case '/api/refresh': engine.poke(); return send(res, 200, { ok: true });
        case '/api/apply': {
          const s = state.suggestions[body.key];
          if (!s) return send(res, 404, { error: '제안이 사라졌습니다' });
          return send(res, 200, await engine.execute(s, 'manual'));
        }
        case '/api/dismiss': delete state.suggestions[body.key]; touch(); return send(res, 200, { ok: true });
        case '/api/manual': {
          // 대시보드에서 직접 하는 동작. 모드와 무관하게 즉시 실행
          const a = { key: 'manual:' + Date.now(), ...body };
          if (a.kind === 'terminate') { a.kind = 'collect'; a.desc = `직접 해지 #${a.id}`; }
          else if (a.kind === 'deposit') a.desc = `직접 예금 #${a.productId} ${a.amount}원`;
          else if (a.kind === 'order') a.desc = `직접 주문 ${a.side} #${a.investmentId} ${a.shares}주`;
          else if (a.kind === 'cancel') {
            try { await api.cancelOrder(body.id); log('action', `[manual] 주문 취소 ${body.id}`); engine.poke(); return send(res, 200, { ok: true }); }
            catch (e) { return send(res, 200, { ok: false, error: e.message }); }
          }
          if (a.kind === 'order') a.shares = Math.floor(Number(a.shares));
          if (a.kind === 'deposit') a.amount = Math.floor(Number(a.amount));
          // 직접 만드는 예금은 접두사를 붙이지 않음 -> 자동 관리 대상이 아님
          if (a.kind === 'deposit') {
            try { await api.createDeposit({ productId: a.productId, name: body.name || '직접-' + new Date().toISOString().slice(5, 16).replace(/[-:T]/g, ''), amount: a.amount }); log('action', `[manual] ${a.desc}`); engine.poke(); return send(res, 200, { ok: true }); }
            catch (e) { return send(res, 200, { ok: false, error: e.message }); }
          }
          if (a.kind === 'order') {
            try {
              const r = await api.placeOrder({ investmentId: a.investmentId, side: a.side, shares: a.shares }); // 현재 시세로 즉시 체결(또는 취소)
              const st = String(r.order?.status || r.status || '').toLowerCase();
              log('action', `[manual] ${a.desc} → ${st || '접수'}`, { result: r });
              engine.poke();
              return send(res, 200, st && st !== 'filled' ? { ok: false, error: `체결되지 않았습니다 (상태: ${st})` } : { ok: true, status: st });
            }
            catch (e) { return send(res, 200, { ok: false, error: e.message }); }
          }
          return send(res, 200, await engine.execute(a, 'manual'));
        }
        default: return send(res, 404, { error: 'not found' });
      }
    } catch (e) {
      log('error', 'server: ' + e.message);
      send(res, 500, { error: e.message });
    }
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(cfgRef.cfg.port, CLOUD || cfgRef.cfg.remote?.listen === 'all' ? '0.0.0.0' : '127.0.0.1', () => resolve(server));
  });
}
