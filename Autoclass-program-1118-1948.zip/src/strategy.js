// 순수 계산 모듈: 입력 스냅샷 -> 제안 액션 목록. 네트워크 호출 없음.
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };
export const unitPrice = (inv) => num(inv.currentPrice) * (num(inv.priceMultiplier) || 1);
export const marketOf = (inv) => (['NASDAQ', 'NYSE'].includes(inv.market) ? 'US' : 'KRX');

const isMatured = (d, now) => d.isMatured || new Date(d.maturityDate).getTime() <= now;
const live = (d) => !d.isEarlyTerminated && !d.terminated && !d.isTerminated && !d.isCollected && d.status !== 'terminated';

// 하루당 복리 수익률. 기간이 짧은 상품이 재투자 가능하면 더 유리할 수 있음
export const perDay = (p) => Math.pow(1 + num(p.interestRate) / 100, 1 / Math.max(1, num(p.termDays))) - 1;

const orderCost = (o) => num(o.raw_price) * (num(o.multiplier) || 1) * num(o.shares);

export function planDeposits({ cfg, user, deposits, products, orders, now, analysis }) {
  const c = cfg.deposits, out = [];
  if (c.mode === 'off') return out;
  const mine = (d) => String(d.name || '').startsWith(cfg.botPrefix);

  for (const d of deposits.filter(live)) {
    if (!isMatured(d, now)) continue;
    if (mine(d) && c.collectMatured) {
      out.push({ key: `collect:${d.id}`, kind: 'collect', module: 'deposits', id: d.id,
        desc: `만기 수령: ${d.productName} ${num(d.principal).toLocaleString()}원 (+${num(d.interestRate)}%)` });
    } else if (!mine(d)) {
      out.push({ key: `matured-manual:${d.id}`, kind: 'alert', event: 'matured', module: 'deposits',
        desc: `직접 만든 예금 만기 도달(건드리지 않음): ${d.productName} ${num(d.principal).toLocaleString()}원` });
    }
  }

  const pendingBuy = orders.filter((o) => o.status === 'pending' && o.side === 'buy').reduce((s, o) => s + orderCost(o), 0);
  const stockKeep = stockKeepOf({ cfg, balance: num(user.balance), analysis });
  const free = Math.floor(num(user.balance) - cfg.cashReserve - pendingBuy - stockKeep);
  const recentMine = deposits.some((d) => mine(d) && now - new Date(d.createdAt).getTime() < c.cooldownMinutes * 60000);
  const active = products.filter((p) => p.isActive !== false);

  // ── 예금 묶어서 넣기: 같은 날 여러 개로 쪼개 넣으면 관리·이자 면에서 불리할 수 있어(함정 가능성) 하루 개수를 제한하고 모아서 한 번에 가입 ──
  const todayN = depositsToday(deposits, cfg.botPrefix, now);
  const maxPerDay = num(c.maxPerDay ?? 2) || 2;
  const afterFlush = kstHourFrac(now) >= num(c.flushHour ?? 14.5);          // 오후 2:30 이후엔 그날 모인 돈을 마지막으로 묶어 넣음
  const batchMin = Math.max(num(c.batchMinAmount ?? 10000), c.minAmount);
  const lastSlot = todayN === maxPerDay - 1;                              // 마지막 한 칸은 하루치를 모아 넣기 위해 아껴 둠
  const ready = todayN < maxPerDay && (lastSlot ? afterFlush && free >= c.minAmount : free >= batchMin || (afterFlush && free >= c.minAmount));
  if (ready && active.length && !recentMine) {
    const ok = active.filter((p) => free >= num(p.minDeposit));
    const best = ok.sort((a, b) => perDay(b) - perDay(a))[0];
    if (best) {
      const amount = Math.min(free, num(best.maxDeposit) || free);
      const gain = Math.floor((amount * num(best.interestRate)) / 100);
      out.push({ key: `deposit:${best.id}:${amount}`, kind: 'deposit', module: 'deposits', productId: best.id, amount,
        desc: `예금 가입(오늘 ${todayN + 1}/${maxPerDay}번째, 묶어서): ${best.name} ${amount.toLocaleString()}원 → ${best.termDays}일 후 약 +${gain.toLocaleString()}원` });
    }
  }
  return out;
}

export const kstDay = (t) => new Date(t + 9 * 3600e3).toISOString().slice(0, 10);
export const kstHourFrac = (t) => { const d = new Date(t + 9 * 3600e3); return d.getUTCHours() + d.getUTCMinutes() / 60; };
export const depositsToday = (deposits, prefix, now) => deposits.filter((d) => String(d.name || '').startsWith(prefix) && kstDay(Date.parse(d.createdAt)) === kstDay(now)).length;

// 주식 매수용으로 남겨 둘 현금. 검증된 매수 신호가 하나도 없으면(예금이 훨씬 유리하므로) 남기는 비율을 줄임
export function stockKeepOf({ cfg, balance, analysis }) {
  if (cfg.stocks.mode === 'off') return 0;
  let ratio = num(cfg.stocks.cashForStocks);
  if (analysis && num(analysis.signalsNow) === 0) ratio = Math.min(ratio, num(cfg.stocks.cashForStocksIdle ?? 0.1));
  return Math.max(0, balance - cfg.cashReserve) * ratio;
}

function stats(series, now, hours) {
  const from = now - hours * 3600e3;
  const w = series.filter(([t]) => t >= from);
  if (!w.length) return null;
  const px = w.map(([, p]) => p);
  const recent = series.filter(([t]) => t >= now - 30 * 60e3).map(([, p]) => p);
  return { hi: Math.max(...px), spanH: (now - w[0][0]) / 3600e3, recentLo: Math.min(...(recent.length ? recent : px)) };
}

// 보유 포지션: 프로그램이 낸(auto-) 체결 주문만 집계 -> 사용자가 직접 산 주식은 건드리지 않음
export function botPositions(orders) {
  const pos = {};
  for (const o of orders) {
    if (!String(o.request_key || '').startsWith('auto-')) continue;
    if (['pending', 'cancelled', 'rejected', 'failed', 'expired'].includes(o.status)) continue;
    const p = (pos[o.investment_id] ??= { shares: 0, cost: 0 });
    const sh = num(o.shares);
    if (o.side === 'buy') { p.shares += sh; p.cost += num(o.gross) + num(o.fee); }
    else { const avg = p.shares ? p.cost / p.shares : 0; p.shares -= sh; p.cost -= avg * sh; }
  }
  return pos;
}

// 즉시 체결 방식 이후: 프로그램이 직접 낸 주문 기록(ledger)으로 자동 매수분을 집계. 실제 보유량(held)을 넘지 않게 보정
export function botPositionsLedger(trades = [], held = {}) {
  const pos = {};
  for (const t of trades) {
    if (t.status !== 'filled') continue;
    const p = (pos[t.investmentId] ??= { shares: 0, cost: 0 });
    const sh = num(t.shares);
    if (t.side === 'buy') { if (p.shares <= 1e-9) p.since = t.t; p.shares += sh; p.cost += sh * num(t.price) * (1 + num(t.fee)); }
    else { const avg = p.shares ? p.cost / p.shares : 0; p.shares -= sh; p.cost -= avg * sh; }
  }
  for (const [id, p] of Object.entries(pos)) {
    const h = num(held[id]);
    if (p.shares > h) { p.cost = p.shares ? p.cost * (h / p.shares) : 0; p.shares = h; } // 직접 판 경우 등
    if (p.shares <= 1e-9) delete pos[id];
  }
  return pos;
}

// 현재 거래 가능한가(즉시 체결 방식): 거래 창이 열려 있고 정지가 아니어야 하며, 종목의 시세가 유효해야 함
export const rtOpen = (rt) => !rt || (rt.enabled !== false && !rt.paused && !!rt.open);
export const quoteOf = (rt, id) => (rt?.quotes || []).find((q) => q.investmentId === id);
export const quotePrice = (q) => num(q?.rawPrice) * (num(q?.multiplier) || 1);

export function planStocks({ cfg, user, investments, orders, prices, settings, sb, now, positions, analysis }) {
  const c = cfg.stocks, out = [];
  if (c.mode === 'off' || !sb?.enabled || sb.blocked || sb.policy?.paused || sb.classroomTradingEnabled === false) return out;
  const rt = sb.rt;
  if (rt && !rtOpen(rt)) return out;
  const fee = num(rt ? quoteOf(rt, investments[0]?.id)?.feeRate : 0) || num(settings?.stockTradingFeeRate) || 0.005;
  const roundTrip = fee * 2 * 100;
  const takeProfit = Math.max(c.takeProfitPct, roundTrip + 1.5); // 수수료 왕복분 + 최소 순이익
  const pos = positions || botPositions(orders);
  const pending = new Set(orders.filter((o) => o.status === 'pending').map((o) => o.investment_id));
  const byId = new Map(investments.map((i) => [i.id, i]));

  for (const [id, p] of Object.entries(pos)) {
    const inv = byId.get(Number(id));
    if (!inv || p.shares <= 0 || pending.has(Number(id)) || inv.tradingEnabled === false) continue;
    if (rt && !quoteOf(rt, inv.id)?.valid) continue; // 시세가 잠긴 종목은 거래 불가
    const net = unitPrice(inv) * p.shares * (1 - fee);
    const pnl = ((net - p.cost) / p.cost) * 100;
    const heldDays = p.since ? (now - p.since) / 86400e3 : 0;
    const timeUp = num(c.maxHoldDays) > 0 && heldDays >= num(c.maxHoldDays); // 검증한 보유 기간(5거래일)이 지나면 정리
    if (pnl >= takeProfit || pnl <= -c.stopLossPct || timeUp) {
      out.push({ key: `sell:${id}:${Math.round(pnl)}${timeUp ? ':t' : ''}`, kind: 'order', module: 'stocks', investmentId: inv.id, side: 'sell', shares: Math.floor(p.shares),
        desc: `${timeUp && pnl < takeProfit && pnl > -c.stopLossPct ? '기간 만료' : pnl >= 0 ? '익절' : '손절'} 매도: ${inv.name} ${Math.floor(p.shares)}주 (수수료 반영 ${pnl.toFixed(1)}%${timeUp ? ', 보유 ' + heldDays.toFixed(1) + '일' : ''})` });
    }
  }

  const posCount = Object.values(pos).filter((p) => p.shares > 0).length;
  if (posCount >= c.maxPositions) return out;
  const held = Object.entries(pos).reduce((s, [id, p]) => s + (byId.get(Number(id)) ? unitPrice(byId.get(Number(id))) * p.shares : 0), 0);
  const total = num(user.balance) + held;
  const pendingBuy = orders.filter((o) => o.status === 'pending' && o.side === 'buy').reduce((s, o) => s + orderCost(o), 0);
  let cash = num(user.balance) - cfg.cashReserve - pendingBuy;
  const cands = [];
  const useSig = c.useSignals !== false && !!analysis?.stocks && Object.keys(analysis.stocks).length > 0;
  for (const inv of investments) {
    if (inv.type !== 'stock' || inv.isActive === false || inv.tradingEnabled === false) continue;
    if (pending.has(inv.id) || pos[inv.id]?.shares > 0) continue;
    if (rt ? !quoteOf(rt, inv.id)?.valid : !sb.nextSessions?.[marketOf(inv)]) continue;
    const px = unitPrice(inv);
    if (useSig) {
      // 외부 시세 분석: 수수료를 뺀 과거 1년 백테스트를 통과한 규칙이 지금 켜진 종목만
      const sg = analysis.stocks[inv.id];
      if (sg?.passing?.length) cands.push({ inv, px, dip: num(sg.expectedNetPct), sig: sg });
      continue;
    }
    const s = stats(prices[inv.id] || [], now, c.lookbackHours);
    if (!s || s.spanH < c.minHistoryHours) continue;
    const dip = (1 - px / s.hi) * 100, bounce = (px / s.recentLo - 1) * 100;
    if (dip >= c.dipPct && bounce >= c.bouncePct) cands.push({ inv, px, dip });
  }
  cands.sort((a, b) => b.dip - a.dip);
  for (const { inv, px, dip, sig } of cands.slice(0, c.maxPositions - posCount)) {
    const budget = Math.min(cash, (total * c.maxPositionPct) / 100);
    const shares = Math.floor(budget / (px * (1 + fee)));
    if (shares < 1) continue;
    cash -= shares * px * (1 + fee);
    out.push({ key: `buy:${inv.id}:${Math.round(dip)}`, kind: 'order', module: 'stocks', investmentId: inv.id, side: 'buy', shares,
      desc: sig ? `매수: ${inv.name} ${shares}주 @${Math.round(px).toLocaleString()} (검증된 신호 ${sig.passing.join('+')}: 과거 1년 수수료 차감 평균 +${sig.expectedNetPct}%, 승률 ${sig.hitPct}%, ${sig.horizonDays}거래일 보유)` : `매수: ${inv.name} ${shares}주 @${Math.round(px).toLocaleString()} (고점 대비 -${dip.toFixed(1)}% 후 반등, 목표 +${takeProfit.toFixed(1)}% / 왕복 수수료 ${roundTrip.toFixed(1)}%)` });
  }
  return out;
}
