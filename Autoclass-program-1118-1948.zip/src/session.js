import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { chromium } from 'playwright-core';
import { DATA } from './config.js';
import { log } from './store.js';

export class AuthError extends Error {}

const PROFILE = path.join(DATA, 'profile');
const COOKIES = path.join(DATA, 'cookies.json'); // 로컬 전용 민감 파일. 공유 금지

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export class Session {
  constructor(getCfg) {
    this.getCfg = getCfg;
    this.ctx = null;
    this.page = null;
    this.headed = false;
  }

  // 이전 실행이 비정상 종료되면 이 프로필을 쓰는 브라우저가 남아 새 실행을 막으므로 먼저 정리
  killOrphans() {
    if (process.platform !== 'win32') return;
    try {
      execFileSync('powershell', ['-NoProfile', '-Command',
        `Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(chrome|msedge)\\.exe$' -and $_.CommandLine -like '*Autoclass*data*profile*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`],
        { windowsHide: true, timeout: 15000, stdio: 'ignore' });
    } catch {}
  }

  async open(headed = false) {
    await this.close();
    this.killOrphans();
    const cfg = this.getCfg();
    const opts = { headless: !(headed || cfg.showBrowser), viewport: { width: 1280, height: 800 } };
    let lastErr;
    for (const channel of ['chrome', 'msedge']) {
      try {
        this.ctx = await chromium.launchPersistentContext(PROFILE, { ...opts, channel });
        break;
      } catch (e) { lastErr = e; }
    }
    if (!this.ctx) throw lastErr;
    this.headed = headed || cfg.showBrowser;
    // 세션 쿠키는 브라우저를 닫으면 사라질 수 있어 따로 보관했다가 복원
    try {
      const saved = JSON.parse(fs.readFileSync(COOKIES, 'utf8'));
      const exp = Math.floor(Date.now() / 1000) + 30 * 86400;
      await this.ctx.addCookies(saved.map((c) => ({ ...c, expires: c.expires > 0 ? c.expires : exp })));
    } catch {}
    this.page = this.ctx.pages()[0] || (await this.ctx.newPage());
    await this.page.goto(cfg.site, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  }

  async close() {
    if (this.ctx) { await this.saveCookies(); await this.ctx.close().catch(() => {}); }
    this.ctx = this.page = null;
  }

  async saveCookies() {
    try {
      const all = await this.ctx.cookies(this.getCfg().site);
      if (all.length) fs.writeFileSync(COOKIES, JSON.stringify(all));
    } catch {}
  }

  async request(method, p, body) {
    if (!this.ctx) await this.open();
    const url = this.getCfg().site + p;
    let status, text;
    if (this.getCfg().transport === 'page') {
      const r = await this.page.evaluate(async ({ url, method, body }) => {
        const res = await fetch(url, {
          method, credentials: 'include',
          headers: body !== undefined ? { 'content-type': 'application/json' } : {},
          body: body !== undefined ? JSON.stringify(body) : undefined,
        });
        return { status: res.status, text: await res.text() };
      }, { url, method, body });
      ({ status, text } = r);
    } else {
      const res = await this.ctx.request.fetch(url, {
        method, timeout: 30000, maxRedirects: 0,
        headers: body !== undefined ? { 'content-type': 'application/json' } : {},
        data: body !== undefined ? JSON.stringify(body) : undefined,
      });
      status = res.status();
      text = await res.text();
    }
    if (status === 401 || status === 403 || (status >= 300 && status < 400)) throw new AuthError(`HTTP ${status} ${p}`);
    let json = null;
    try { json = JSON.parse(text); } catch {}
    if (json === null && p.startsWith('/api/') && /<html/i.test(text.slice(0, 300))) throw new AuthError(`HTML 응답 ${p}`);
    return { status, json, text };
  }

  // 사용자가 직접 로그인할 수 있게 창을 띄우고 로그인 완료를 기다림 (비밀번호는 이 프로그램이 다루지 않음)
  // 환경변수(ECONOMY_USERNAME / ECONOMY_PASSWORD)가 있으면 창 없이 자동 재로그인. 비밀번호는 이 프로그램이 저장·기록하지 않음
  async autoLogin() {
    const username = process.env.ECONOMY_USERNAME, password = process.env.ECONOMY_PASSWORD;
    if (!username || !password) return false;
    try {
      if (!this.ctx) await this.open(false);
      const r = await this.ctx.request.post(this.getCfg().site + '/api/login/local', { data: { username, password }, headers: { 'content-type': 'application/json' }, timeout: 30000 });
      if (r.ok()) { await this.saveCookies(); log('auth', '자동 로그인 성공'); return true; }
      log('auth', `자동 로그인 실패 (HTTP ${r.status()}) — 아이디/비밀번호를 확인하세요`);
    } catch (e) { log('auth', '자동 로그인 오류: ' + String(e.message).slice(0, 120)); }
    return false;
  }

  async interactiveLogin(timeoutMin = 20) {
    if (await this.autoLogin()) return true;
    log('auth', '로그인 창을 엽니다. 직접 로그인해 주세요.');
    await this.open(true);
    const end = Date.now() + timeoutMin * 60_000;
    while (Date.now() < end) {
      await sleep(3000);
      try {
        const r = await this.page.evaluate(async () => (await fetch('/api/auth/user', { credentials: 'include' })).status);
        if (r === 200) {
          log('auth', '로그인 확인됨');
          await this.saveCookies();
          await this.open(false);
          return true;
        }
      } catch {}
    }
    await this.open(false);
    return false;
  }
}

// ─────────────────────────────────────────────────────────────
// 클라우드(서버)용: 브라우저 없이 HTTP 로 직접 접속. 쿠키는 파일(DATA/cookies.json)에 보관하고,
// 세션이 풀리면 환경변수(ECONOMY_USERNAME / ECONOMY_PASSWORD)로 자동 재로그인한다. 비밀번호는 코드·파일에 저장하지 않음.
// ─────────────────────────────────────────────────────────────
export class HttpSession {
  constructor(getCfg) { this.getCfg = getCfg; this.jar = new Map(); this.loginP = null; this.headed = false; }

  async open() {
    try { for (const c of JSON.parse(fs.readFileSync(COOKIES, 'utf8'))) this.jar.set(c.name, c.value); } catch {}
  }
  async close() { await this.saveCookies(); }
  async saveCookies() {
    try {
      const host = new URL(this.getCfg().site).hostname;
      fs.writeFileSync(COOKIES, JSON.stringify([...this.jar].map(([name, value]) => ({ name, value, domain: host, path: '/', expires: -1, httpOnly: true, secure: true, sameSite: 'Lax' }))));
    } catch {}
  }
  cookieHeader() { return [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '); }
  absorb(res) {
    const list = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
    for (const sc of list) {
      const [pair, ...attrs] = sc.split(';').map((s) => s.trim());
      const i = pair.indexOf('='); if (i < 1) continue;
      const name = pair.slice(0, i), value = pair.slice(i + 1);
      const expired = attrs.some((a) => /^max-age=0$/i.test(a)) || attrs.some((a) => /^expires=/i.test(a) && Date.parse(a.slice(8)) < Date.now());
      if (expired || value === '') this.jar.delete(name); else this.jar.set(name, value);
    }
  }
  async rawFetch(method, p, body) {
    const res = await fetch(this.getCfg().site + p, {
      method, redirect: 'manual', signal: AbortSignal.timeout(30000),
      headers: { cookie: this.cookieHeader(), 'user-agent': 'Mozilla/5.0 (compatible; AutoclassCloud/1.0)', ...(body !== undefined ? { 'content-type': 'application/json' } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    this.absorb(res);
    return { status: res.status, text: await res.text() };
  }
  async login() {
    if (this.loginP) return this.loginP;
    this.loginP = (async () => {
      const username = process.env.ECONOMY_USERNAME, password = process.env.ECONOMY_PASSWORD;
      if (!username || !password) throw new AuthError('로그인 정보가 없습니다 (ECONOMY_USERNAME / ECONOMY_PASSWORD 환경변수)');
      this.jar.delete('connect.sid');
      const r = await this.rawFetch('POST', '/api/login/local', { username, password });
      if (r.status >= 300) throw new AuthError(`자동 로그인 실패 (HTTP ${r.status}) — 아이디/비밀번호가 바뀌었는지 확인하세요`);
      await this.saveCookies();
      log('auth', '자동 로그인 성공(클라우드)');
    })().finally(() => { this.loginP = null; });
    return this.loginP;
  }
  async interactiveLogin() { try { await this.login(); return true; } catch (e) { log('auth', String(e.message)); return false; } }

  async request(method, p, body) {
    let r = await this.rawFetch(method, p, body);
    if ((r.status === 401 || (r.status >= 300 && r.status < 400)) && p !== '/api/login/local') {
      if (process.env.ECONOMY_USERNAME && process.env.ECONOMY_PASSWORD && !/^\/api\/(login|logout)/.test(p)) {
        await this.login();
        r = await this.rawFetch(method, p, body);
      }
    }
    const { status, text } = r;
    if (status === 401 || (status >= 300 && status < 400)) throw new AuthError(`HTTP ${status} ${p}`);
    // 403 은 로그아웃이 아니라 권한 없음(예: 급식 관리 직업이 아닐 때 /api/meals) — 재로그인하지 않고 일반 오류로 처리
    if (status === 403) throw new Error(`HTTP 403 ${p} 권한 없음 ${text.slice(0, 80)}`);
    let json = null; try { json = JSON.parse(text); } catch {}
    if (json === null && p.startsWith('/api/') && /<html/i.test(text.slice(0, 300))) throw new AuthError(`HTML 응답 ${p}`);
    return { status, json, text };
  }
}
