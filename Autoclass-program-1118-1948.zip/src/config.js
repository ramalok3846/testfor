import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// 클라우드(서버) 실행: AUTOCLASS_MODE=cloud, 데이터 폴더는 AUTOCLASS_DATA(볼륨), 포트는 PORT
export const CLOUD = process.env.AUTOCLASS_MODE === 'cloud';
export const DATA = process.env.AUTOCLASS_DATA ? path.resolve(process.env.AUTOCLASS_DATA) : path.join(ROOT, 'data');
fs.mkdirSync(DATA, { recursive: true });

export const DEFAULTS = {
  site: 'https://economyclass-t.replit.app',
  port: 7788,
  pollSeconds: 60,
  // api: 브라우저 쿠키로 직접 API 호출(기본, 가장 가벼움)
  // page: 실제 페이지 안에서 fetch(확장 프로그램처럼 페이지 컨텍스트 사용)
  transport: 'api',
  showBrowser: false,
  paused: false,
  botPrefix: 'auto-',          // 프로그램이 만든 예금 이름 접두사. 이 접두사가 있는 것만 자동 관리
  maxAutoActionsPerDay: 10,    // 하루 자동 실행 상한(안전장치)
  // 같은 계정을 여러 곳(내 PC + 클라우드)에서 돌릴 때 중복 거래 방지: primary=실행함, monitor=감시·알림만(자동 실행 안 함)
  role: 'primary',
  // 휴대폰·다른 기기 접속(기본 꺼짐). 켜면 '접속 링크'로 한 번 로그인한 기기만 열 수 있음. listen: localhost(터널/Tailscale용) | all(같은 와이파이 직접 접속, 재시작 필요)
  remote: { enabled: false, listen: 'localhost', tokenHash: '', tokenAt: null },
  cashReserve: 0,             // 항상 현금으로 남겨둘 금액
  deposits: {
    mode: 'auto',              // off | advice(제안만) | auto
    minAmount: 1000,
    cooldownMinutes: 60,
    maxPerDay: 2,              // 하루에 새로 넣는 예금 개수 상한(쪼개 넣으면 불리할 수 있어 묶어서 넣음)
    batchMinAmount: 10000,     // 이 금액 이상 모였을 때 바로 가입(그 전에는 모아 둠)
    flushHour: 14.5,           // 한국시간 이 시각(14.5=오후 2:30) 이후엔 그날 모인 돈을 마지막으로 묶어 가입
    collectMatured: true,      // 프로그램이 만든 예금의 만기 수령
  },
  stocks: {
    mode: 'advice',            // off | advice | auto
    lookbackHours: 48,
    minHistoryHours: 6,
    dipPct: 4,                 // 최근 고점 대비 이만큼 빠졌을 때 매수 후보
    bouncePct: 0.5,            // 최근 저점에서 이만큼 반등 확인
    takeProfitPct: 4,          // 수수료 왕복분을 넘겨야 의미 있음(자동 보정)
    stopLossPct: 6,
    maxPositionPct: 25,        // 총자산 대비 한 종목 최대 비중
    maxPositions: 3,
    cashForStocks: 0.5,
    cashForStocksIdle: 0.1,    // 검증된 매수 신호가 하나도 없을 때 주식용으로 남길 현금 비율(예금이 훨씬 유리하므로 줄임)
    useSignals: true,          // 외부 시세로 수수료 차감 백테스트를 통과한 신호가 켜진 종목만 매수
    requireSignal: true,       // AI 제안도 검증된 신호가 있어야 통과(끄면 AI 판단만으로 매수 가능)
    maxHoldDays: 7,            // 이 날짜가 지나면 매도해서 현금 회수(백테스트 보유 기간 5거래일)        // 예금에 넣지 않고 남겨둘 현금 비율(0~1)
  },
  ai: {
    mode: 'advice',            // off | advice | auto  (AI가 판단 → 아래 예금/주식 모드에 따라 제안 또는 실행)
    provider: 'claude-cli',    // claude-cli(내 Claude 로그인 사용) | api(ANTHROPIC_API_KEY 환경변수)
    model: '',
    intervalMinutes: 60,
    preSessionMinutes: 90,     // 거래 회차 이만큼 전에 추가로 판단
    timeoutSec: 180,
    autoRelogin: true,         // Claude 로그인이 풀리면 로그인 창을 자동으로 열기(6시간에 한 번)
    reconsiderHours: 24,       // 프로그램이 넣은 예금을 이 시간 이내에는 AI가 해지·재고려할 수 있음(0이면 끔). 가입 직후라 손해가 거의 없음
  },
  job: { mode: 'advice', remind: true, remindHour: 13 }, // mode: advice=제안·알림, auto=급식 기록이 전부 입력된 날만 완료 체크 자동 실행. // 한국시간 기준 이 시각 이후에도 오늘 직업 체크가 안 됐으면 매시간 알림
  // 절전 방지: off | system(화면은 꺼져도 되지만 PC는 잠들지 않음) | display(화면도 켜 둠). 노트북 덮개를 닫으면 윈도우 설정에 따라 잠들 수 있음
  system: { keepAwake: 'off' },
  analysis: { enabled: true, refreshHours: 6 }, // 외부 시세(Yahoo) 분석·백테스트 갱신 주기
  selfTest: { enabled: true, intervalMinutes: 360 }, // 전체 회귀 점검(읽기 전용) 주기
  store: { mode: 'advice', wishlist: [] }, // 상점은 자동 구매 없음. wishlist(아이템 id) 재입고/가격인하 알림만 // 상점은 절대 자동 구매하지 않음. 변경 알림만
  notify: {
    master: true,                       // 전체 알림 on/off
    quiet: { enabled: false, from: '23:00', to: '07:00', allowUrgent: true }, // 조용한 시간: 소리를 끔(긴급 알림은 예외 허용)
    phoneUrl: '',                       // 폰 알림 링크(선택). Discord·Slack·ntfy 링크를 붙여 넣으면 자동 인식
    // 종류별: popup=자체 알림창, system=윈도우 알림센터, phone=폰 링크, sound=none|default|soft|alert
    events: {
      login_lost:   { popup: true,  system: true,  phone: true,  sound: 'alert' },
      error:        { popup: true,  system: false, phone: true,  sound: 'alert' },
      job:          { popup: true,  system: true,  phone: true,  sound: 'default' },
      matured:      { popup: true,  system: false, phone: false, sound: 'soft' },
      order:        { popup: true,  system: false, phone: false, sound: 'soft' },
      advice:       { popup: true,  system: false, phone: false, sound: 'soft' },
      site_changed: { popup: true,  system: true,  phone: true,  sound: 'default' },
      store:        { popup: true,  system: false, phone: false, sound: 'none' },
      action:       { popup: true,  system: false, phone: false, sound: 'none' },
      system:       { popup: false, system: false, phone: true,  sound: 'none' },
    },
  },
};

const file = path.join(DATA, 'config.json');
const merge = (a, b) => {
  const out = Array.isArray(a) ? [...a] : { ...a };
  for (const [k, v] of Object.entries(b || {})) {
    out[k] = v && typeof v === 'object' && !Array.isArray(v) && a && typeof a[k] === 'object' ? merge(a[k], v) : v;
  }
  return out;
};

// 클라우드 기본값: 창·윈도우 알림이 없으므로 폰(ntfy) 알림 중심, 브라우저 없이 API로만 접속
const CLOUD_DEFAULTS = {
  transport: 'api',
  notify: { events: Object.fromEntries(['login_lost', 'error', 'job', 'matured', 'order', 'advice', 'site_changed', 'action', 'system', 'store'].map((k) => [k, { popup: false, system: false, phone: k !== 'store', sound: 'none' }])) },
};
export function loadConfig() {
  let cfg;
  try { cfg = merge(DEFAULTS, JSON.parse(fs.readFileSync(file, 'utf8'))); }
  catch { cfg = merge(DEFAULTS, CLOUD ? CLOUD_DEFAULTS : {}); }
  if (CLOUD) {
    if (process.env.PORT) cfg.port = Number(process.env.PORT);
    if (process.env.PHONE_URL && !cfg.notify.phoneUrl) cfg.notify.phoneUrl = process.env.PHONE_URL;
  }
  return cfg;
}
export function saveConfig(cfg) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2));
  fs.renameSync(tmp, file);
}
export { merge };
