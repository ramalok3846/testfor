import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { DATA } from './config.js';
import { log } from './store.js';
import { unitPrice, marketOf, stockKeepOf, depositsToday } from './strategy.js';

const SANDBOX = path.join(DATA, 'ai');
fs.mkdirSync(SANDBOX, { recursive: true });
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };

const SYSTEM = `당신은 학교 "경제교실" 시뮬레이션(가상 화폐, 실제 돈 아님)에서 한 학생의 자산 운용을 돕는 분석가입니다.
목표: 장기적으로 총자산을 가장 효율적으로 늘리되 손실을 제한. 판단 근거는 반드시 숫자(수수료, 이자율, 기간, 가격 변동, 주문 마감/체결 시각)로 설명.
규칙:
- 주식 수수료는 매수·매도 각각 부과된다. 왕복 수수료보다 기대 수익이 충분히 크지 않으면 매매하지 말고 보유/예금/현금 유지를 택한다.
- 주식은 이제 "즉시 체결"이다. 거래 가능 시간(평일 한국시간 08:00-08:50, 09:30-09:40, 10:20-10:40, 11:20-11:30, 13:00-13:50, 14:30-15:00)에만 주문할 수 있고, 주문하면 그 순간의 최신 시세로 바로 체결되거나 취소된다. 거래 시간이 아니면 어떤 주문도 낼 수 없다(trading.open 이 false).
- 예금은 기간 중 해지하면 이자가 없다. 현금 필요(주식 매수 예정)와 비교해 판단한다.
- 종목마다 시세가 "유효(tradable=true)"일 때만 거래할 수 있다. 국내 종목은 장중 실시간 시세라 거래 시간에 대부분 유효하고, 미국 종목은 한국 낮에는 미국 장이 닫혀 있어 시세가 "지연(delayed)"으로 잠기는 경우가 많다. 잠긴 종목은 제안하지 않는다.
- 거래 창은 짧다(10분~50분). 거래 창 밖에는 행동을 제안해도 실행되지 않으므로, 창이 열려 있을 때의 가격 흐름·수수료를 근거로 판단하고, 창이 닫혀 있으면 다음 창(nextOpenAt) 전망을 watch 에 적는다.
- 미국 장 마감 결과는 한국 장 시작 전에 알려지므로, 국내 종목 판단의 참고 신호로 쓸 수 있다(예: 같은 업종 미국 종목의 밤사이 등락). 실제로 알 수 없는 미래 가격을 아는 것처럼 쓰지 않는다.
- 투자도 매번 진지하게 검토한다. 거래 창이 열려 있고 시세가 유효한 종목 중에서, 예금 대안(7일 3%, 30일 10%)과 왕복 수수료를 뺀 뒤에도 기대수익이 더 큰 후보가 있는지 따져 본다. 후보가 있으면 expectedGainPct·horizonDays 와 함께 order 를 제안한다. 단기 등락 ±1~2%만으로는 근거가 아니며, 추세·반등·업종·미국 장 결과 같은 숫자 근거가 있어야 한다. 근거가 없으면 그 이유(어떤 숫자가 부족한지)를 summary 에 쓴다.
- 예금은 이자가 확정이라 안전하지만 현금이 묶인다. 현금을 전부 예금에 넣지 말고, 주식 기회를 위해 cashForStocksRatio 만큼은 남겨 두는 것을 기본으로 한다.
- 프로그램이 넣은 예금 중 freeToCancel=true(가입 후 24시간 이내)인 것은 해지해도 잃는 이자가 사실상 없다. 더 나은 주식 기회가 있을 때만 {"kind":"terminate","depositId":숫자,"why":"..."} 로 먼저 해지하고, 이어서 order 를 제안한다. freeToCancel=false 인 예금은 절대 해지하지 않는다.
- externalAnalysis 는 외부 시세(야후)로 과거 1년 일봉을 받아 수수료를 뺀 뒤 백테스트한 결과다. passed=true 인 규칙만 신뢰할 수 있는 근거이고, 종목의 ext.verifiedSignal 이 비어 있으면 그 종목은 매수하지 않는다(통과 규칙이 하나도 없으면 오늘은 매수할 근거가 없다고 솔직하게 쓴다). 기대수익은 expectedNetPct(수수료 차감 후, 보유 5거래일)를 넘겨 쓰지 않는다. 코스피·S&P500 같은 지수 흐름(indices)도 함께 보고 시장이 약세일 때는 더 보수적으로 판단한다.
- 예금은 하루에 새로 넣는 개수를 maxNewDepositsPerDay(기본 2개) 이하로 유지한다(쪼개 넣으면 불리할 수 있음). 현금이 조금씩 들어오면 모아 두었다가 한 번에 묶어서 넣는다. depositsCreatedToday 가 한도에 닿으면 오늘은 더 넣지 않는다.
- 배당(dividend): 취득한 지 168시간(7일) 이상 보유한 주식만 기준 시각(nextAt)에 원가의 ratePct%를 받는다. 예) 2% 배당 − 왕복 수수료 1% = 순 +1% 정도라서 7일 3%·30일 10% 예금보다 불리하다. 배당만으로는 매수 근거가 안 되고, 검증된 신호가 있을 때 보너스로만 고려한다.
- 상점 구매는 절대 제안하지 않는다.
- summary·forecast·watch 는 학생이 읽는 글이다. tradingBlocked 같은 영어 필드명이나 따옴표 코드를 쓰지 말고 쉬운 한국어로 쓴다.
- 근거가 약하면 아무 행동도 하지 않는 것이 정답이다. 억지로 행동을 만들지 않는다.
- 학생이 직접 만든 예금/보유 주식은 건드리지 않는다(auto 로 표시된 것만 관리 대상).
출력은 아래 JSON 한 개만, 다른 텍스트 없이:
{"summary":"현재 판단 2~4문장","forecast":"다음 거래 창 전망 1~3문장","confidence":0~1,
 "actions":[{"kind":"deposit","productId":숫자,"amount":숫자,"why":"..."},
            {"kind":"order","investmentId":숫자,"side":"buy|sell","shares":정수,"why":"...","expectedGainPct":숫자,"horizonDays":숫자},
            {"kind":"terminate","depositId":숫자,"why":"..."}],
 "watch":["다음에 확인할 점"]}`;

function stockView(inv, series, now) {
  const px = unitPrice(inv);
  const at = (h) => { const t = now - h * 3600e3; const p = (series || []).filter(([x]) => x <= t).pop(); return p ? +(((px / p[1]) - 1) * 100).toFixed(2) : null; };
  const w = (series || []).filter(([x]) => x >= now - 48 * 3600e3).map(([, p]) => p);
  return { id: inv.id, name: inv.name, market: marketOf(inv), price: Math.round(px), dayChangePct: num(inv.changePercent),
    chg1h: at(1), chg6h: at(6), chg24h: at(24), hi48: w.length ? Math.round(Math.max(...w)) : null, lo48: w.length ? Math.round(Math.min(...w)) : null,
    historyHours: series?.length ? +(((now - series[0][0]) / 3600e3)).toFixed(1) : 0, tradable: inv.tradingEnabled !== false && inv.isActive !== false };
}

export function buildContext({ cfg, snap, prices, positions, fee, now }) {
  const stocks = snap.investments.filter((i) => i.type === 'stock').map((i) => {
    const v = stockView(i, prices[i.id], now), q = snap.rt?.quotes?.[i.id], an = snap.analysis?.stocks?.[i.id];
    if (q) { v.tradable = v.tradable && !!q.valid; v.quote = q.displayStatus; }
    if (an) v.ext = { ret1: an.ret1, ret5: an.ret5, ret20: an.ret20, rsi: an.rsi, vsSma50: an.distSma50, firing: an.firing, verifiedSignal: an.passing, expectedNetPct: an.expectedNetPct, hitPct: an.hitPct };
    return v;
  });
  return {
    nowKST: new Date(now + 9 * 3600e3).toISOString().replace('Z', ' KST'),
    cash: snap.user.balance, cashReserve: cfg.cashReserve,
    feeRatePerSide: fee, roundTripFeePct: +(fee * 200).toFixed(2),
    trading: snap.rt ? { open: snap.rt.open, enabled: snap.rt.enabled, paused: snap.rt.paused, nextOpenAt: snap.rt.nextOpenAt, windowsToday: snap.rt.windowsToday } : { open: false }, tradingBlocked: !!(snap.sb.blocked || snap.sb.paused),
    deposits: snap.deposits.filter((d) => !d.isEarlyTerminated).map((d) => ({ id: d.id, product: d.productName, principal: num(d.principal), ratePct: num(d.interestRate), matures: d.maturityDate, auto: String(d.name).startsWith(cfg.botPrefix),
      ageHours: +(((now - Date.parse(d.createdAt)) / 3600e3)).toFixed(1),
      freeToCancel: String(d.name).startsWith(cfg.botPrefix) && (now - Date.parse(d.createdAt)) / 3600e3 <= num(cfg.ai.reconsiderHours ?? 24) && Date.parse(d.maturityDate) > now })),
    cashForStocksRatio: cfg.stocks.cashForStocks,
    depositsCreatedToday: depositsToday(snap.deposits, cfg.botPrefix, now), maxNewDepositsPerDay: cfg.deposits.maxPerDay ?? 2,
    dividend: snap.dividend || null,
    externalAnalysis: snap.analysis ? { asOf: snap.analysis.at, roundTripFeePct: snap.analysis.roundTripPct, indices: snap.analysis.indices, rulesBacktest1y: snap.analysis.rules.map((r) => ({ id: r.id, label: r.label, samples: r.n, meanNetPct: r.meanNetPct, hitPct: r.hitPct, t: r.t, passed: r.pass })), verifiedSignalsNow: snap.analysis.signalsNow } : null,
    products: snap.products.filter((p) => p.isActive !== false).map((p) => ({ id: p.id, name: p.name, ratePct: num(p.interestRate), termDays: p.termDays, min: p.minDeposit, max: p.maxDeposit })),
    autoPositions: Object.entries(positions).filter(([, p]) => p.shares > 0).map(([id, p]) => ({ investmentId: +id, shares: p.shares, avgCostPerShare: Math.round(p.cost / p.shares) })),
    pendingOrders: snap.orders.filter((o) => o.status === 'pending').map((o) => ({ id: o.id, investmentId: o.investment_id, side: o.side, shares: num(o.shares) })),
    stocks,
    limits: { maxPositionPct: cfg.stocks.maxPositionPct, maxPositions: cfg.stocks.maxPositions, stocksMode: cfg.stocks.mode, depositsMode: cfg.deposits.mode },
  };
}

export function callClaude(prompt, cfg) {
  return new Promise((resolve, reject) => {
    const args = ['-p', '--output-format', 'json', '--tools', '', '--no-session-persistence', '--append-system-prompt', SYSTEM];
    if (cfg.ai.model) args.push('--model', cfg.ai.model);
    const p = spawn('claude', args, { cwd: SANDBOX, shell: true, windowsHide: true });
    let out = '', err = '';
    const timer = setTimeout(() => { p.kill(); reject(new Error('AI 응답 시간 초과')); }, (cfg.ai.timeoutSec || 180) * 1000);
    p.stdout.on('data', (d) => (out += d));
    p.stderr.on('data', (d) => (err += d));
    p.on('error', reject);
    p.on('close', () => {
      clearTimeout(timer);
      try {
        const j = JSON.parse(out);
        if (j.is_error) return reject(new Error('AI 오류: ' + String(j.result).slice(0, 200)));
        resolve(String(j.result));
      } catch { reject(new Error('AI 출력 해석 실패: ' + (err || out).slice(0, 200))); }
    });
    p.stdin.end(prompt);
  });
}

export async function callApi(prompt, cfg) {
  const key = process.env.ANTHROPIC_API_KEY || cfg.ai.apiKey;
  if (!key) throw new Error('ANTHROPIC_API_KEY 없음');
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: cfg.ai.model || 'claude-sonnet-5-5', max_tokens: 2000, system: SYSTEM, messages: [{ role: 'user', content: prompt }] }),
  });
  const j = await r.json();
  if (!r.ok) throw new Error('API 오류 ' + r.status + ' ' + JSON.stringify(j).slice(0, 200));
  return j.content.map((c) => c.text || '').join('');
}

export function parseDecision(text) {
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) throw new Error('JSON 없음');
  const d = JSON.parse(m[0]);
  if (!d.summary) throw new Error('AI 응답에 summary 없음(형식 위반)');
  return { summary: String(d.summary), forecast: String(d.forecast || ''), confidence: Math.min(1, Math.max(0, num(d.confidence))),
    actions: (Array.isArray(d.actions) ? d.actions : []).map((a) => ({ ...a, kind: a.kind ?? a.type })), watch: Array.isArray(d.watch) ? d.watch.map(String) : [] };
}

// AI 제안은 반드시 하드 규칙을 통과해야 함(수수료 게이트, 한도, 거래 가능 여부, 현금)
export function validate(decision, { cfg, snap, positions, fee, analysis }) {
  const out = [], rejected = [];
  const byId = new Map(snap.investments.map((i) => [i.id, i]));
  const prodById = new Map(snap.products.map((p) => [p.id, p]));
  let cash = snap.user.balance - cfg.cashReserve
    - snap.orders.filter((o) => o.status === 'pending' && o.side === 'buy').reduce((s, o) => s + num(o.raw_price) * (num(o.multiplier) || 1) * num(o.shares), 0);
  const held = Object.entries(positions).reduce((s, [id, p]) => s + (byId.get(+id) ? unitPrice(byId.get(+id)) * p.shares : 0), 0);
  const total = snap.user.balance + held;
  const pending = new Set(snap.orders.filter((o) => o.status === 'pending').map((o) => o.investment_id));
  const roundTrip = fee * 200;
  const nOpen = Object.values(positions).filter((p) => p.shares > 0).length;
  let opened = 0;
  // 주식 매수용으로 남겨 둘 현금(예금에 다 넣어 버려 투자 기회를 놓치지 않게)
  const stockKeep = stockKeepOf({ cfg, balance: snap.user.balance, analysis });
  const maxDep = num(cfg.deposits.maxPerDay ?? 2) || 2;
  let depToday = depositsToday(snap.deposits, cfg.botPrefix, Date.now());
  const reconH = num(cfg.ai.reconsiderHours ?? 24);

  for (const a of decision.actions.slice(0, 6)) {
    const rej = (why) => rejected.push({ action: a, why });
    if (a.kind === 'terminate') {
      // 최근(기본 24시간 이내)에 프로그램이 넣은 예금만 해지 가능 — 가입 직후라 잃는 이자가 사실상 없음
      const d = snap.deposits.find((x) => x.id === Number(a.depositId));
      if (cfg.deposits.mode === 'off') { rej('예금 모드 off'); continue; }
      if (!d || d.isEarlyTerminated) { rej('없는 예금'); continue; }
      if (!String(d.name).startsWith(cfg.botPrefix)) { rej('직접 만든 예금은 해지하지 않음'); continue; }
      const age = (Date.now() - Date.parse(d.createdAt)) / 3600e3;
      if (!(reconH > 0) || age > reconH) { rej(`가입 후 ${age.toFixed(0)}시간 지남 (재고려 허용 ${reconH}시간 이내)`); continue; }
      if (d.isMatured || Date.parse(d.maturityDate) <= Date.now()) { rej('이미 만기'); continue; }
      cash += num(d.principal);
      out.push({ key: `ai-terminate:${d.id}`, kind: 'collect', module: 'deposits', id: d.id, ai: true, early: true,
        desc: `[AI] 방금 넣은 예금 해지(재고려): ${d.productName} ${num(d.principal).toLocaleString()}원 — ${a.why || ''}` });
    } else if (a.kind === 'deposit') {
      const p = prodById.get(Number(a.productId));
      const amount = Math.floor(num(a.amount));
      if (cfg.deposits.mode === 'off') { rej('예금 모드 off'); continue; }
      if (!p || p.isActive === false) { rej('없는 상품'); continue; }
      if (amount < cfg.deposits.minAmount || amount > cash || (num(p.minDeposit) && amount < num(p.minDeposit)) || (num(p.maxDeposit) && amount > num(p.maxDeposit))) { rej('금액 범위 위반'); continue; }
      if (amount > cash - stockKeep) { rej(`주식 매수용으로 남겨 둔 현금(${Math.round(stockKeep).toLocaleString()}원)을 침범`); continue; }
      if (depToday >= maxDep) { rej(`오늘 새 예금 ${depToday}개 — 하루 ${maxDep}개 한도(여러 개로 쪼개 넣지 않고 묶어서 넣어요)`); continue; }
      depToday++;
      cash -= amount;
      out.push({ key: `ai-deposit:${p.id}:${amount}`, kind: 'deposit', module: 'deposits', productId: p.id, amount, ai: true,
        desc: `[AI] 예금 가입: ${p.name} ${amount.toLocaleString()}원 — ${a.why || ''}` });
    } else if (a.kind === 'order') {
      const inv = byId.get(Number(a.investmentId));
      const shares = Math.floor(num(a.shares));
      const side = a.side === 'sell' ? 'sell' : 'buy';
      if (cfg.stocks.mode === 'off') { rej('주식 모드 off'); continue; }
      if (!inv || inv.type !== 'stock' || inv.tradingEnabled === false || inv.isActive === false) { rej('거래 불가 종목'); continue; }
      if (snap.sb.blocked || snap.sb.paused || (snap.rt ? !snap.rt.open || !snap.rt.quotes?.[inv.id]?.valid : !snap.sb.nextSessions?.[marketOf(inv)])) { rej('거래 시간이 아니거나 시세가 잠김'); continue; }
      if (shares < 1 || pending.has(inv.id)) { rej('수량/대기주문'); continue; }
      const px = unitPrice(inv);
      if (side === 'buy') {
        // 외부 시세 분석이 있으면: 수수료를 뺀 과거 1년 백테스트를 통과한 규칙이 지금 켜진 종목만 매수 허용(기대수익은 이미 수수료 차감값)
        const sigMode = cfg.stocks.requireSignal !== false && analysis?.stocks && Object.keys(analysis.stocks).length > 0;
        if (sigMode) {
          const sg = analysis.stocks[inv.id];
          if (!sg?.passing?.length) { rej('검증된 매수 신호 없음 (수수료 차감 백테스트를 통과한 규칙이 이 종목에서 켜지지 않음)'); continue; }
        } else {
          const gain = num(a.expectedGainPct);
          if (gain < roundTrip + 1.5) { rej(`기대수익 ${gain}% < 왕복수수료 ${roundTrip.toFixed(1)}% + 1.5%`); continue; }
        }
        if (positions[inv.id]?.shares > 0) { rej('이미 보유'); continue; }
        if (nOpen + opened >= cfg.stocks.maxPositions) { rej('최대 보유 종목 초과'); continue; }
        const cost = shares * px * (1 + fee);
        if (cost > cash || cost > (total * cfg.stocks.maxPositionPct) / 100) { rej('현금/비중 한도 초과'); continue; }
        cash -= cost; opened++;
      } else {
        const own = positions[inv.id]?.shares || 0; // AI는 자동 매수분만 매도 가능
        if (shares > own) { rej('자동 보유분 초과 매도'); continue; }
        const p = positions[inv.id];
        const pnl = ((px * shares * (1 - fee)) / (p.cost * (shares / p.shares)) - 1) * 100;
        if (pnl < 0 && pnl > -cfg.stocks.stopLossPct && !/손절|stop/i.test(a.why || '')) { rej(`손실 ${pnl.toFixed(1)}% 구간 매도는 손절 사유 필요`); continue; }
      }
      out.push({ key: `ai-order:${side}:${inv.id}:${shares}`, kind: 'order', module: 'stocks', investmentId: inv.id, side, shares, ai: true,
        desc: `[AI] ${side === 'buy' ? '매수' : '매도'}: ${inv.name} ${shares}주 @${Math.round(px).toLocaleString()} — ${a.why || ''}` });
    } else rej('허용되지 않은 kind');
  }
  return { actions: out, rejected };
}

export async function think(ctxData, cfg) {
  const prompt = `${SYSTEM}\n\n현재 상태(JSON):\n${JSON.stringify(ctxData)}\n\n위 규칙에 따라 판단하고, 반드시 위 출력 형식(summary, forecast, confidence, actions[kind 키 사용], watch)의 JSON 한 개만 답하세요. summary와 forecast는 비우지 말고 숫자 근거를 넣으세요.`;
  const text = cfg.ai.provider === 'api' ? await callApi(prompt, cfg) : await callClaude(prompt, cfg);
  log('ai', 'AI 응답 수신 ' + text.length + '자');
  return parseDecision(text);
}
