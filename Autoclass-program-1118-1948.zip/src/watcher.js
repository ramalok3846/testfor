// 사이트 변경 감시: 수수료/상품/이자/상점/번들 변화를 기준선과 비교
export function fingerprint({ settings, products, items, sb, bundle, investments, rt, jobs }) {
  const keys = (a) => Object.keys((a || [])[0] || {}).sort().join(',');
  return {
    bundle,
    // 실시간 거래: open 은 거래 창마다 바뀌므로 비교하지 않음. 설정·거래 창 시간표·응답 형식만 비교
    rt: { enabled: rt?.enabled, paused: rt?.paused, windows: (rt?.windows || []).map((w) => `${w.weekday}${w.start}${w.end}`).join(','), keys: Object.keys(rt || {}).sort().join(','), quoteKeys: keys(rt?.quotes), retired: sb?.scheduledTradingRetired },
    jobsList: Object.fromEntries((Array.isArray(jobs) ? jobs : []).map((j) => [j.id, `${j.title}|${j.salary}|${j.weeklyTarget}|${j.maxStudents}`])),
    fee: settings?.stockTradingFeeRate,
    transferEnabled: settings?.transferEnabled,
    investmentTradingEnabled: settings?.investmentTradingEnabled,
    products: Object.fromEntries((products || []).map((p) => [p.id, `${p.name}|${p.interestRate}|${p.termDays}|${p.isActive}|${p.minDeposit}|${p.maxDeposit}`])),
    items: Object.fromEntries((Array.isArray(items) ? items : []).map((i) => [i.id, `${i.name}|${i.price}|${i.stock ?? i.quantity ?? ''}|${i.isActive ?? ''}`])),
    sb: { ct: sb?.classroomTradingEnabled },
    stocks: Object.fromEntries((investments || []).map((i) => [i.id, `${i.name}|${i.tradingEnabled}|${i.isActive}`])),
    apiKeys: { investments: keys(investments), sb: Object.keys(sb || {}).sort().join(','), products: keys(products) },
    // 사이트가 갱신될 때마다 바뀌는 화면 번들 이름은 bundle 로 이미 비교함
  };
}

export function diff(prev, cur) {
  const msgs = [];
  const walk = (a, b, path) => {
    if (a && b && typeof a === 'object' && typeof b === 'object') {
      for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) walk(a[k], b[k], path ? `${path}.${k}` : k);
    } else if (JSON.stringify(a) !== JSON.stringify(b)) msgs.push({ path, from: a, to: b });
  };
  walk(prev, cur, '');
  return msgs;
}

// 응답 형식이 예상과 다르면 안전모드(자동 실행 중지)로 전환하기 위한 검사
export function schemaProblems({ user, investments, deposits, products, sb, rt }) {
  const p = [];
  if (!user || user.balance === undefined) p.push('auth/user 에 balance 없음');
  if (!Array.isArray(investments) || (investments[0] && investments[0].currentPrice === undefined)) p.push('investments 형식 변경');
  if (!Array.isArray(deposits)) p.push('bank/deposits 형식 변경');
  if (!Array.isArray(products)) p.push('savings-products 형식 변경');
  // 주식: 새 실시간 방식(stock-realtime)이 기준. 응답이 없을 때만 예전 방식으로 확인
  if (rt) { if (!Array.isArray(rt.quotes) || !Array.isArray(rt.windows) || rt.open === undefined) p.push('stock-realtime 형식 변경'); }
  else if (!sb || sb.orders === undefined) p.push('주식 거래 정보를 불러오지 못함');
  return p;
}
