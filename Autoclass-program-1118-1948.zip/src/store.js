import fs from 'node:fs';
import path from 'node:path';
import { DATA } from './config.js';

const stateFile = path.join(DATA, 'state.json');
const logFile = path.join(DATA, 'activity.jsonl');

export const state = (() => {
  try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { return {}; }
})();
state.prices ??= {};
state.baseline ??= {};
state.seen ??= {};
state.suggestions ??= {};

let dirty = false;
export const touch = () => { dirty = true; };
export function flush() {
  if (!dirty) return;
  dirty = false;
  const tmp = stateFile + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state));
  fs.renameSync(tmp, stateFile);
}
setInterval(flush, 5000).unref();

const recent = [];
export function log(type, msg, extra = {}) {
  const rec = { t: new Date().toISOString(), type, msg, ...extra };
  recent.push(rec);
  if (recent.length > 300) recent.shift();
  try {
    if (fs.existsSync(logFile) && fs.statSync(logFile).size > 5_000_000) fs.renameSync(logFile, logFile + '.old');
    fs.appendFileSync(logFile, JSON.stringify(rec) + '\n');
  } catch {}
  return rec;
}
export function recentLog() {
  if (!recent.length) {
    try {
      const lines = fs.readFileSync(logFile, 'utf8').trim().split('\n').slice(-300);
      for (const l of lines) try { recent.push(JSON.parse(l)); } catch {}
    } catch {}
  }
  return recent;
}
