// 시세 분석: 외부 시세 → 지표 → 수수료 차감 백테스트 → 종목별 "검증된 신호" 판정. 하루 몇 번만 갱신.
import { candidatesOf, daily, pool } from './market.js';
import { backtest, featuresOf } from './signals.js';
import { log } from './store.js';

const INDICES = { kospi: '^KS11', sp500: '^GSPC', nasdaq: '^IXIC' };

export async function runAnalysis({ investments, fee }) {
  const stocks = investments.filter((i) => i.type === 'stock');
  const items = stocks.map((i) => ({ inv: i, cands: candidatesOf(i) })).filter((x) => x.cands.length);
  const tasks = [...items.map((x) => x.cands), ...Object.values(INDICES).map((s) => [s])];
  const got = await pool(tasks, 4, async (cands) => { let last; for (const s of cands) { try { return { s, rows: await daily(s) }; } catch (e) { last = e; } } throw last; });
  const closes = {}, errors = [];
  got.forEach((g, k) => { if (g?.rows) closes[g.s] = g.rows.map((r) => r[4]); else errors.push(`${tasks[k][0]}: ${g?.error || '실패'}`); if (g?.rows && k < items.length) items[k].sym = g.s; });

  const roundTrip = fee * 2;
  const rules = backtest(Object.fromEntries(items.filter((x) => x.sym && closes[x.sym]).map((x) => [x.sym, closes[x.sym]])), roundTrip);
  const passIds = new Set(rules.filter((r) => r.pass).map((r) => r.id));
  const byRule = Object.fromEntries(rules.map((r) => [r.id, r]));

  const out = {};
  for (const { inv, sym } of items) {
    const c = sym && closes[sym]; if (!c) continue;
    const f = featuresOf(c); if (!f) continue;
    const passing = f.firing.filter((id) => passIds.has(id));
    const best = passing.map((id) => byRule[id]).sort((a, b) => b.meanNetPct - a.meanNetPct)[0];
    out[inv.id] = { symbol: sym, ...f, passing, expectedNetPct: best ? best.meanNetPct : null, hitPct: best ? best.hitPct : null, horizonDays: best ? best.H : null };
  }
  const idx = {};
  for (const [k, s] of Object.entries(INDICES)) { const f = closes[s] && featuresOf(closes[s]); if (f) idx[k] = { last: f.last, ret1: f.ret1, ret5: f.ret5, ret20: f.ret20 }; }
  const res = { at: new Date().toISOString(), fee, roundTripPct: +(roundTrip * 100).toFixed(2), universe: Object.keys(closes).length - Object.keys(INDICES).length, rules, stocks: out, indices: idx, errors: errors.slice(0, 6),
    passingRules: rules.filter((r) => r.pass).map((r) => r.id), signalsNow: Object.values(out).filter((s) => s.passing.length).length };
  log('analysis', `시세 분석 완료: 종목 ${res.universe}개 · 통과 규칙 ${res.passingRules.length}/${rules.length} · 지금 신호 ${res.signalsNow}종목${errors.length ? ` · 실패 ${errors.length}` : ''}`);
  return res;
}
