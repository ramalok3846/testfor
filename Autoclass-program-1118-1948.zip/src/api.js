import { randomUUID } from 'node:crypto';

// 경제교실 API 래퍼. 사이트 번들에서 확인한 경로/페이로드 형식 기준.
export class Api {
  constructor(session) { this.s = session; }
  // 읽기 요청만 일시적 네트워크 오류(연결 끊김·타임아웃)에서 최대 3회 재시도. 쓰기(POST/PUT)는 중복 방지를 위해 재시도하지 않음
  async get(p) {
    let last;
    for (let i = 0; i < 3; i++) {
      try { return (await this.s.request('GET', p)).json; }
      catch (e) {
        last = e;
        if (!/ECONNRESET|ETIMEDOUT|EAI_AGAIN|ENOTFOUND|socket hang up|Timeout/i.test(String(e.message))) throw e;
        await new Promise((r) => setTimeout(r, 1200 * (i + 1)));
      }
    }
    throw last;
  }
  user() { return this.get('/api/auth/user'); }
  investments() { return this.get('/api/investments'); }
  deposits() { return this.get('/api/bank/deposits'); }
  products() { return this.get('/api/savings-products'); }
  stockBatch() { return this.get('/api/stock-batch'); } // 예전 회차 방식(은퇴함). 주문 기록·보유(lots) 참고용으로만 사용
  // 학생 본인의 업무 완료 체크(사이트 직업 화면과 같은 요청)
  async markWork(date, completed = true) {
    const r = await this.s.request('PUT', '/api/work-logs/me', { workDate: date, isCompleted: completed });
    if (r.status >= 300) throw new Error(`직업 체크 실패 ${r.status} ${r.text.slice(0, 200)}`);
    return r.json;
  }
  jobs() { return this.get('/api/jobs'); }
  meals() { return this.get('/api/meals'); }
  workSummary() { return this.get('/api/work-logs/me/summary'); }
  purchases() { return this.get('/api/user/purchases'); }
  categories() { return this.get('/api/item-categories'); }
  forecast() { return this.get('/api/payroll/me/forecast'); }
  settings() {return this.get('/api/classroom/settings'); }
  items() { return this.get('/api/items'); }
  async bundleName() {
    const { text } = await this.s.request('GET', '/');
    return (text.match(/assets\/index-[\w-]+\.js/) || [])[0] || null;
  }
  async createDeposit({ productId, name, amount }) {
    const r = await this.s.request('POST', '/api/bank/deposits', { savingsProductId: Number(productId), name, amount: String(amount) });
    if (r.status >= 300) throw new Error(`예금 생성 실패 ${r.status} ${r.text.slice(0, 200)}`);
    return r.json;
  }
  async terminateDeposit(id) {
    const r = await this.s.request('POST', `/api/bank/deposits/${id}/terminate`, {});
    if (r.status >= 300) throw new Error(`예금 해지 실패 ${r.status} ${r.text.slice(0, 200)}`);
    return r.json;
  }
  // ── 실시간(즉시 체결) 거래: 사이트가 회차 방식에서 바꿈 ──
  stockRealtime() { return this.get('/api/stock-realtime'); }
  holdings() { return this.get('/api/user/investments'); }
  // 순서: ① 최신 시세 확보 → ② 시세 버전 확인 → ③ 주문(현재 시세로 즉시 체결 또는 취소)
  async placeOrder({ investmentId, side, shares }) {
    const id = Number(investmentId);
    await this.s.request('POST', '/api/stock-realtime/quote', { investmentId: id });
    const rt = await this.stockRealtime();
    if (!rt?.enabled || rt.paused) throw new Error('지금은 주식 거래가 막혀 있습니다');
    if (!rt.open) throw new Error('지금은 거래 가능 시간이 아닙니다 (다음 ' + (rt.nextOpenAt || '-') + ')');
    const q = (rt.quotes || []).find((x) => x.investmentId === id);
    if (!q?.valid) throw new Error('최신 시세를 확인하지 못해 이 종목은 거래할 수 없습니다' + (q?.reason ? ` (${q.reason})` : ''));
    const r = await this.s.request('POST', '/api/stock-realtime/orders', {
      investmentId: id, side, shares: String(shares), requestKey: randomUUID(), quoteVersion: q.version,
    });
    if (r.status !== 201) throw new Error(`주문 실패 ${r.status} ${r.text.slice(0, 200)}`);
    return { ...(r.json || {}), quote: q };
  }
  async cancelOrder(id) {
    const r = await this.s.request('POST', `/api/stock-batch/orders/${id}/cancel`, {});
    if (r.status >= 300) throw new Error(`주문 취소 실패 ${r.status} ${r.text.slice(0, 200)}`);
    return r.json;
  }
}
