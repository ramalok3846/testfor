# 우리 전용 서버 만들기 (라즈베리파이 / 안 쓰는 PC)

PC를 꺼도 **24시간 돌아가는, 이 프로그램만을 위한 작은 서버**예요. 월 이용료 없이 전기료만 들어요(라즈베리파이 약 5W → 월 1천 원 안팎).

## 무엇이 준비되어 있나
| 기능 | 내용 |
|---|---|
| 가벼움 | Docker·브라우저 없이 Node 프로그램 하나(약 90MB 메모리). 라즈베리파이 3/4/5, Zero 2 W, 오래된 노트북 모두 OK |
| 자동 시작 | 전원이 들어오면 알아서 시작 (systemd) |
| 자동 복구 | 죽으면 5초 뒤 재시작 · 2분마다 상태 점검 · 응답이 없으면 재시작하고 폰에 알림 · 메모리 폭주 시 이 프로그램만 재시작 |
| 정전·먹통 대비 | 하드웨어 워치독(보드가 지원하면 OS가 멈출 때 스스로 재부팅) |
| 죽음 감시 | `HEARTBEAT_URL`(healthchecks.io 무료)에 1분마다 신호 → 서버가 통째로 꺼지면 **그쪽에서 폰으로 경보** |
| 백업 | 매일 새벽 4시 데이터 백업, 최근 14개 보관, 한 줄로 복원 |
| 보안 | 전용 계정, 쓰기 가능 폴더 제한, 방화벽(인터넷 차단 · 같은 공유기 + Tailscale만 허용), 자동 보안 업데이트, 로그 용량 제한 |
| 관리 도구 | `autoclassctl` 명령 하나로 상태/로그/업데이트/백업/복원 |

## 준비물 (추천)
- **라즈베리파이 4 (2GB 이상) 또는 5** + 정품 전원 어댑터 + **microSD 보다는 USB SSD 부팅 권장**(SD카드는 오래 쓰면 고장 나요) + 랜선(와이파이보다 안정적)
- 또는 **안 쓰는 노트북/미니PC** (Ubuntu Server 설치, 전원 연결 상태 유지. 노트북은 덮개를 닫아도 안 꺼지게 `HandleLidSwitch=ignore`)
- 정전이 잦으면 작은 UPS 또는 보조배터리형 전원

## 설치 (15분)
1. **Raspberry Pi Imager**로 *Raspberry Pi OS Lite (64-bit)* 를 굽고, 톱니바퀴 설정에서 호스트 이름, SSH 켜기, 사용자/암호, 와이파이(랜선이면 생략)를 지정
2. 공유기에서 이 기기의 **내부 IP를 고정**(DHCP 예약)하면 편해요
3. 이 프로그램 폴더 전체(또는 zip)를 서버로 복사
   ```
   scp -r Autoclass 사용자@서버IP:~/
   ```
4. 서버에 접속(`ssh 사용자@서버IP`)해서 설치
   ```
   cd ~/Autoclass
   sudo bash server-kit/install.sh
   ```
   질문 5개에 답하면 끝: 경제교실 아이디/비밀번호, 대시보드 암호(새로 정함), Claude 토큰(선택), 죽음 감시 URL(선택)
5. 같은 와이파이의 PC·폰 브라우저에서 `http://서버IP:8080` → 암호 입력. 폰은 “홈 화면에 추가”로 앱처럼 설치

> **중요: 같은 계정을 두 곳이 동시에 자동 거래하지 않게** — 서버를 시작하면 내 PC의 프로그램은 설정 → 시스템 → 역할을 “감시만”으로 바꾸거나 `stop.bat`으로 끄세요. (서버가 주 실행)

## 밖에서(학교·데이터) 접속: Tailscale
```
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
sudo tailscale serve --bg 8080      # https 주소가 생겨요
```
폰에도 Tailscale 앱을 깔고 같은 계정으로 로그인하면 `https://서버이름.tailnet-이름.ts.net` 으로 어디서든 접속돼요. 서버는 인터넷에 직접 열리지 않아요.

## “죽으면 알려 주는” 이중 안전장치 (권장, 무료)
서버가 완전히 꺼지면 서버 스스로는 알릴 수 없어요. 그래서 바깥 감시를 하나 둬요.
1. https://healthchecks.io 가입(무료) → 체크 생성(Period 5분, Grace 5분) → 알림 수단에 이메일/텔레그램/ntfy 연결
2. 나오는 Ping URL을 설치 질문(또는 `sudo autoclassctl config` 의 `HEARTBEAT_URL=`)에 입력
→ 서버가 5~10분 이상 신호를 못 보내면(정전, 인터넷 끊김, 프로그램 멈춤) 폰으로 경보가 와요. 감시 루프가 멈춘 경우에도 신호를 일부러 끊어서 경보가 가게 해 뒀어요.

## 평소 쓰는 명령
```
autoclassctl status          # 상태 (서비스·메모리·온도·디스크·마지막 백업)
autoclassctl logs 200        # 최근 로그 200줄      autoclassctl follow  (실시간)
sudo autoclassctl config     # 아이디/암호/토큰/알림 주소 바꾸기 (저장하면 자동 재시작)
sudo autoclassctl update ~/Autoclass-새버전.zip   # 업데이트 (자동 백업 후 적용)
sudo autoclassctl backup | restore /var/backups/autoclass/파일.tgz
```

## 서버 vs 내 PC 버전 차이
- 서버에는 브라우저가 없어서 **아이디/비밀번호로 직접 로그인**해요(세션이 끊기면 자동 재로그인). 구글 로그인 전용 계정이면 사용할 수 없어요.
- AI 판단은 `CLAUDE_CODE_OAUTH_TOKEN`이 있어야 해요(없으면 규칙 기반으로 동작).
- 데이터는 `/var/lib/autoclass`에 있고, 내 PC의 `data` 폴더 내용을 복사해 옮길 수도 있어요(서비스 중지 후 복사 → 소유자 `autoclass`로 → 시작).

## 문제 해결
- 접속 안 됨 → `autoclassctl status`, 서버 IP가 바뀌었는지 확인(공유기에서 IP 고정)
- 계속 재시작됨 → `autoclassctl logs 100` 확인(대개 로그인 정보 오류)
- 설치를 다시 하고 싶음 → `sudo bash server-kit/install.sh` 재실행(설정·데이터는 유지)
- 완전 삭제 → `sudo systemctl disable --now autoclass autoclass-health.timer autoclass-backup.timer`
