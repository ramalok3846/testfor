# 공기계 폰(Galaxy Note9)을 24시간 서버로

비용 0원. 폰에 Termux(리눅스 터미널 앱)를 깔고 이 프로그램을 서버 모드로 돌려요.

## 준비
1. 공기계를 **와이파이에 연결**, 충전기 상시 연결(가능하면 설정 → 배터리에서 충전 제한 켜기. 배터리가 부풀면 위험해요)
2. 폰 브라우저에서 **F-Droid**(f-droid.org) 설치 → F-Droid에서 **Termux**, **Termux:Boot** 두 앱 설치 (구글 플레이 버전은 오래돼서 안 돼요)
3. 이 프로그램 zip(`Autoclass-program-….zip`)을 폰의 **다운로드** 폴더에 복사 (카톡 “나에게 보내기”, 구글 드라이브, USB 등)
4. 설치 스크립트를 폰으로 가져오기: Termux에서
   ```
   termux-setup-storage
   cd ~/storage/downloads
   unzip -o Autoclass-program-*.zip 'server-kit/termux-install.sh' -d ~/tmp-ac
   bash ~/tmp-ac/server-kit/termux-install.sh
   ```
5. 질문에 답하기: 경제교실 아이디/비밀번호, 대시보드 암호(새로 정함), 죽음 감시 URL(선택)

## 설치 뒤 꼭 할 설정 (폰에서 직접)
- 설정 → 앱 → **Termux → 배터리 → 제한 없음**(최적화 안 함). 삼성은 “절전 앱/잠자는 앱” 목록에서도 Termux 제외
- **Termux:Boot** 앱을 한 번 실행(그래야 폰이 재부팅돼도 자동 시작)
- 화면은 꺼도 되지만 Termux 알림(“wake lock 유지”)은 지우지 마세요

## 접속
- 같은 와이파이: `http://폰IP:8080` (폰 IP는 설치 끝에 표시, 공유기에서 IP 고정 권장)
- 밖에서: 폰과 내 휴대폰/PC 모두 **Tailscale** 앱을 설치해 같은 계정으로 로그인 → `http://폰의 Tailscale IP:8080`

## 확인·관리
```
curl -s localhost:8080/healthz     # {"ok":true,...} 이면 정상
tail -n 50 ~/autoclass.log         # 로그
```
- 죽으면 5초 뒤 다시 켜고, 2분마다 점검, 매일 백업(`~/autoclass-backup`, 7개)
- 업데이트: 새 zip을 다운로드 폴더에 넣고 `bash 설치스크립트` 다시 실행(설정·데이터 유지)

## 한계
- 안드로이드가 앱을 죽이면 멈출 수 있어요 → 위 배터리 설정과 healthchecks.io 죽음 감시를 꼭 같이 쓰세요
- Termux에서 Claude CLI는 확인 못 했어요. 안 되면 AI 없이 규칙 기반으로 동작해요
- **내 PC 프로그램과 동시에 자동 거래 금지** (PC는 “감시만” 또는 종료)
