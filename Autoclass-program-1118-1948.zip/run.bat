@echo off
cd /d "%~dp0"
title EconomyClassAuto
:loop
node src\main.js %*
if errorlevel 1 (
  echo [%date% %time%] crashed, restart in 10s...
  timeout /t 10 /nobreak >nul
  goto loop
)
