#!/usr/bin/env bash
# 경제교실 오토 — 전용 서버 설치 (Raspberry Pi OS / Ubuntu / Debian)
# 사용:  이 폴더 전체를 서버로 옮긴 뒤   sudo bash server-kit/install.sh
# 다시 실행해도 안전해요(설정·데이터는 그대로 두고 프로그램만 갱신).
set -euo pipefail

[ "$(id -u)" = 0 ] || { echo "sudo 로 실행해 주세요:  sudo bash server-kit/install.sh"; exit 1; }
SRC="$(cd "$(dirname "$0")/.." && pwd)"
APP=/opt/autoclass
DATA=/var/lib/autoclass
ETC=/etc/autoclass
USR=autoclass
PORT=8080

say() { printf '\n== %s\n' "$*"; }

say "1/8  기본 도구 설치"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates unzip ufw rsync unattended-upgrades

say "2/8  Node.js 22 설치"
need_node=1
if command -v node >/dev/null 2>&1 && [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 22 ]; then need_node=0; fi
if [ "$need_node" = 1 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
node -v

say "3/8  전용 사용자 · 폴더"
id "$USR" >/dev/null 2>&1 || useradd --system --home "$DATA" --shell /usr/sbin/nologin "$USR"
mkdir -p "$APP" "$DATA" "$ETC" /var/backups/autoclass
chown -R "$USR":"$USR" "$DATA"
chmod 700 "$ETC"

say "4/8  메모리가 작으면 스왑(보조 메모리) 만들기"
MEM_MB=$(free -m | awk '/Mem:/ {print $2}')
if [ "$MEM_MB" -lt 1500 ] && ! swapon --show | grep -q .; then
  fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  echo "스왑 1GB 추가 (메모리 ${MEM_MB}MB)"
fi

say "5/8  프로그램 복사 · 설치"
rsync -a --delete \
  --exclude 'data' --exclude 'dist' --exclude 'node_modules' --exclude '.env' --exclude '.git' \
  "$SRC"/ "$APP"/
cd "$APP"
npm ci --omit=dev --no-audit --no-fund 2>/dev/null || npm install --omit=dev --no-audit --no-fund
chown -R root:root "$APP"
install -m 755 "$APP/server-kit/autoclassctl" /usr/local/bin/autoclassctl

say "6/8  비밀 설정 — 입력한 값은 화면에 안 보이고 $ETC/env 파일(관리자만 읽기)에만 저장돼요"
if [ -f "$ETC/env" ]; then
  echo "$ETC/env 가 이미 있어요. 그대로 사용합니다 (바꾸려면: sudo autoclassctl config)"
else
  read -rp  "경제교실 아이디: " ECO_USER
  read -rsp "경제교실 비밀번호: " ECO_PASS; echo
  while true; do
    read -rsp "대시보드 접속 암호(8자 이상, 새로 정하세요): " DASH_PASS; echo
    [ "${#DASH_PASS}" -ge 8 ] && break || echo "8자 이상이어야 해요."
  done
  read -rsp "Claude 장기 토큰(sk-ant-oat01-...; 없으면 Enter — 없으면 AI 대신 규칙 기반으로 동작): " CLAUDE_TOKEN; echo
  read -rp  "죽음 감시(healthchecks.io 의 Ping URL; 없으면 Enter): " HB
  RAND="$(head -c 10 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  PHONE="https://ntfy.sh/autoclass-${RAND}"
  umask 077
  {
    echo "AUTOCLASS_MODE=cloud"
    echo "AUTOCLASS_DATA=${DATA}"
    echo "PORT=${PORT}"
    echo "TZ=Asia/Seoul"
    echo "ECONOMY_USERNAME=${ECO_USER}"
    echo "ECONOMY_PASSWORD=${ECO_PASS}"
    echo "DASHBOARD_PASSWORD=${DASH_PASS}"
    echo "CLAUDE_CODE_OAUTH_TOKEN=${CLAUDE_TOKEN}"
    echo "PHONE_URL=${PHONE}"
    echo "HEARTBEAT_URL=${HB}"
  } > "$ETC/env"
  chmod 600 "$ETC/env"
  echo ">>> 폰 알림 주소: ${PHONE}"
  echo ">>> 폰에 ntfy 앱을 설치하고 '${PHONE##*/}' 를 구독하세요."
fi

# Claude CLI(선택): 토큰이 있을 때만 설치
if grep -q '^CLAUDE_CODE_OAUTH_TOKEN=.\+' "$ETC/env" && ! command -v claude >/dev/null 2>&1; then
  say "   Claude CLI 설치"
  npm install -g @anthropic-ai/claude-code --no-audit --no-fund || echo "(Claude CLI 설치 실패 — AI 없이 규칙 기반으로 동작해요)"
fi

say "7/8  서비스 등록 (자동 시작 · 자동 복구 · 감시 · 매일 백업 · 보안 업데이트)"
install -m 644 "$APP/server-kit/autoclass.service"        /etc/systemd/system/autoclass.service
install -m 644 "$APP/server-kit/autoclass-health.service" /etc/systemd/system/autoclass-health.service
install -m 644 "$APP/server-kit/autoclass-health.timer"   /etc/systemd/system/autoclass-health.timer
install -m 644 "$APP/server-kit/autoclass-backup.service" /etc/systemd/system/autoclass-backup.service
install -m 644 "$APP/server-kit/autoclass-backup.timer"   /etc/systemd/system/autoclass-backup.timer
timedatectl set-timezone Asia/Seoul || true
# 로그가 디스크를 채우지 않게 상한
mkdir -p /etc/systemd/journald.conf.d
printf '[Journal]\nSystemMaxUse=100M\n' > /etc/systemd/journald.conf.d/autoclass.conf
systemctl restart systemd-journald || true
# 하드웨어 워치독(라즈베리파이 등): 커널이 멈추면 스스로 재부팅
if [ -e /dev/watchdog ]; then
  mkdir -p /etc/systemd/system.conf.d
  printf '[Manager]\nRuntimeWatchdogSec=15\nRebootWatchdogSec=2min\n' > /etc/systemd/system.conf.d/autoclass-watchdog.conf
fi
systemctl daemon-reload
systemctl enable --now autoclass.service autoclass-health.timer autoclass-backup.timer
systemctl enable --now unattended-upgrades || true

say "8/8  방화벽 (같은 와이파이/공유기 안 + Tailscale 에서만 접속 가능, 인터넷에서는 차단)"
ufw --force default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow OpenSSH >/dev/null
for net in 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16; do ufw allow from "$net" to any port "$PORT" proto tcp >/dev/null; done
ufw allow in on tailscale0 >/dev/null 2>&1 || true
ufw --force enable >/dev/null

sleep 4
echo
autoclassctl status || true
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
cat <<EOF

설치 완료!
  같은 와이파이의 PC/폰에서:  http://${IP:-서버IP}:${PORT}   (아이디 아무거나 / 암호 = 아까 정한 대시보드 암호)
  상태 보기:   autoclassctl status        로그 보기:   autoclassctl logs
  업데이트:    autoclassctl update <새 폴더 또는 zip>
  밖에서 접속: Tailscale 설치  →  curl -fsSL https://tailscale.com/install.sh | sh && sudo tailscale up
  자세한 설명: README-SERVER.md
EOF
