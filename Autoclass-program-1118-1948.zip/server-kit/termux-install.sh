#!/data/data/com.termux/files/usr/bin/bash
# 경제교실 오토 — 안드로이드 폰(Termux) 설치
# 사용: Termux 에서   bash termux-install.sh   (zip 은 폰의 '다운로드' 폴더에 둔 상태)
set -eu
APP="$HOME/autoclass"; DATA="$HOME/autoclass-data"; ENVF="$HOME/.autoclass-env"; PORT=8080
say() { printf '\n== %s\n' "$*"; }

say "1/6  저장소 접근 허용 (팝업이 뜨면 '허용')"
[ -d "$HOME/storage" ] || { termux-setup-storage; sleep 6; }

say "2/6  필요한 프로그램 설치"
pkg update -y && pkg upgrade -y
pkg install -y nodejs unzip curl rsync termux-api termux-services
node -v

say "3/6  프로그램 복사"
ZIP="$(ls -1t "$HOME"/storage/downloads/Autoclass*.zip 2>/dev/null | head -n1 || true)"
if [ -n "$ZIP" ]; then
  T="$(mktemp -d)"; unzip -oq "$ZIP" -d "$T"; mkdir -p "$APP"
  rsync -a --delete --exclude data --exclude node_modules "$T"/ "$APP"/; rm -rf "$T"
  echo "설치 파일: $ZIP"
elif [ -f "$APP/src/main.js" ]; then echo "$APP 에 이미 있어요"
else echo "폰의 '다운로드' 폴더에 Autoclass-program-....zip 을 넣고 다시 실행해 주세요."; exit 1; fi
mkdir -p "$DATA"
cd "$APP" && (npm ci --omit=dev --no-audit --no-fund || npm install --omit=dev --no-audit --no-fund)

say "4/6  비밀 설정 (입력값은 화면에 안 보이고 이 폰의 $ENVF 에만 저장)"
if [ -f "$ENVF" ]; then echo "$ENVF 가 이미 있어요 — 그대로 사용"; else
  read -rp  "경제교실 아이디: " U
  read -rsp "경제교실 비밀번호: " P; echo
  while true; do read -rsp "대시보드 접속 암호(8자 이상, 새로 정하세요): " D; echo; [ "${#D}" -ge 8 ] && break; echo "8자 이상!"; done
  read -rp  "죽음 감시 Ping URL(healthchecks.io; 없으면 Enter): " HB
  R="$(head -c 10 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  umask 077
  { echo "export AUTOCLASS_MODE=cloud"; echo "export AUTOCLASS_DATA='$DATA'"; echo "export PORT=$PORT"; echo "export TZ=Asia/Seoul"
    echo "export ECONOMY_USERNAME='$U'"; echo "export ECONOMY_PASSWORD='$P'"; echo "export DASHBOARD_PASSWORD='$D'"
    echo "export PHONE_URL='https://ntfy.sh/autoclass-$R'"; echo "export HEARTBEAT_URL='$HB'"; } > "$ENVF"
  echo ">>> 폰 알림 주소: https://ntfy.sh/autoclass-$R  (ntfy 앱에서 'autoclass-$R' 구독)"
fi

say "5/6  자동 시작 · 자동 복구 등록"
mkdir -p "$HOME/.termux/boot" "$HOME/bin"
cp "$APP/server-kit/termux-run.sh" "$HOME/bin/autoclass-run"; chmod +x "$HOME/bin/autoclass-run"
printf '#!/data/data/com.termux/files/usr/bin/bash\ntermux-wake-lock\nnohup "$HOME/bin/autoclass-run" >> "$HOME/autoclass.log" 2>&1 &\n' > "$HOME/.termux/boot/autoclass.sh"
chmod +x "$HOME/.termux/boot/autoclass.sh"

say "6/6  시작"
pkill -f autoclass-run 2>/dev/null || true
termux-wake-lock
nohup "$HOME/bin/autoclass-run" >> "$HOME/autoclass.log" 2>&1 &
sleep 8
IP="$(ip route get 1 2>/dev/null | awk '{print $7; exit}' || true)"
echo; curl -fsS -m 5 "http://127.0.0.1:$PORT/healthz" || echo "(아직 시작 중일 수 있어요: tail -f ~/autoclass.log)"
cat <<EOF


설치 완료!  같은 와이파이에서  http://${IP:-폰IP}:$PORT  (암호 = 정한 대시보드 암호)
남은 설정(폰에서 직접):
  1) 설정 → 앱 → Termux → 배터리 → '제한 없음'(최적화 안 함)
  2) Termux:Boot 앱을 F-Droid 에서 설치하고 한 번 실행(폰 재부팅 후 자동 시작)
  3) 충전기는 계속 연결(가능하면 충전 80% 제한 설정)
상태 보기: curl -s localhost:$PORT/healthz      로그: tail -n 50 ~/autoclass.log
EOF
