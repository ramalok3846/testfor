#!/data/data/com.termux/files/usr/bin/bash
# 경제교실 오토 실행기(Termux): 죽으면 다시 켜고, 2분마다 응답을 점검하고, 매일 백업
. "$HOME/.autoclass-env"
APP="$HOME/autoclass"; DATA="${AUTOCLASS_DATA:-$HOME/autoclass-data}"
termux-wake-lock 2>/dev/null
phone() { [ -n "${PHONE_URL:-}" ] && curl -fsS -m 10 -H "Title: $1" -d "$2" "$PHONE_URL" >/dev/null 2>&1 || true; }

( # 감시: 응답 없음이 2번 연속이면 node 를 죽여서 아래 루프가 재시작하게 함
  fails=0; sleep 180
  while true; do
    if curl -fsS -m 8 "http://127.0.0.1:${PORT:-8080}/healthz" >/dev/null 2>&1; then fails=0
    else fails=$((fails+1)); if [ $fails -ge 2 ]; then fails=0; pkill -f "node src/main.js"; phone "경제교실 폰 서버" "응답이 없어서 자동으로 재시작했어요"; fi; fi
    sleep 120
  done ) &
( # 백업: 하루 한 번, 최근 7개
  while true; do
    sleep 86400
    mkdir -p "$HOME/autoclass-backup"; tar -czf "$HOME/autoclass-backup/data-$(date +%Y%m%d).tgz" -C "$DATA" . 2>/dev/null
    ls -1t "$HOME"/autoclass-backup/data-*.tgz 2>/dev/null | tail -n +8 | xargs -r rm -f
  done ) &

cd "$APP" || exit 1
while true; do
  node --max-old-space-size=256 src/main.js
  echo "[$(date '+%F %T')] 프로그램이 종료됨 — 5초 후 재시작"
  sleep 5
done
