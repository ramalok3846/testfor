# 24시간 켜 두는 방법 모음 (내 컴퓨터가 꺼져도 돌아가게)

프로그램은 **어디서든 같은 코드**로 돌아요. 아래 중 편한 곳에 두면 됩니다. (클라우드 모드: `README-CLOUD.md`)

| 방법 | 비용 | 난이도 | 안정성 | 메모 |
|---|---|---|---|---|
| **1. 지금 쓰는 PC를 계속 켜 두기** | 전기료 | ★ | 중 | 이미 자동 시작·자동 복구·절전 방지 있음. 전원 연결 + 덮개 닫아도 안 꺼지게 설정(`README-24H.md` 아래 참고) |
| **2. 안 쓰는 노트북/미니 PC를 서버로** | 전기료(월 1~3천 원) | ★★ | 높음 | 리눅스(Ubuntu) 설치 후 `deploy/oracle-setup.sh` 그대로 사용 |
| **3. 라즈베리파이(전용 서버 키트)** | 보드 + 전기료(월 ~1천 원) | ★★ | 높음 | `README-SERVER.md` — Docker 없이 systemd, 자동 복구·백업·감시 포함 |
| **4. NAS(시놀로지 등)의 Docker** | 이미 있으면 0원 | ★★ | 높음 | Container Manager에 `docker-compose.yml` 그대로 |
| **5. Oracle 무료 VM** | 0원(카드 인증) | ★★★ | 중상 | 유휴 서버 회수 정책 주의(사용률이 낮으면 회수될 수 있음) |
| **6. 저가 VPS(Lightsail/Vultr/국내)** | 월 3~6천 원 | ★★ | 높음 | 가입 쉽고 안정적. 카드 필요 |
| **7. Fly.io / Railway / Render (저장소 연결)** | 월 약 5천 원~ | ★★ | 높음 | GitHub 저장소에 올리면 자동 배포. 볼륨(영구 디스크) 필요 |
| **8. 안드로이드 폰 + Termux** | 0원(안 쓰는 폰) | ★★★★ | 낮음 | 가능은 하지만 절전·배터리 이슈가 많아 취미용 |
| **9. GitHub Actions 예약 실행** | 0원 | ★★★ | **낮음** | 최소 5분 간격·지연이 잦아 10분짜리 거래 창에 부적합. 예금·감시용 보조로만 |
| **10. Cloudflare Workers(서버리스)로 다시 만들기** | 0원 | ★★★★★ | 중 | 1분 크론 가능하지만 코드를 새로 짜야 하고 Claude CLI 불가(API 키 필요) |

## 추천
- **돈 안 들이고 직접 만들기**: 3번(라즈베리파이) 또는 2번(안 쓰는 노트북)
- **가장 간단**: 1번 + 자동 복구 켜기, 그리고 필요하면 6번
- 어느 쪽이든 **같은 계정을 두 곳이 동시에 자동 거래하지 않도록** 설정 → 시스템 → “이 프로그램의 역할”을 한 곳만 “주 실행”으로 두세요.

## 라즈베리파이/중고 PC 서버 만들기 (요약)
1. Raspberry Pi OS(64bit) 또는 Ubuntu Server 설치 → SSH 켜기
2. 이 폴더(zip)를 서버로 복사 후 `bash deploy/oracle-setup.sh` (이름만 Oracle이고 Ubuntu/Debian 어디서나 동작)
3. 질문에 답하면 Docker 설치·실행까지 끝나요. 접속은 `README-MOBILE.md` 참고(Tailscale 추천)

## 내 PC를 안 꺼지게 하는 윈도우 설정 (직접 실행)
관리자 권한이 필요 없는 설정이에요. 프로그램이 대신 바꾸지는 않고, 원하면 명령 프롬프트에서 직접 실행하세요.
```
powercfg /change standby-timeout-ac 0
powercfg /change monitor-timeout-ac 10
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0
powercfg /setactive SCHEME_CURRENT
```
(전원 연결 시 잠들지 않기, 화면은 10분 뒤 꺼짐, 덮개를 닫아도 아무것도 안 함)

## 직접 만든 전용 서버 (추천)
라즈베리파이/중고 PC에 설치하는 전용 서버 키트가 있어요 → `README-SERVER.md` (`sudo bash server-kit/install.sh`)
