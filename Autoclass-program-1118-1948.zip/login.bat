@echo off
cd /d "%~dp0"
echo A Chrome window will open. Log in to the site yourself.
node src\main.js --login
pause
