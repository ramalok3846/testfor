@echo off
rem Optional: store your Economy Class ID/password in YOUR Windows user environment so the program can log in again
rem by itself when the site session expires. The password is typed hidden, stored only on this PC (user-level
rem environment variable), and is never written to the project files, logs or the zip.
echo.
echo  This lets the program log in automatically when the site logs you out.
echo  The password is stored on this PC only (Windows user environment variable).
echo  Press Ctrl+C now to cancel.
echo.
powershell -NoProfile -Command "$u = Read-Host ' Economy Class ID'; $p = Read-Host ' Password (hidden)' -AsSecureString; $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($p); $plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto($b); if (-not $u -or -not $plain) { Write-Host ' Nothing entered. Nothing was changed.'; exit 1 }; [Environment]::SetEnvironmentVariable('ECONOMY_USERNAME', $u, 'User'); [Environment]::SetEnvironmentVariable('ECONOMY_PASSWORD', $plain, 'User'); Write-Host ' Saved.'"
echo.
echo  Restart the program (stop.bat, then start-hidden.vbs, or sign out and in) to apply.
echo  To remove: set both variables to empty in Windows "Edit environment variables for your account".
pause
