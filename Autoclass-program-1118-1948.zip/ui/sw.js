// 최소 서비스 워커: 앱으로 설치(PWA) 가능하게 하기 위한 것. 데이터는 캐시하지 않고 항상 서버에서 가져와요.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
