/* 경제교실 오토 — 웹 앱 (해시 라우팅 · 페이지별 오류 격리) */
'use strict';
const T = window.__TOKEN__;
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };
const won = (n) => Math.round(num(n)).toLocaleString('ko-KR') + '원';
const pct = (n, d = 2) => (n > 0 ? '+' : '') + num(n).toFixed(d) + '%';
const KST = { timeZone: 'Asia/Seoul' };
const fdt = (t) => (t ? new Date(t).toLocaleString('ko-KR', { ...KST, month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }) : '-');
const fd = (t) => (t ? new Date(t).toLocaleDateString('ko-KR', { ...KST, month: 'numeric', day: 'numeric' }) : '-');
const ft = (t) => new Date(t).toLocaleTimeString('ko-KR', { ...KST, hour: '2-digit', minute: '2-digit', hour12: false });
const left = (t) => {
  const m = Math.round(((typeof t === 'number' ? t : Date.parse(t)) - Date.now()) / 60000);
  if (m <= 0) return '지금';
  if (m < 60) return m + '분 후';
  if (m < 1440) return Math.floor(m / 60) + '시간 ' + (m % 60 ? (m % 60) + '분 ' : '') + '후';
  return Math.floor(m / 1440) + '일 ' + Math.floor((m % 1440) / 60) + '시간 후';
};

const api = async (p, b) => {
  const r = await fetch(p, { method: b !== undefined ? 'POST' : 'GET', headers: { 'x-token': T, 'content-type': 'application/json' }, body: b !== undefined ? JSON.stringify(b) : undefined });
  return r.json();
};

let S = null;               // 서버 상태
let connErr = false;
const ui = { range: '24h', mk: 'all', sort: 'chg', q: '', cat: 'all', logType: 'all', logQ: '', alertType: 'all', setSec: 'auto', storeQ: '', storeSort: 'stock' };

/* ───────── 토스트 · 모달 ───────── */
function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + kind; el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 3800);
}
function openModal(html, mount) {
  $('#modal-root').innerHTML = `<div class="mask" data-act="maskclose"><div class="modal" role="dialog">${html}</div></div>`;
  mount?.($('#modal-root .modal'));
}
const closeModal = () => { $('#modal-root').innerHTML = ''; };
function confirmBox(title, body, ok = '확인', danger = false) {
  return new Promise((resolve) => {
    openModal(`<h3>${esc(title)}</h3><p class="mute" style="margin:8px 0 0">${body}</p><div class="actions"><button class="btn" data-act="cf-no">취소</button><button class="btn ${danger ? 'danger' : 'pri'}" data-act="cf-yes">${esc(ok)}</button></div>`);
    window.__cf = (v) => { closeModal(); resolve(v); };
  });
}

/* ───────── 계산 ───────── */
function calc() {
  const sn = S?.snap; if (!sn) return null;
  const byId = new Map(sn.investments.map((i) => [i.id, i]));
  const px = (i) => num(i.currentPrice) * (num(i.priceMultiplier) || 1);
  const lots = {};
  (sn.sb.lots || []).forEach((l) => { lots[l.investment_id] = (lots[l.investment_id] || 0) + num(l.remaining_shares); });
  const live = sn.deposits.filter((d) => !d.isEarlyTerminated);
  const dep = live.reduce((s, d) => s + num(d.principal), 0);
  const interest = live.reduce((s, d) => s + (num(d.principal) * num(d.interestRate)) / 100, 0);
  const stk = Object.entries(lots).reduce((s, [id, n]) => { const i = byId.get(+id); return s + (i ? px(i) * n : 0); }, 0);
  const cash = sn.user.balance;
  return { cash, dep, interest, stk, total: cash + dep + stk, lots, byId, px, live, fee: num(sn.settings?.stockTradingFeeRate) };
}
const mkt = (i) => (['NASDAQ', 'NYSE'].includes(i.market) ? 'US' : 'KRX');

/* ───────── 차트 ───────── */
function areaChart(el, rows, o = {}) {
  if (!el) return;
  if (!rows || rows.length < 2) { el.innerHTML = `<div class="empty" style="color:inherit;opacity:.8"><span class="e">📈</span>기록이 쌓이는 중입니다</div>`; return; }
  const W = el.clientWidth || 600, H = el.clientHeight || 160, P = { t: 12, b: 6 };
  const cols = o.cols; // [{i:열 인덱스, color}] 아래→위 누적
  const sum = rows.map((r) => cols.reduce((s, c) => s + r[c.i], 0));
  const hi = Math.max(...sum), lo = o.zero ? 0 : Math.min(...sum) * 0.92;
  const t0 = rows[0][0], t1 = rows[rows.length - 1][0] || t0 + 1;
  const X = (t) => ((t - t0) / (t1 - t0 || 1)) * W;
  const Y = (v) => H - P.b - ((v - lo) / (hi - lo || 1)) * (H - P.t - P.b);
  let paths = '';
  for (let k = cols.length - 1; k >= 0; k--) {
    const top = rows.map((r) => cols.slice(0, k + 1).reduce((s, c) => s + r[c.i], 0));
    const d = 'M' + rows.map((r, j) => `${X(r[0]).toFixed(1)},${Y(top[j]).toFixed(1)}`).join('L') + `L${W},${H}L0,${H}Z`;
    paths += `<path d="${d}" fill="${cols[k].color}" opacity="${o.op ?? 0.75}"/>`;
  }
  const line = 'M' + rows.map((r, j) => `${X(r[0]).toFixed(1)},${Y(sum[j]).toFixed(1)}`).join('L');
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${paths}<path d="${line}" fill="none" stroke="${o.line || '#fff'}" stroke-width="2" stroke-linejoin="round"/><line id="cx" y1="0" y2="${H}" stroke="${o.line || '#fff'}" stroke-opacity=".5" style="display:none"/></svg><div class="tip"></div>`;
  const tip = $('.tip', el), cx = $('#cx', el);
  el.onmousemove = (e) => {
    const rc = el.getBoundingClientRect(), x = e.clientX - rc.left;
    const t = t0 + (x / rc.width) * (t1 - t0);
    let b = 0; for (let j = 1; j < rows.length; j++) if (Math.abs(rows[j][0] - t) < Math.abs(rows[b][0] - t)) b = j;
    const r = rows[b];
    tip.style.display = 'block'; tip.style.left = Math.min(Math.max(x, 60), rc.width - 60) + 'px'; tip.style.top = '30px';
    tip.innerHTML = `<b>${fdt(r[0])}</b><br>${o.fmt(r)}`;
    cx.style.display = ''; cx.setAttribute('x1', X(r[0])); cx.setAttribute('x2', X(r[0]));
  };
  el.onmouseleave = () => { tip.style.display = 'none'; cx.style.display = 'none'; };
}
function lineChart(el, pts) {
  if (!pts || pts.length < 2) { el.innerHTML = '<div class="empty"><span class="e">📉</span>시세 기록이 아직 부족합니다</div>'; return; }
  const W = el.clientWidth || 600, H = el.clientHeight || 220, P = 14;
  const ys = pts.map((p) => p[1]), hi = Math.max(...ys), lo = Math.min(...ys);
  const t0 = pts[0][0], t1 = pts[pts.length - 1][0];
  const X = (t) => ((t - t0) / (t1 - t0 || 1)) * (W - 2 * P) + P, Y = (v) => H - P - ((v - lo) / (hi - lo || 1)) * (H - 2 * P);
  const up = ys[ys.length - 1] >= ys[0], col = up ? 'var(--ok)' : 'var(--bad)';
  const d = 'M' + pts.map((p) => `${X(p[0]).toFixed(1)},${Y(p[1]).toFixed(1)}`).join('L');
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><defs><linearGradient id="lg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".25"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs><path d="${d}L${X(t1)},${H}L${X(t0)},${H}Z" fill="url(#lg)"/><path d="${d}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round"/><line id="cx" y1="0" y2="${H}" stroke="${col}" stroke-opacity=".4" style="display:none"/></svg><div class="tip"></div>`;
  const tip = $('.tip', el), cx = $('#cx', el);
  el.onmousemove = (e) => {
    const rc = el.getBoundingClientRect(), x = e.clientX - rc.left, t = t0 + ((x - P) / (rc.width - 2 * P)) * (t1 - t0);
    let b = 0; for (let j = 1; j < pts.length; j++) if (Math.abs(pts[j][0] - t) < Math.abs(pts[b][0] - t)) b = j;
    tip.style.display = 'block'; tip.style.left = Math.min(Math.max(x, 60), rc.width - 60) + 'px'; tip.style.top = Y(pts[b][1]) + 'px';
    tip.innerHTML = `<b>${fdt(pts[b][0])}</b><br>${won(pts[b][1])}`;
    cx.style.display = ''; cx.setAttribute('x1', X(pts[b][0])); cx.setAttribute('x2', X(pts[b][0]));
  };
  el.onmouseleave = () => { tip.style.display = 'none'; cx.style.display = 'none'; };
}
const spark = (a, up) => {
  if (!a || a.length < 2) return '<span class="mute xs">-</span>';
  const mn = Math.min(...a), mx = Math.max(...a), w = 96, h = 28;
  const d = a.map((v, i) => `${((i / (a.length - 1)) * w).toFixed(1)},${(h - 2 - (mx === mn ? h / 2 : ((v - mn) / (mx - mn)) * (h - 4))).toFixed(1)}`).join(' ');
  return `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}"><polyline fill="none" stroke="${up ? 'var(--ok)' : 'var(--bad)'}" stroke-width="1.7" stroke-linejoin="round" points="${d}"/></svg>`;
};

/* ───────── 공통 조각 ───────── */
const empty = (ic, t, sub = '') => `<div class="empty"><span class="e">${ic}</span><b>${esc(t)}</b>${sub ? `<div class="sm">${sub}</div>` : ''}</div>`;
const waiting = () => `<div class="card">${empty('⏳', '데이터를 불러오는 중입니다', '로그인이 필요하면 위 배너의 버튼을 눌러 주세요.')}</div>`;
const modeSeg = (path, v) => `<div class="seg modes">${['off', 'advice', 'auto'].map((m) => `<button data-act="setmode" data-path="${path}" data-v="${m}" class="${v === m ? 'on' : ''}">${{ off: '끄기', advice: '제안만', auto: '자동' }[m]}</button>`).join('')}</div>`;
const getPath = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
const patchOf = (path, v) => { const out = {}; let o = out; const k = path.split('.'); k.slice(0, -1).forEach((x) => (o = o[x] = {})); o[k.at(-1)] = v; return out; };

/* ───────── 페이지: 개요 ───────── */
function timeline() {
  const sn = S.snap, cfg = S.cfg, now = Date.now(), ev = [];
  if (sn.rt) {
    const day = new Date(now + 9 * 3600e3).toISOString().slice(0, 10);
    for (const w of sn.rt.windowsToday || []) ev.push({ t: Date.parse(`${day}T${w.start}:00+09:00`), ic: '📈', title: '주식 거래 창 열림', sub: `${w.start}~${w.end} · 즉시 체결` });
    if (!(sn.rt.windowsToday || []).some((w) => Date.parse(`${day}T${w.start}:00+09:00`) > now) && sn.rt.nextOpenAt) ev.push({ t: Date.parse(sn.rt.nextOpenAt), ic: '📈', title: '다음 주식 거래 창', sub: '즉시 체결' });
  }
  for (const d of sn.deposits.filter((x) => !x.isEarlyTerminated)) {
    const t = Date.parse(d.maturityDate);
    if (t - now < 10 * 864e5) ev.push({ t, ic: '🏦', title: `${d.productName} 만기`, sub: `${won(d.principal)} → ${won(num(d.principal) * (1 + num(d.interestRate) / 100))}` });
  }
  const j = S.job;
  if (j?.isWorkday) {
    const t = Date.parse(`${j.today}T${String(cfg.job.remindHour).padStart(2, '0')}:00:00+09:00`);
    const done = j.watch ? j.watch.todayStatus === 'completed' : j.items?.[0]?.todayDone;
    ev.push({ t, ic: '🗓', title: done ? '오늘 직업 체크 완료 ✅' : '직업 체크 확인 시작', sub: done ? '오늘은 할 일이 없어요' : `${cfg.job.remindHour}시 이후 미완료면 매시간 알림`, done });
  }
  if (S.ai?.at && cfg.ai.mode !== 'off') ev.push({ t: Date.parse(S.ai.at) + cfg.ai.intervalMinutes * 60000, ic: '🧠', title: 'AI 다음 판단', sub: `${cfg.ai.intervalMinutes}분 주기` });
  return ev.filter((e) => e.t > now - 3 * 3600e3 && e.t < now + 40 * 3600e3).sort((a, b) => a.t - b.t);
}
/* ── 자산 추이: 기간(24시간/7일/30일/전체/직접) + 항목 선택 + 상세 차트 ── */
const SERIES = {
  total: { l: '총자산', c: '#6244e8', f: (r) => r[1] + r[2] + r[3] },
  cash: { l: '현금', c: '#9a86ff', f: (r) => r[1] },
  dep: { l: '예금', c: '#2bb3a8', f: (r) => r[2] },
  stk: { l: '주식', c: '#f0a23b', f: (r) => r[3] },
};
ui.series = ['total', 'cash', 'dep', 'stk'];
const RANGES = [['24h', '24시간'], ['7d', '7일'], ['30d', '30일'], ['all', '전체'], ['custom', '직접']];
const kstDay = (t) => new Date(t + 9 * 3600e3).toISOString().slice(0, 10);
function rangeBounds() {
  const now = Date.now();
  if (ui.range === 'custom') {
    const a = ui.cFrom ? Date.parse(ui.cFrom + 'T00:00:00+09:00') : 0, b = ui.cTo ? Date.parse(ui.cTo + 'T23:59:59+09:00') : now;
    return [a, b];
  }
  const ms = { '24h': 864e5, '7d': 7 * 864e5, '30d': 30 * 864e5, all: Infinity }[ui.range];
  return [now - ms, now];
}
function rangeRows() {
  const [a, b] = rangeBounds();
  return (S.history || []).filter((r) => r[0] >= a && r[0] <= b);
}
const rangeLabel = () => (ui.range === 'custom' ? `${ui.cFrom || '처음'} ~ ${ui.cTo || '오늘'}` : RANGES.find((x) => x[0] === ui.range)[1]);
const compact = (n) => { const a = Math.abs(n); return a >= 1e8 ? (n / 1e8).toFixed(1) + '억' : a >= 1e4 ? (n / 1e4).toFixed(a >= 1e5 ? 0 : 1) + '만' : Math.round(n).toLocaleString('ko-KR'); };

function multiChart(el, rows, keys) {
  if (!el) return;
  if (!rows || rows.length < 2) { el.innerHTML = `<div class="empty"><span class="e">📈</span><b>이 기간에는 기록이 아직 부족해요</b><div class="sm">기록은 10분마다 쌓여요. 기간을 넓혀 보세요.</div></div>`; el.onmousemove = el.onmouseleave = null; return; }
  if (!keys.length) { el.innerHTML = `<div class="empty"><span class="e">☝</span>보고 싶은 항목을 눌러 켜 주세요</div>`; return; }
  const W = Math.max(320, el.clientWidth || 700), H = el.clientHeight || 280, L = 56, R = 14, T = 12, B = 26;
  const vals = keys.map((k) => rows.map((r) => SERIES[k].f(r)));
  let lo = Math.min(...vals.flat()), hi = Math.max(...vals.flat());
  if (hi === lo) { hi += Math.abs(hi) * 0.05 + 100; lo -= Math.abs(lo) * 0.05 + 100; }
  const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const t0 = rows[0][0], t1 = rows[rows.length - 1][0];
  const X = (t) => L + ((t - t0) / (t1 - t0 || 1)) * (W - L - R), Y = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  let g = '';
  for (let i = 0; i <= 4; i++) { const v = lo + ((hi - lo) * i) / 4, y = Y(v); g += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" stroke="var(--line)" stroke-dasharray="3 4"/><text x="${L - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="var(--mute)">${compact(v)}</text>`; }
  const span = t1 - t0, short = span <= 36 * 3600e3;
  for (let i = 0; i <= 4; i++) { const t = t0 + (span * i) / 4; const d = new Date(t); const lab = short ? d.toLocaleTimeString('ko-KR', { ...KST, hour: '2-digit', minute: '2-digit', hour12: false }) : d.toLocaleDateString('ko-KR', { ...KST, month: 'numeric', day: 'numeric' }); g += `<text x="${X(t)}" y="${H - 7}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}" font-size="11" fill="var(--mute)">${lab}</text>`; }
  let lines = '';
  keys.forEach((k, ki) => {
    const d = 'M' + rows.map((r, j) => `${X(r[0]).toFixed(1)},${Y(vals[ki][j]).toFixed(1)}`).join('L');
    if (k === 'total') lines += `<path d="${d}L${X(t1)},${H - B}L${X(t0)},${H - B}Z" fill="${SERIES[k].c}" opacity=".1"/>`;
    lines += `<path d="${d}" fill="none" stroke="${SERIES[k].c}" stroke-width="${k === 'total' ? 2.6 : 2}" stroke-linejoin="round" stroke-linecap="round"/>`;
    lines += `<circle cx="${X(t1)}" cy="${Y(vals[ki][vals[ki].length - 1])}" r="3.5" fill="${SERIES[k].c}"/>`;
  });
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${g}${lines}<line id="mcx" y1="${T}" y2="${H - B}" stroke="var(--mute)" stroke-opacity=".5" style="display:none"/></svg><div class="tip" style="transform:none"></div>`;
  const tip = $('.tip', el), cx = $('#mcx', el);
  el.onmousemove = (e) => {
    const rc = el.getBoundingClientRect(), x = e.clientX - rc.left;
    const t = t0 + ((x - L) / (W - L - R)) * (t1 - t0);
    let b = 0; for (let j = 1; j < rows.length; j++) if (Math.abs(rows[j][0] - t) < Math.abs(rows[b][0] - t)) b = j;
    const px = X(rows[b][0]);
    tip.style.display = 'block'; tip.style.left = Math.min(Math.max(px + 12, 8), rc.width - 168) + 'px'; tip.style.top = '8px';
    tip.innerHTML = `<b>${fdt(rows[b][0])}</b>` + keys.map((k, ki) => `<div><i class="dotc" style="background:${SERIES[k].c}"></i>${SERIES[k].l} <b>${won(vals[ki][b])}</b></div>`).join('');
    cx.style.display = ''; cx.setAttribute('x1', px); cx.setAttribute('x2', px);
  };
  el.onmouseleave = () => { tip.style.display = 'none'; cx.style.display = 'none'; };
}
function donut(parts) {
  const tot = parts.reduce((s, p) => s + Math.max(0, p.v), 0) || 1, R = 46, C = 2 * Math.PI * R; let off = 0;
  return `<svg viewBox="0 0 120 120" width="150" height="150"><circle cx="60" cy="60" r="${R}" fill="none" stroke="rgba(255,255,255,.18)" stroke-width="16"/>${parts.map((p) => { const len = (Math.max(0, p.v) / tot) * C; const s = `<circle cx="60" cy="60" r="${R}" fill="none" stroke="${p.c}" stroke-width="16" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-off}" transform="rotate(-90 60 60)"/>`; off += len; return s; }).join('')}</svg>`;
}
function exportCsv() {
  const rows = rangeRows(); if (!rows.length) return toast('내보낼 기록이 없어요', 'bad');
  const csv = '시각(KST),현금,예금,주식,총자산\n' + rows.map((r) => `${new Date(r[0] + 9 * 3600e3).toISOString().slice(0, 16).replace('T', ' ')},${r[1]},${r[2]},${r[3]},${r[1] + r[2] + r[3]}`).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' })); a.download = `자산추이_${kstDay(Date.now())}.csv`; a.click(); toast('CSV로 저장했어요', 'ok');
}

function pHome() {
  const c = calc(); if (!c) return waiting();
  const sn = S.snap, rows = rangeRows();
  const base = rows[0], dv = base ? c.total - (base[1] + base[2] + base[3]) : 0, dp = base && base[1] + base[2] + base[3] ? (dv / (base[1] + base[2] + base[3])) * 100 : 0;
  const ev = timeline(), now = Date.now(), j = S.job;
  const tot = rows.map((r) => r[1] + r[2] + r[3]);
  const hiT = tot.length ? Math.max(...tot) : null, loT = tot.length ? Math.min(...tot) : null;
  return `
  <div class="card hero view-anim">
    <div>
      <div class="lbl">총자산</div><div class="big num">${won(c.total)}</div>
      <span class="delta">${dv >= 0 ? '▲' : '▼'} ${won(Math.abs(dv))} (${dp >= 0 ? '+' : ''}${dp.toFixed(2)}%) · ${esc(rangeLabel())}</span>
      <div class="leg" style="margin-top:16px"><span><i style="background:var(--c-cash)"></i>현금 <b>${won(c.cash)}</b></span><span><i style="background:var(--c-dep)"></i>예금 <b>${won(c.dep)}</b></span><span><i style="background:var(--c-stk)"></i>주식 <b>${won(c.stk)}</b></span></div>
    </div>
    <div class="donutwrap">${donut([{ v: c.cash, c: 'var(--c-cash)' }, { v: c.dep, c: 'var(--c-dep)' }, { v: c.stk, c: 'var(--c-stk)' }])}
      <div class="donutleg">${[['현금', c.cash, 'var(--c-cash)'], ['예금', c.dep, 'var(--c-dep)'], ['주식', c.stk, 'var(--c-stk)']].map(([l, v, col]) => `<div><i style="background:${col}"></i>${l} <b>${c.total > 0 ? Math.round((Math.max(0, v) / Math.max(1, c.total)) * 100) : 0}%</b></div>`).join('')}</div></div>
  </div>

  <div class="card" style="margin-top:16px"><h2>자산 추이 <small>${esc(rangeLabel())} · ${rows.length}개 시점</small><span class="row"><button class="btn sm" data-act="csv">CSV 저장</button></span></h2>
    <div class="row" style="margin-bottom:10px"><div class="chips">${RANGES.map(([k, l]) => `<span class="chip ${ui.range === k ? 'on' : ''}" data-act="range" data-v="${k}">${l}</span>`).join('')}</div>
      ${ui.range === 'custom' ? `<span class="row"><input type="date" id="c-from" value="${esc(ui.cFrom || '')}" max="${kstDay(now)}"><em class="mute">~</em><input type="date" id="c-to" value="${esc(ui.cTo || '')}" max="${kstDay(now)}"><button class="btn sm pri" data-act="applyrange">적용</button></span>` : ''}</div>
    <div class="chips" style="margin-bottom:8px">${Object.entries(SERIES).map(([k, s]) => `<span class="chip ${ui.series.includes(k) ? 'on' : ''}" data-act="series" data-v="${k}" style="${ui.series.includes(k) ? `background:${s.c};border-color:${s.c}` : ''}"><i class="dotc" style="background:${ui.series.includes(k) ? '#fff' : s.c}"></i>${s.l}</span>`).join('')}</div>
    <div class="chartbox" id="hchart" style="height:290px"></div>
    <div class="grid g4" style="margin-top:14px">
      <div class="tile"><div class="xs mute">기간 시작</div><div class="b num">${base ? won(base[1] + base[2] + base[3]) : '-'}</div></div>
      <div class="tile"><div class="xs mute">지금</div><div class="b num">${won(c.total)}</div></div>
      <div class="tile"><div class="xs mute">최고 / 최저</div><div class="b num">${hiT != null ? won(hiT) : '-'} <span class="mute">/</span> ${loT != null ? won(loT) : '-'}</div></div>
      <div class="tile"><div class="xs mute">변화</div><div class="b num ${dv >= 0 ? 'ok' : 'bad'}">${dv >= 0 ? '+' : ''}${won(dv)}</div></div>
    </div>
  </div>

  <div class="grid g4" style="margin-top:16px">
    <div class="card"><div class="mute sm">현금</div><div class="mid num ${c.cash < 0 ? 'bad' : ''}">${won(c.cash)}</div><div class="xs mute">바로 쓸 수 있는 돈 · 남길 현금 ${won(S.cfg.cashReserve)}</div></div>
    <div class="card"><div class="mute sm">예금 ${c.live.length}건</div><div class="mid num">${won(c.dep)}</div><div class="xs ok">만기 시 이자 +${won(c.interest)}</div></div>
    <div class="card"><div class="mute sm">주식 평가액</div><div class="mid num">${won(c.stk)}</div><div class="xs mute">${Object.keys(c.lots).length}종목 보유</div></div>
    <div class="card"><div class="mute sm">이번 주 예상 급여</div><div class="mid num">${won(j?.expectedPay || 0)}</div><div class="xs mute">${esc(j?.items?.[0]?.title || '직업 없음')} · ${j?.items?.[0]?.done ?? 0}/${j?.items?.[0]?.target ?? 0}일</div></div>
  </div>

  <div class="grid g2" style="margin-top:16px">
    <div class="card"><h2>오늘의 일정 <small>한국시간</small></h2>
      ${ev.length ? `<ul class="tl">${ev.map((e) => `<li class="${e.t < now - 5 * 60000 || e.done ? 'past' : e.t - now < 3600e3 ? 'now' : ''}"><span class="t">${new Date(e.t).toLocaleDateString('ko-KR', { ...KST, month: 'numeric', day: 'numeric' })}<br><b>${ft(e.t)}</b></span><span class="ic">${e.ic}</span><div><b>${esc(e.title)}</b><div class="sm mute">${esc(e.sub)} · ${left(e.t)}</div></div></li>`).join('')}</ul>` : empty('🗓', '예정된 일정이 없습니다')}
    </div>
    <div class="stack">
      <div class="card"><h2>승인 대기 제안 <small>${S.suggestions.length}건</small></h2>
        ${S.suggestions.length ? S.suggestions.map((s) => `<div class="sug"><span>${esc(s.desc)}</span><span class="row"><button class="btn pri sm" data-act="apply" data-key="${esc(s.key)}">실행</button><button class="btn ghost sm" data-act="dismiss" data-key="${esc(s.key)}">무시</button></span></div>`).join('') : '<div class="sm mute">승인을 기다리는 제안이 없습니다.</div>'}
      </div>
      <div class="card"><h2>AI 한 줄 요약 <a class="sm" href="#/ai">자세히 →</a></h2>${aiMini()}</div>
    </div>
  </div>`;
}
function aiMini() {
  const a = S.ai;
  if (S.cfg.ai.mode === 'off') return '<div class="sm mute">AI가 꺼져 있습니다. AI 화면에서 켤 수 있어요.</div>';
  if (!a) return '<div class="sm mute">첫 판단을 준비하는 중입니다…</div>';
  if (a.error) return `<div class="err">AI 호출 실패 → 규칙 엔진으로 대체 중<br><span class="xs">${esc(a.error)}</span></div>`;
  return `<div style="line-height:1.7">${esc(a.decision?.summary || '').slice(0, 220)}${(a.decision?.summary || '').length > 220 ? '…' : ''}</div><div class="xs mute" style="margin-top:6px">${fdt(a.at)}${S.aiBusy ? ' · 생각 중…' : ''}</div>`;
}

/* ───────── 페이지: AI 매니저 ───────── */
const MODE_INFO = {
  off: ['⏹', '끄기', 'AI를 쓰지 않아요. 규칙 엔진만 동작해요.'],
  advice: ['💡', '제안만', 'AI가 판단하고 제안만 해요. 실행은 내가 눌러요.'],
  auto: ['🤖', '자동', '안전장치 안에서 AI가 스스로 실행해요.'],
};
function pAI() {
  const a = S.ai, d = a?.decision, cfgm = S.cfg.ai.mode, hist = S.aiHistory || [];
  const today = kstDay(Date.now());
  const th = hist.filter((h) => kstDay(Date.parse(h.at)) === today);
  const acc = th.reduce((s, h) => s + (h.accepted?.length || 0), 0), rej = th.reduce((s, h) => s + (h.rejected?.length || 0), 0);
  const nextT = a?.at ? Date.parse(a.at) + S.cfg.ai.intervalMinutes * 60000 : null;
  const tone = cfgm === 'off' ? 'gray' : a?.error ? 'bad' : S.aiBusy ? 'warn' : 'ok';
  const st = cfgm === 'off' ? 'AI 꺼짐' : a?.error ? '연결 문제 · 규칙 엔진 대체 중' : S.aiBusy ? '생각하는 중…' : '대기 중 · 정상';
  const cl = ui.claude;
  const sn = a?.seen;
  return `<div class="stack view-anim">
  <div class="card aihead">
    <div class="row sb" style="align-items:flex-start;gap:20px">
      <div class="row" style="gap:16px"><span class="orb ${tone}"></span><div><div class="mid">AI 매니저</div><div class="sm ${tone === 'bad' ? 'bad' : 'mute'}">${st}</div>
        <div class="xs mute" style="margin-top:4px">${cl ? (cl.loggedIn ? `Claude 연결됨 (${esc(cl.method === 'oauth_token' ? '장기 토큰' : cl.method)})` : 'Claude 로그인 필요') : ''}</div></div></div>
      <button class="btn pri" data-act="think" ${S.aiBusy ? 'disabled' : ''}>${S.aiBusy ? '생각 중…' : '🧠 지금 판단하기'}</button>
    </div>
    <div class="modecards">${Object.entries(MODE_INFO).map(([k, [ic, l, h]]) => `<button class="mcard ${cfgm === k ? 'on' : ''}" data-act="setmode" data-path="ai.mode" data-v="${k}"><span class="mi">${ic}</span><b>${l}</b><span class="xs">${h}</span></button>`).join('')}</div>
    <div class="grid g4" style="margin-top:14px">
      <div class="tile"><div class="xs mute">마지막 판단</div><div class="b">${a?.at ? fdt(a.at) : '-'}</div><div class="xs mute">${a ? esc(a.why) : ''}</div></div>
      <div class="tile"><div class="xs mute">다음 판단</div><div class="b">${nextT && cfgm !== 'off' ? left(nextT) : '-'}</div><div class="xs mute">${S.cfg.ai.intervalMinutes}분 주기 + 거래 창 열릴 때</div></div>
      <div class="tile"><div class="xs mute">오늘 판단</div><div class="b">${th.length}회</div><div class="xs mute">제안 ${acc} · 안전장치 거부 ${rej}</div></div>
      <div class="tile"><div class="xs mute">확신도</div><div class="b">${d ? Math.round(d.confidence * 100) + '%' : '-'}</div><div class="bar thin" style="margin-top:6px"><i style="width:${d ? Math.round(d.confidence * 100) : 0}%"></i></div></div>
    </div>
    ${a?.error ? `<div class="err" style="margin-top:12px">AI 호출 실패 → 규칙 엔진이 대신 동작 중입니다.<br><span class="xs">${esc(a.error)}</span>${/로그인|authenticate|OAuth/i.test(a.error) ? '<br><b>설정 → 연결·유지에서 “로그인 열기”를 눌러 주세요.</b>' : ''}</div>` : ''}
  </div>

  <div class="grid g2">
    <div class="card"><h2>AI가 보고 있는 상황 <small>마지막 판단 기준</small></h2>
      ${sn ? `<div class="grid g3" style="gap:10px">
        <div class="tile"><div class="xs mute">현금</div><div class="b num ${sn.cash < 0 ? 'bad' : ''}">${won(sn.cash)}</div><div class="xs mute">남길 현금 ${won(sn.reserve)}</div></div>
        <div class="tile"><div class="xs mute">주식 거래</div><div class="b">${sn.tradingOpen ? '<span class="ok">창 열림</span>' : '창 닫힘'}</div><div class="xs mute">거래 가능 ${sn.tradableCount}/${sn.stockCount}종목</div></div>
        <div class="tile"><div class="xs mute">예금 합계</div><div class="b num">${won(sn.depositTotal)}</div><div class="xs mute">왕복 수수료 ${sn.feeRoundTripPct}%</div></div></div>
        <div class="xs mute" style="margin:12px 0 6px">오늘 크게 움직인 종목</div><div class="chips">${(sn.movers || []).map((m) => `<span class="chip" style="cursor:default">${esc(m.name)} <b class="${m.pct < 0 ? 'bad' : 'ok'}">${pct(m.pct, 1)}</b>${m.tradable ? '' : ' 🔒'}</span>`).join('') || '<span class="mute sm">-</span>'}</div>` : empty('🔎', '아직 판단 기록이 없어요', '위 버튼으로 바로 판단을 시켜 보세요.')}
    </div>
    <div class="card"><h2>이번 판단</h2>
      ${d ? `<p style="margin:0 0 10px;line-height:1.75"><b>판단</b> ${esc(d.summary)}</p><p style="margin:0 0 10px;line-height:1.75"><b>전망</b> ${esc(d.forecast)}</p>
        ${d.watch?.length ? `<div class="sm">${d.watch.map((w) => `<div style="margin-bottom:4px"><span class="tag">확인</span>${esc(w)}</div>`).join('')}</div>` : ''}
        <div class="row" style="margin-top:10px">${(d.actions || []).length ? d.actions.map((x) => `<span class="pill">${esc(x.kind ?? x.type)}${x.amount ? ' ' + won(x.amount) : ''}${x.shares ? ' ' + x.shares + '주' : ''}</span>`).join('') : '<span class="pill gray">행동 없음</span>'}</div>` : empty('🧠', '아직 판단 전이에요')}
    </div>
  </div>

  <div class="card"><h2>판단 타임라인 <small>최근 ${hist.length}건</small></h2>
    ${hist.length ? hist.slice(0, 15).map((h) => `<details class="aitl"><summary><span class="tm">${fdt(h.at)}</span><span class="pill gray">${esc(h.why)}</span><span class="sum">${esc(h.summary).slice(0, 90)}${h.summary.length > 90 ? '…' : ''}</span>${h.accepted?.length ? `<span class="pill ok">제안 ${h.accepted.length}</span>` : ''}${h.rejected?.length ? `<span class="pill warn">거부 ${h.rejected.length}</span>` : ''}</summary>
      <div class="aibody"><p><b>판단</b> ${esc(h.summary)}</p><p><b>전망</b> ${esc(h.forecast)}</p><div class="xs mute">확신도 ${Math.round((h.confidence || 0) * 100)}%</div>
      ${h.accepted?.length ? `<div style="margin-top:6px">${h.accepted.map((x) => `<div class="sm ok">✔ ${esc(x)}</div>`).join('')}</div>` : ''}
      ${h.rejected?.length ? `<div style="margin-top:6px">${h.rejected.map((r) => `<div class="sm warn">✖ ${esc(JSON.stringify(r.action).slice(0, 80))} — ${esc(r.why)}</div>`).join('')}</div>` : ''}
      ${h.watch?.length ? `<div style="margin-top:6px">${h.watch.map((w) => `<div class="sm"><span class="tag">확인</span>${esc(w)}</div>`).join('')}</div>` : ''}</div></details>`).join('') : empty('🕘', '아직 기록이 없어요')}
  </div>

  <div class="card"><h2>안전장치 <small>AI가 제안해도 이 규칙을 모두 통과해야 실행돼요</small></h2>
    <div class="grid g3" style="gap:10px">
      <div class="tile"><b>수수료 문턱</b><div class="xs mute">기대수익이 왕복 수수료 + 1.5% 보다 커야 매수</div></div>
      <div class="tile"><b>한도</b><div class="xs mute">종목당 ${S.cfg.stocks.maxPositionPct}% · 최대 ${S.cfg.stocks.maxPositions}종목 · 하루 ${S.cfg.maxAutoActionsPerDay}건</div></div>
      <div class="tile"><b>내 것은 그대로</b><div class="xs mute">직접 산 주식·직접 만든 예금은 건드리지 않아요</div></div>
      <div class="tile"><b>거래 창</b><div class="xs mute">평일 08:00·09:30·10:20·11:20·13:00·14:30에만 · 시세가 잠긴 종목 제외</div></div>
      <div class="tile"><b>현금 여유</b><div class="xs mute">항상 남길 현금 ${won(S.cfg.cashReserve)} 은 쓰지 않아요</div></div>
      <div class="tile"><b>수동 전용</b><div class="xs mute">상점·기부·송금·입찰은 AI가 하지 않아요</div></div>
    </div>
    ${a?.rejected?.length ? `<div class="xs mute" style="margin:14px 0 6px">이번 판단에서 막힌 제안</div>${a.rejected.map((r) => `<div class="callout" style="margin-bottom:6px"><code class="xs">${esc(JSON.stringify(r.action).slice(0, 120))}</code><div class="warn sm">→ ${esc(r.why)}</div></div>`).join('')}` : ''}
  </div>
  </div>`;
}

/* ───────── 페이지: 내 거래 내역 (사이트 "내 종합 상태"의 전체 내역) ───────── */
const TX = {
  salary: ['급여', 'ok'], interest_payment: ['이자', 'ok'], deposit_maturity: ['예금 만기', 'ok'], deposit_creation: ['예금 가입', 'info'], deposit_termination: ['예금 해지', 'warn'],
  fine_issued: ['벌금', 'bad'], donation: ['기부', 'warn'], item_purchase: ['상점 구매', 'info'], item_refund: ['환불', 'ok'], transfer: ['송금', 'info'], gift: ['선물', 'info'],
  stock_buy: ['주식 매수', 'info'], stock_sell: ['주식 매도', 'ok'], investment_buy: ['주식 매수', 'info'], investment_sell: ['주식 매도', 'ok'], auction_bid: ['자리 경매', 'warn'], dividend: ['배당', 'ok'],
  deposit_withdrawal: ['예금 해지·출금', 'warn'], item_use: ['아이템 사용', 'gray'], admin_send: ['교사 지급', 'ok'], admin_take: ['교사 회수', 'bad'], gift_sent: ['선물 보냄', 'info'], gift_received: ['선물 받음', 'ok'],
  fine: ['벌금', 'bad'], transfer_fee: ['송금 수수료', 'warn'], initial_balance: ['초기 지급', 'ok'], auction_payment: ['경매 결제', 'warn'], transfer_sent: ['송금 보냄', 'info'], transfer_received: ['송금 받음', 'ok'],
};
const txl = (t) => TX[t] || [String(t || '').replace(/_/g, ' '), 'gray'];
ui.hist = { rows: [], total: 0, pages: 0, loading: false, loaded: false };
ui.hType = 'all'; ui.hQ = ''; ui.hRange = 'all';
async function loadHist(more = false) {
  const h = ui.hist; if (h.loading) return; h.loading = true; lastSig = ''; render(true);
  const start = more ? h.pages + 1 : 1, n = 4;
  if (!more) { h.rows = []; h.pages = 0; }
  const res = await Promise.all(Array.from({ length: n }, (_, i) => api(`/api/data/mylogs?page=${start + i}&limit=50`)));
  for (const r of res) if (r.ok && r.data?.data) { h.rows.push(...r.data.data); h.total = r.data.total ?? h.total; h.pages = Math.max(h.pages, start + res.indexOf(r)); }
  h.loading = false; h.loaded = true; lastSig = ''; render(true);
}
function pHistory() {
  const h = ui.hist;
  if (!h.loaded && !h.loading) loadHist();
  const now = Date.now(), ms = { '7d': 7 * 864e5, '30d': 30 * 864e5, all: Infinity }[ui.hRange];
  const inRange = h.rows.filter((r) => now - Date.parse(r.createdAt) <= ms);
  const types = {}; for (const r of inRange) types[r.transactionType] = (types[r.transactionType] || 0) + 1;
  const q = ui.hQ.trim().toLowerCase();
  const rows = inRange.filter((r) => (ui.hType === 'all' || r.transactionType === ui.hType) && (!q || (r.description || '').toLowerCase().includes(q)));
  const inc = rows.filter((r) => num(r.amount) > 0).reduce((s, r) => s + num(r.amount), 0), out = rows.filter((r) => num(r.amount) < 0).reduce((s, r) => s + num(r.amount), 0);
  const byDay = {}; for (const r of rows) { const d = kstDay(Date.parse(r.createdAt)); (byDay[d] ??= []).push(r); }
  return `<div class="stack view-anim">
  <div class="grid g4">
    <div class="card"><div class="mute sm">조회된 내역</div><div class="mid">${rows.length}건</div><div class="xs mute">전체 ${h.total || '-'}건 중 ${h.rows.length}건 불러옴</div></div>
    <div class="card"><div class="mute sm">들어온 돈</div><div class="mid num ok">+${won(inc)}</div></div>
    <div class="card"><div class="mute sm">나간 돈</div><div class="mid num bad">${won(out)}</div></div>
    <div class="card"><div class="mute sm">순변화</div><div class="mid num ${inc + out >= 0 ? 'ok' : 'bad'}">${inc + out >= 0 ? '+' : ''}${won(inc + out)}</div></div>
  </div>
  <div class="card"><h2>내 거래 내역 <small>사이트 대시보드의 전체 내역과 같아요</small><span class="row"><button class="btn sm" data-act="histreload">새로고침</button></span></h2>
    <div class="row" style="margin-bottom:10px"><div class="chips">${[['all', '전체'], ['7d', '7일'], ['30d', '30일']].map(([k, l]) => `<span class="chip ${ui.hRange === k ? 'on' : ''}" data-act="hrange" data-v="${k}">${l}</span>`).join('')}</div><input id="hq" type="search" placeholder="내용 검색" value="${esc(ui.hQ)}" class="right"></div>
    <div class="chips" style="margin-bottom:12px"><span class="chip ${ui.hType === 'all' ? 'on' : ''}" data-act="htype" data-v="all">전체 ${inRange.length}</span>${Object.entries(types).sort((a, b) => b[1] - a[1]).map(([t, n]) => `<span class="chip ${ui.hType === t ? 'on' : ''}" data-act="htype" data-v="${t}">${esc(txl(t)[0])} ${n}</span>`).join('')}</div>
    ${h.loading && !h.rows.length ? empty('⏳', '불러오는 중…') : rows.length ? Object.entries(byDay).map(([d, list]) => `<div class="daygrp"><div class="dayh">${new Date(d + 'T00:00:00+09:00').toLocaleDateString('ko-KR', { month: 'long', day: 'numeric', weekday: 'short' })}<span class="mute xs"> · ${list.length}건</span></div>${list.map((r) => { const [lb, tone] = txl(r.transactionType); const a = num(r.amount); return `<div class="txrow"><span class="pill ${tone}">${esc(lb)}</span><div class="txd"><div>${esc(r.description || '')}</div><div class="xs mute">${ft(Date.parse(r.createdAt))}${r.relatedUserName ? ' · ' + esc(r.relatedUserName) : ''}</div></div><div class="txa"><b class="num ${a < 0 ? 'bad' : 'ok'}">${a > 0 ? '+' : ''}${won(a)}</b><div class="xs mute num">잔액 ${won(r.balanceAfter)}</div></div></div>`; }).join('')}</div>`).join('') : empty('🧾', '조건에 맞는 내역이 없어요')}
    ${h.rows.length < h.total ? `<div class="row" style="justify-content:center;margin-top:12px"><button class="btn" data-act="histmore" ${h.loading ? 'disabled' : ''}>${h.loading ? '불러오는 중…' : `더 불러오기 (${h.rows.length}/${h.total})`}</button></div>` : ''}
  </div></div>`;
}

/* ───────── 페이지: 내 급식 (직업과 무관하게 내 급식 참여 기록) ───────── */
function pMeals() {
  const d = ensureData('meals'); if (!d) return loadingBox('meals');
  const ms = d.months || [];
  const nowM = kstDay(Date.now()).slice(0, 7);
  const sum = (k) => ms.reduce((s, m) => s + num(m[k]), 0);
  const part = sum('participationDays'), clean = sum('cleanPlateCount');
  return `<div class="stack view-anim">
  <div class="grid g4">
    <div class="card"><div class="mute sm">최근 ${ms.length}개월 급식 참여</div><div class="mid">${part}일</div></div>
    <div class="card"><div class="mute sm">다 먹은(깨끗이 먹은) 날</div><div class="mid ok">${clean}번</div><div class="xs mute">${part ? Math.round((clean / part) * 100) : 0}%</div></div>
    <div class="card"><div class="mute sm">최고 연속 기록</div><div class="mid">${Math.max(0, ...ms.map((m) => num(m.bestStreak)))}일</div></div>
    <div class="card"><div class="mute sm">지금 연속</div><div class="mid">${num(ms[0]?.currentStreak)}일</div><div class="xs mute">이번 달 기준</div></div>
  </div>
  <div class="callout">지금 직업(<b>${esc(S.snap?.work?.jobTitle || '')}</b>)은 급식 <b>기록 권한</b>이 없어서 친구들의 급식 기록은 입력할 수 없어요. 이 화면은 <b>내가 먹은 급식</b> 기록(사이트 대시보드의 급식 요약)이에요.</div>
  <div class="grid g2">${ms.map((m) => { const p = num(m.participationDays), c = num(m.cleanPlateCount); return `<div class="card"><h2>${esc(m.month)} ${m.month === nowM ? '<span class="pill ok">이번 달</span>' : ''}</h2>
    <div class="row sb"><div><div class="big num">${c}<span class="mute mid"> / ${p}일</span></div><div class="sm mute">다 먹은 날 / 참여한 날</div></div><div class="ring" style="--p:${p ? Math.round((c / p) * 100) : 0}"><span>${p ? Math.round((c / p) * 100) : 0}%</span></div></div>
    <div class="bar" style="margin:12px 0"><i style="width:${p ? (c / p) * 100 : 0}%"></i></div>
    <dl class="kv"><dt>현재 연속</dt><dd>${num(m.currentStreak)}일</dd><dt>최고 연속</dt><dd>${num(m.bestStreak)}일</dd><dt>마지막 확정일</dt><dd>${esc(m.lastFinalizedDate || '-')}</dd><dt>확정 대기</dt><dd>${num(m.pendingDays)}일</dd></dl></div>`; }).join('') || `<div class="card">${empty('🍱', '급식 기록이 없어요')}</div>`}</div></div>`;
}


/* ───────── 페이지: 주식 ───────── */
function pStock() {
  const c = calc(); if (!c) return waiting();
  const sn = S.snap, blocked = sn.sb.blocked || sn.sb.paused;
  const pos = sn.positions || {};
  const held = Object.entries(c.lots).filter(([, n]) => n > 0);
  let list = sn.investments.filter((i) => i.type === 'stock');
  if (ui.mk === 'KRX' || ui.mk === 'US') list = list.filter((i) => mkt(i) === ui.mk);
  if (ui.mk === 'held') list = list.filter((i) => c.lots[i.id] > 0);
  if (ui.q) { const q = ui.q.toLowerCase(); list = list.filter((i) => i.name.toLowerCase().includes(q) || String(i.symbol).toLowerCase().includes(q)); }
  list.sort({ chg: (a, b) => num(b.changePercent) - num(a.changePercent), chgAsc: (a, b) => num(a.changePercent) - num(b.changePercent), name: (a, b) => a.name.localeCompare(b.name, 'ko'), price: (a, b) => c.px(b) - c.px(a) }[ui.sort] || (() => 0));
  const orders = sn.orders.slice(0, 12);
  return `<div class="stack view-anim">
  ${blocked ? `<div class="banner warn" style="margin:0"><b>${sn.rt && !sn.rt.paused && sn.rt.enabled ? '지금은 거래 가능 시간이 아니에요. 거래 창이 열리면 자동으로 다시 동작합니다.' : '교사가 지금 주식 거래를 막아 두었습니다. 열리면 자동으로 다시 동작합니다.'}</b></div>` : ''}
  <div class="grid g3">
    <div class="card"><div class="mute sm">거래 창 <span class="xs">(즉시 체결)</span></div>
      <div class="row" style="margin:6px 0 4px"><span class="pill ${sn.rt?.open ? 'ok' : 'gray'}"><i class="dot"></i>${sn.rt?.open ? '지금 열림' : '닫힘'}</span>${sn.rt && !sn.rt.open && sn.rt.nextOpenAt ? `<span class="sm">다음 ${fdt(sn.rt.nextOpenAt)} (${left(sn.rt.nextOpenAt)})</span>` : ''}</div>
      <div class="xs mute">오늘 ${(sn.rt?.windowsToday || []).map((w) => `${w.start}~${w.end}`).join(' · ') || '없음'}</div>
      <div class="xs mute">유효 시세 ${sn.rt ? Object.values(sn.rt.quotes).filter((q) => q.valid).length : 0}/${sn.rt ? Object.keys(sn.rt.quotes).length : 0}종목 (잠긴 종목은 거래 불가)</div></div>
    <div class="card"><div class="mute sm">수수료</div><div class="mid">${(c.fee * 100).toFixed(2)}%<span class="sm mute"> 편도</span></div><div class="xs mute">왕복 ${(c.fee * 200).toFixed(2)}% · 이 이상 오를 때만 매수</div></div>
    <div class="card"><div class="mute sm">보유 평가액</div><div class="mid num">${won(c.stk)}</div><div class="xs mute">${held.length}종목 · 주문 대기 ${orders.filter((o) => o.status === 'pending').length}건</div></div>
  </div>
  <div class="grid g2">
    <div class="card"><h2>내 보유</h2>${held.length ? `<table><thead><tr><th>종목</th><th class="r">수량</th><th class="r">평가액</th><th class="r">자동 매수분 손익</th></tr></thead><tbody>${held.map(([id, n]) => { const i = c.byId.get(+id); const p = pos[id]; const pnl = p && p.shares > 0 ? ((c.px(i) * p.shares * (1 - c.fee) - p.cost) / p.cost) * 100 : null; return `<tr class="click" data-act="stock" data-id="${id}"><td><b>${esc(i?.name)}</b></td><td class="r">${n}</td><td class="r">${won(i ? c.px(i) * n : 0)}</td><td class="r ${pnl == null ? 'mute' : pnl >= 0 ? 'ok' : 'bad'}">${pnl == null ? '-' : pct(pnl, 1)}</td></tr>`; }).join('')}</tbody></table>` : empty('📭', '보유 중인 주식이 없습니다')}</div>
    <div class="card"><h2>자동 거래 기록 <small>프로그램이 낸 주문 · 즉시 체결</small></h2>${(sn.botTrades || []).length ? `<table><thead><tr><th>시각</th><th>종목</th><th>구분</th><th class="r">수량</th><th class="r">체결가</th><th>결과</th></tr></thead><tbody>${sn.botTrades.slice().reverse().slice(0, 12).map((t) => `<tr><td class="xs">${fdt(t.t)}</td><td>${esc(c.byId.get(t.investmentId)?.name || '#' + t.investmentId)}</td><td>${t.side === 'buy' ? '<span class="pill ok">매수</span>' : '<span class="pill bad">매도</span>'}</td><td class="r">${num(t.shares)}</td><td class="r num">${won(t.price)}</td><td>${t.status === 'filled' ? '체결' : esc(t.status || '?')}</td></tr>`).join('')}</tbody></table>` : empty('🧾', '아직 자동 거래가 없습니다', '거래 창이 열렸을 때 조건이 맞으면 여기에 쌓여요.')}
      ${orders.length ? `<div class="xs mute" style="margin-top:8px">예전 방식 주문 기록 ${orders.length}건은 사이트에 그대로 남아 있어요.</div>` : ''}</div>
  </div>
  <div class="card"><h2>종목 시세 <small>행을 누르면 차트와 주문 창이 열려요</small></h2>
    <div class="row" style="margin-bottom:12px"><div class="chips">${[['all', '전체'], ['KRX', '국내'], ['US', '미국'], ['held', '보유']].map(([k, l]) => `<span class="chip ${ui.mk === k ? 'on' : ''}" data-act="mk" data-v="${k}">${l}</span>`).join('')}</div>
      <select data-act-change="sort" class="right">${[['chg', '등락률 높은 순'], ['chgAsc', '등락률 낮은 순'], ['name', '이름순'], ['price', '가격 높은 순']].map(([k, l]) => `<option value="${k}" ${ui.sort === k ? 'selected' : ''}>${l}</option>`).join('')}</select>
      <input id="q" type="search" placeholder="종목 검색" value="${esc(ui.q)}"></div>
    ${list.length ? `<div class="tscroll"><table><thead><tr><th>종목</th><th class="r">현재가</th><th class="r">등락</th><th>추이</th></tr></thead><tbody>${list.map((i) => `<tr class="click" data-act="stock" data-id="${i.id}"><td><b>${esc(i.name)}</b><div class="xs mute">${esc(i.symbol)} · ${mkt(i) === 'US' ? '미국' : '국내'}${c.lots[i.id] ? ' · <span class="ok">보유</span>' : ''}${sn.rt?.quotes?.[i.id] ? (sn.rt.quotes[i.id].valid ? ' · <span class="ok">시세 유효</span>' : ' · <span class="warn">🔒 시세 잠김</span>') : ''}</div></td><td class="r num">${won(c.px(i))}</td><td class="r num ${num(i.changePercent) < 0 ? 'bad' : 'ok'}">${pct(i.changePercent)}</td><td>${spark(S.spark[i.id], num(i.changePercent) >= 0)}</td></tr>`).join('')}</tbody></table></div>` : empty('🔍', '조건에 맞는 종목이 없습니다')}
  </div></div>`;
}
async function openStock(id) {
  const c = calc(); const i = c.byId.get(+id); if (!i) return;
  const rtq = S.snap.rt?.quotes?.[i.id];
  const blocked = S.snap.sb.blocked || S.snap.sb.paused || (S.snap.rt && !rtq?.valid);
  const why = !S.snap.rt?.open ? '지금은 거래 가능 시간이 아니에요' : rtq && !rtq.valid ? '이 종목은 최신 시세를 확인하지 못해 잠겨 있어요' : '지금은 거래가 막혀 있어요';
  const px = rtq?.valid ? rtq.price : c.px(i);
  openModal(`<div class="row sb"><div><h3>${esc(i.name)}</h3><div class="sm mute">${esc(i.symbol)} · ${mkt(i) === 'US' ? '미국' : '국내'} · ${rtq ? (rtq.valid ? '시세 유효(' + esc(rtq.displayStatus || '') + ')' : '🔒 시세 잠김') : ''}</div></div><button class="btn ghost sm" data-act="mclose">✕</button></div>
    <div class="row" style="margin:14px 0 6px"><span class="big num">${won(px)}</span><span class="pill ${num(i.changePercent) < 0 ? 'bad' : 'ok'}">${pct(i.changePercent)}</span><span class="sm mute">보유 ${c.lots[i.id] || 0}주</span></div>
    <div class="chartbox" id="schart" style="height:230px"></div>
    <div class="xs mute" id="sinfo" style="margin:6px 0 14px"></div>
    <div class="callout"><b>주문</b> <span class="mute xs">· 현재 시세로 바로 체결돼요 · 수수료 ${(c.fee * 100).toFixed(2)}% (편도)</span>
      <div class="row" style="margin-top:10px"><select id="o-side"><option value="buy">매수</option><option value="sell">매도</option></select><input id="o-sh" type="number" min="1" step="1" placeholder="주수" style="width:100px"><span class="sm mute" id="o-est"></span></div>
      ${blocked ? `<div class="warn sm" style="margin-top:8px">${why} — 주문할 수 없습니다.</div>` : ''}</div>
    <div class="actions"><button class="btn" data-act="mclose">닫기</button><button class="btn pri" id="o-go" ${blocked ? 'disabled' : ''}>주문하기</button></div>`,
  (m) => {
    const upd = () => { const n = Math.floor(num($('#o-sh', m).value)), s = $('#o-side', m).value; $('#o-est', m).textContent = n > 0 ? `예상 ${s === 'buy' ? '지불' : '수령'} 약 ${won(px * n * (s === 'buy' ? 1 + c.fee : 1 - c.fee))} (현재가 기준)` : ''; };
    $('#o-sh', m).oninput = upd; $('#o-side', m).onchange = upd;
    $('#o-go', m).onclick = async () => {
      const n = Math.floor(num($('#o-sh', m).value)), side = $('#o-side', m).value;
      if (n < 1) return toast('주수를 입력해 주세요', 'bad');
      if (!(await confirmBox('주문을 접수할까요?', `${esc(i.name)} ${n}주 ${side === 'buy' ? '매수' : '매도'}<br>약 ${won(px * n * (side === 'buy' ? 1 + c.fee : 1 - c.fee))} (현재 시세 기준) · <b>바로 체결됩니다.</b>`, '주문'))) return;
      const r = await api('/api/manual', { kind: 'order', investmentId: i.id, side, shares: n });
      toast(r.ok ? '체결되었습니다' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); if (r.ok) { closeModal(); refresh(); }
    };
  });
  const pts = await api('/api/series?id=' + id);
  const ch = $('#schart'); if (ch) { lineChart(ch, pts); const ys = pts.map((p) => p[1]); if (ys.length) $('#sinfo').textContent = `기록 구간 최고 ${won(Math.max(...ys))} · 최저 ${won(Math.min(...ys))} · ${pts.length}개 시점`; }
}

/* ───────── 페이지: 예금 ───────── */
function pBank() {
  const c = calc(); if (!c) return waiting();
  const sn = S.snap, now = Date.now();
  const next = c.live.slice().sort((a, b) => Date.parse(a.maturityDate) - Date.parse(b.maturityDate))[0];
  return `<div class="stack view-anim">
  <div class="grid g3">
    <div class="card"><div class="mute sm">예금 합계</div><div class="big num">${won(c.dep)}</div><div class="xs mute">${c.live.length}건</div></div>
    <div class="card"><div class="mute sm">만기 시 받을 이자</div><div class="big num ok">+${won(c.interest)}</div><div class="xs mute">중도해지하면 이자는 없어요</div></div>
    <div class="card"><div class="mute sm">다음 만기</div><div class="mid">${next ? fd(next.maturityDate) : '-'}</div><div class="xs mute">${next ? `${esc(next.productName)} · ${left(next.maturityDate)}` : '예정 없음'}</div></div>
  </div>
  <div class="card"><h2>내 예금 <button class="btn pri sm" data-act="newdep">+ 예금 가입</button></h2>
    ${sn.deposits.length ? `<div class="grid g3">${sn.deposits.map((d) => {
      const start = Date.parse(d.createdAt), end = Date.parse(d.maturityDate), p = Math.min(100, Math.max(0, ((now - start) / (end - start)) * 100)), m = d.isMatured || end <= now, mine = String(d.name).startsWith(S.cfg.botPrefix);
      return `<div class="dep"><div class="row sb"><b>${esc(d.productName)}</b>${d.isEarlyTerminated ? '<span class="pill gray">해지됨</span>' : m ? '<span class="pill ok">만기</span>' : `<span class="pill info">${left(d.maturityDate)}</span>`}</div>
        <div class="xs mute">${esc(d.name)} ${mine ? '<span class="tag">자동</span>' : ''}</div>
        <div class="mid num" style="margin:8px 0 2px">${won(d.principal)}</div><div class="sm ok">만기 ${won(num(d.principal) * (1 + num(d.interestRate) / 100))} (+${+d.interestRate}%)</div>
        <div class="bar thin" style="margin:10px 0 6px"><i style="width:${p}%"></i></div><div class="row sb xs mute"><span>${fd(d.createdAt)} 가입</span><span>${fd(d.maturityDate)} 만기</span></div>
        ${(() => { const age = (now - start) / 3600e3, fresh = mine && !m && !d.isEarlyTerminated && age <= num(S.cfg.ai.reconsiderHours ?? 24); return fresh ? `<div class="xs ok" style="margin-top:8px">🕐 방금 가입(${Math.max(1, Math.round(age))}시간 전) · 지금 해지해도 잃는 이자가 거의 없어요</div>` : ''; })()}
        ${d.isEarlyTerminated ? '' : `<div class="row" style="margin-top:10px"><button class="btn sm ${m ? 'pri' : 'danger'}" data-act="term" data-id="${d.id}" data-m="${m ? 1 : 0}">${m ? '만기 수령' : '중도 해지'}</button>${mine && !m && (now - start) / 3600e3 <= num(S.cfg.ai.reconsiderHours ?? 24) ? `<button class="btn sm" data-act="reconsider" data-id="${d.id}">해지하고 AI 재판단</button>` : ''}</div>`}</div>`;
    }).join('')}</div>` : empty('🏦', '가입한 예금이 없습니다')}
    <div class="callout" style="margin-top:14px">이름이 <code>${esc(S.cfg.botPrefix)}</code> 로 시작하는 예금만 자동으로 만기 수령합니다. 직접 가입한 예금은 만기가 되어도 알림만 보냅니다.</div></div>
  <div class="card"><h2>예금 상품 비교</h2><table><thead><tr><th>상품</th><th class="r">이율</th><th class="r">기간</th><th class="r">하루 복리 환산</th><th class="r">100,000원 넣으면</th></tr></thead><tbody>${sn.products.map((p) => `<tr><td><b>${esc(p.name)}</b></td><td class="r">${+p.interestRate}%</td><td class="r">${p.termDays}일</td><td class="r">${((Math.pow(1 + p.interestRate / 100, 1 / p.termDays) - 1) * 100).toFixed(3)}%</td><td class="r ok">+${won(100000 * p.interestRate / 100)}</td></tr>`).join('')}</tbody></table>
    <div class="xs mute" style="margin-top:8px">짧은 상품을 이어서 재가입하면 복리 효과가 있지만 현금이 묶이는 기간과 주식 매수 기회를 함께 따져야 합니다. 자동 모드에서는 AI가 이를 판단합니다.</div></div>
  ${transferCard()}
  </div>`;
}
function newDeposit() {
  const c = calc(), sn = S.snap;
  openModal(`<div class="row sb"><h3>예금 가입</h3><button class="btn ghost sm" data-act="mclose">✕</button></div>
    <div class="callout" style="margin:10px 0">가입 가능 현금 <b>${won(c.cash)}</b> · 직접 가입한 예금은 자동 관리 대상이 아닙니다.</div>
    <div class="setrow"><div class="lbl"><b>상품</b></div><select id="d-p">${sn.products.map((p) => `<option value="${p.id}">${esc(p.name)} · ${+p.interestRate}% / ${p.termDays}일</option>`).join('')}</select></div>
    <div class="setrow"><div class="lbl"><b>금액</b></div><span class="unit"><input id="d-a" type="number" min="1" step="100" value="${Math.floor(c.cash)}"><em>원</em><button class="btn sm" id="d-max">전액</button></span></div>
    <div class="callout" id="d-prev"></div>
    <div class="actions"><button class="btn" data-act="mclose">취소</button><button class="btn pri" id="d-go">가입하기</button></div>`,
  (m) => {
    const prev = () => { const p = sn.products.find((x) => x.id == $('#d-p', m).value), a = Math.floor(num($('#d-a', m).value)); $('#d-prev', m).innerHTML = p && a > 0 ? `만기(${p.termDays}일 후) 수령액 <b>${won(a * (1 + p.interestRate / 100))}</b> <span class="ok">(+${won((a * p.interestRate) / 100)})</span>` : '금액을 입력해 주세요'; };
    $('#d-p', m).onchange = prev; $('#d-a', m).oninput = prev; $('#d-max', m).onclick = () => { $('#d-a', m).value = Math.floor(c.cash); prev(); }; prev();
    $('#d-go', m).onclick = async () => {
      const a = Math.floor(num($('#d-a', m).value));
      if (a < 1 || a > c.cash) return toast('금액을 확인해 주세요 (현금 ' + won(c.cash) + ')', 'bad');
      const r = await api('/api/manual', { kind: 'deposit', productId: +$('#d-p', m).value, amount: a });
      toast(r.ok ? '예금에 가입했습니다' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); if (r.ok) { closeModal(); refresh(); }
    };
  });
}

/* ───────── 페이지: 상점 ───────── */
function pStore() {
  const sn = S.snap; if (!sn) return waiting();
  ensureData('users'); // 선물 받는 사람 목록
  const cats = sn.categories || [], wish = new Set(S.cfg.store.wishlist || []);
  const cn = Object.fromEntries(cats.map((x) => [x.id, x.name]));
  let list = (sn.items || []).filter((i) => i.isActive !== false);
  if (ui.cat === 'wish') list = list.filter((i) => wish.has(i.id)); else if (ui.cat === 'stock') list = list.filter((i) => i.stock > 0); else if (ui.cat !== 'all') list = list.filter((i) => i.categoryId == ui.cat);
  if (ui.storeQ) list = list.filter((i) => i.name.includes(ui.storeQ));
  list.sort({ stock: (a, b) => (b.stock > 0) - (a.stock > 0) || a.price - b.price, low: (a, b) => a.price - b.price, high: (a, b) => b.price - a.price, name: (a, b) => a.name.localeCompare(b.name, 'ko') }[ui.storeSort]);
  const P = (sn.purchases || []).slice().sort((a, b) => b.purchasedAt.localeCompare(a.purchasedAt));
  const own = P.filter((p) => p.status !== 'used' && p.status !== 'refunded');
  const src = { purchase: '구매', gift: '선물', teacher_distribute: '교사 지급' };
  const spent = P.filter((p) => p.source === 'purchase' && p.status !== 'refunded').reduce((s, p) => s + num(p.totalPrice), 0);
  return `<div class="stack view-anim">
  <div class="callout">상점 구매·사용·환불·선물을 여기서 할 수 있어요. <b>자동으로는 절대 사지 않고</b>, 직접 누르고 확인 창에서 한 번 더 확인할 때만 실행돼요. ★ 관심 상품은 재입고·가격 인하 때 알려 드립니다. <a href="https://economyclass-t.replit.app/store" target="_blank">사이트 상점 ↗</a></div>
  <div class="card"><div class="row" style="margin-bottom:14px"><div class="chips">${[['all', '전체'], ...cats.map((x) => [x.id, x.name]), ['stock', '재고 있음'], ['wish', '★ 관심']].map(([k, l]) => `<span class="chip ${String(ui.cat) === String(k) ? 'on' : ''}" data-act="cat" data-v="${k}">${esc(l)}</span>`).join('')}</div>
      <select data-act-change="storeSort" class="right">${[['stock', '재고 있는 것 먼저'], ['low', '가격 낮은 순'], ['high', '가격 높은 순'], ['name', '이름순']].map(([k, l]) => `<option value="${k}" ${ui.storeSort === k ? 'selected' : ''}>${l}</option>`).join('')}</select><input id="sq" type="search" placeholder="아이템 검색" value="${esc(ui.storeQ)}"></div>
    ${list.length ? `<div class="items">${list.map((i) => `<div class="item ${i.stock <= 0 ? 'out' : ''}"><button class="star ${wish.has(i.id) ? 'on' : ''}" data-act="wish" data-id="${i.id}" title="관심 상품">★</button><span class="tag" style="align-self:flex-start">${esc(cn[i.categoryId] || '기타')}</span><div class="nm">${esc(i.name)}</div><div class="ds">${esc(i.description || '')}</div><div class="row sb"><span class="mid num">${won(i.price)}</span><span class="pill ${i.stock > 0 ? 'ok' : 'gray'}">${i.stock > 0 ? '재고 ' + i.stock : '품절'}</span></div>${i.stock > 0 ? `<button class="btn sm pri" data-act="buyitem" data-id="${i.id}">구매하기</button>` : '<button class="btn sm" disabled>품절</button>'}</div>`).join('')}</div>` : empty('🛍', '조건에 맞는 아이템이 없습니다')}
  </div>
  <div class="grid g2">
    <div class="card"><h2>내 아이템 <small>미사용 ${own.length}개</small></h2>${own.length ? `<table><tbody>${own.map((p) => `<tr><td><b>${esc(p.itemName)}</b> ×${p.quantity}<div class="xs mute">${src[p.source] || p.source}${p.giftSender ? ' · ' + esc(p.giftSender) : ''} · ${fd(p.purchasedAt)}</div></td><td class="r"><span class="row" style="justify-content:flex-end;flex-wrap:nowrap"><button class="btn sm pri" data-act="useitem" data-id="${p.id}" data-n="${esc(p.itemName)}" data-q="${p.quantity}">사용</button><button class="btn sm" data-act="giftitem" data-id="${p.id}" data-n="${esc(p.itemName)}">선물</button>${p.source === 'purchase' ? `<button class="btn sm danger" data-act="refunditem" data-id="${p.id}" data-n="${esc(p.itemName)}">환불</button>` : ''}</span></td></tr>`).join('')}</tbody></table>` : empty('🎒', '지금 가진 아이템이 없습니다', '구매·선물받은 아이템 중 아직 안 쓴 것이 여기 표시돼요.')}</div>
    <div class="card"><h2>구매·수령 이력 <small>총 구매 ${won(spent)}</small></h2><div class="tscroll" style="max-height:340px"><table><tbody>${P.map((p) => `<tr><td>${esc(p.itemName)} ×${p.quantity}<div class="xs mute">${src[p.source] || p.source} · ${p.status === 'used' ? '사용함' : p.status === 'refunded' ? '환불됨' : esc(p.status)}</div></td><td class="r sm">${p.source === 'purchase' ? won(p.totalPrice) : ''}<div class="xs mute">${fd(p.purchasedAt)}</div></td></tr>`).join('')}</tbody></table></div></div>
  </div></div>`;
}

/* ───────── 페이지: 직업 ───────── */
function pJob() {
  const sn = S.snap, j = S.job; if (!sn) return waiting();
  const DN = ['월', '화', '수', '목', '금', '토', '일'];
  const w = j?.watch, it = j?.items?.[0], ml = j?.meals, mj = sn.work?.currentJobId;
  const week = j ? `<div class="week">${DN.map((n, i) => { const d = new Date(j.weekStart + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + i); const ds = d.toISOString().slice(0, 10); const done = it?.doneDates?.includes(ds); return `<span class="${done ? 'done' : ''} ${i > 4 ? 'off' : ''} ${ds === j.today ? 'today' : ''}"><b>${n}</b>${done ? '✓' : '·'}</span>`; }).join('')}</div>` : '';
  return `<div class="stack view-anim">
  <div class="grid g2">
    <div class="card"><h2>내 직업 체크 <span class="row"><span class="sm mute">자동 체크</span>${modeSeg('job.mode', S.cfg.job.mode)}</span></h2>
      ${j && it ? `<div class="row sb"><div><div class="mid">${esc(it.title)}</div><div class="sm mute">주급 ${won(it.salary)} · 주 ${it.target}일 목표</div></div><span class="pill ${w?.todayStatus === 'completed' ? 'ok' : j.isWorkday ? 'warn' : 'gray'}">${w?.todayStatus === 'completed' ? '오늘 완료 ✅' : j.isWorkday ? '오늘 미완료 ⚠' : '오늘 휴무'}</span></div>
      <div style="margin:16px 0">${week}</div>
      <div class="bar" style="margin-bottom:6px"><i style="width:${Math.min(100, (it.done / it.target) * 100)}%"></i></div><div class="sm mute">${it.done}/${it.target}일 완료 · 달성률 ${it.pct}% → 이번 주 예상 <b>${won(it.expected)}</b></div>
      ${j.payrollNote ? `<div class="callout" style="margin-top:12px">⚠ ${esc(j.payrollNote)}${j.legacyJobs?.length ? ` <span class="xs mute">(이전 직업: ${esc(j.legacyJobs.join(', '))})</span>` : ''}</div>` : ''}
      ${j.isWorkday && w?.todayStatus !== 'completed' ? `<div class="row" style="margin-top:12px"><button class="btn pri" data-act="markjob" data-date="${esc(j.today)}">오늘 직업 완료 체크</button><span class="xs mute">일을 마쳤을 때만 눌러 주세요 (사이트의 완료 버튼과 같아요)</span></div>` : ''}
      <hr class="sep"><dl class="kv"><dt>직전 근무일</dt><dd>${esc(w?.prevDate || '-')} ${w?.prevStatus === 'completed' ? '<span class="ok">완료</span>' : '<span class="bad">미완료</span>'}${w?.prevEditable ? ' <span class="xs mute">(수정 가능)</span>' : ''}</dd><dt>알림</dt><dd>${S.cfg.job.remind ? `${S.cfg.job.remindHour}시 이후 미완료면 매시간` : '꺼짐'}</dd></dl>`
        : empty('🗓', '직업 정보를 불러오지 못했습니다')}
      <div class="callout" style="margin-top:14px"><b>자동 모드</b>는 급식 관리 직업일 때, 급식 기록이 반 전원 입력된 날에만 완료 체크를 대신 눌러요. 지금 직업처럼 확인할 기록이 없으면 자동 체크는 하지 않고 알림만 보냅니다.</div></div>
    <div class="card"><h2>급식 기록 진행 <a class="sm" href="https://economyclass-t.replit.app/meals" target="_blank">급식 기록 열기 ↗</a></h2>
      ${ml ? `<div class="row sb"><div class="big num">${ml.filled}<span class="mute mid">/${ml.total}명</span></div><span class="pill ${ml.filled >= ml.total ? 'ok' : 'warn'}">${esc({ draft: '작성 중', final: '확정', finalized: '확정' }[ml.status] || ml.status)}</span></div><div class="bar" style="margin:12px 0"><i style="width:${ml.total ? (ml.filled / ml.total) * 100 : 0}%"></i></div><div class="sm mute">${ml.filled < ml.total ? '점심 때 기록을 입력해 주세요. 전원 입력되면 자동 모드가 완료 체크를 합니다.' : '모두 기록되었습니다.'}</div>` : j && j.mealAccess === false ? `<div class="callout">지금 직업(<b>${esc(it?.title || '')}</b>)은 급식 기록 대상이 아니라서 이 칸은 쓰지 않아요.<br><span class="xs mute">직업 체크는 일을 마친 뒤 사이트나 왼쪽의 “오늘 직업 완료 체크”로 해 주세요. 프로그램은 완료 여부를 매시간 지켜보고 알려 줘요.</span></div>` : empty('🍱', '급식 기록 정보를 불러오지 못했습니다')}
    </div>
  </div>
  <div class="card"><h2>직업표 <span class="row"><small>주급은 주간 목표 달성 비율만큼 받아요</small><button class="btn sm" data-act="refresh">불러오기</button></span></h2>
    ${sn.jobs?.length ? `<div class="tscroll"><table><thead><tr><th>직업</th><th class="r">주급(100%)</th><th class="r">주간 목표</th><th class="r">1회당</th><th class="r">정원</th><th>권한</th></tr></thead><tbody>${sn.jobs.slice().sort((a, b) => b.salary - a.salary).map((x) => `<tr ${x.id === mj ? 'style="background:var(--priSoft)"' : ''}><td><b>${esc(x.title)}</b> ${x.id === mj ? '<span class="tag">내 직업</span>' : ''}</td><td class="r num">${won(x.salary)}</td><td class="r">${x.weeklyTarget}일</td><td class="r num">${won(x.salary / (x.weeklyTarget || 1))}</td><td class="r">${x.maxStudents}명</td><td class="xs mute">${esc((x.permissions || []).join(', ')) || '-'}</td></tr>`).join('')}</tbody></table></div>` : empty('📋', '직업 목록이 비어 있습니다')}
    <div class="xs mute" style="margin-top:8px">직업 신청·변경은 사이트에서 직접 합니다. <a href="https://economyclass-t.replit.app/jobs" target="_blank">사이트 직업 ↗</a></div></div>
  <div class="card"><h2>수수료·이자 점검 <small>${S.feeCheck?.day || ''}</small></h2>${S.feeCheck ? `<dl class="kv"><dt>주식 수수료</dt><dd>편도 ${(S.feeCheck.ratePerSide * 100).toFixed(2)}% · 왕복 ${S.feeCheck.roundTripPct}%</dd><dt>최근 주문 수수료율</dt><dd>${S.feeCheck.lastOrderRate == null ? '체결 주문 없음' : (S.feeCheck.lastOrderRate * 100).toFixed(2) + '%'} ${S.feeCheck.mismatch ? '<span class="bad">설정과 불일치!</span>' : ''}</dd><dt>송금</dt><dd>${S.feeCheck.transferEnabled ? S.feeCheck.transferFee + '%' : '비활성'}</dd></dl>` : '<div class="sm mute">점검 전</div>'}</div>
  </div>`;
}

/* ───────── 경제교실 기능: 상점 구매·사용 / 기부 / 벌금 / 자리 경매 / 게시판 / 송금 ───────── */
// 모든 실행은 사용자가 직접 누르고 확인 창을 거친 뒤에만 서버로 전달됨(서버도 confirm 없으면 거부)
const svc = (op, body) => api('/api/svc/' + op, { ...body, confirm: true });
ui.data = {}; ui.loading = {};
function ensureData(name) {
  if (ui.data[name] !== undefined || ui.loading[name]) return ui.data[name];
  ui.loading[name] = true;
  api('/api/data/' + name).then((r) => { ui.data[name] = r.ok ? r.data : null; ui.err = ui.err || {}; ui.err[name] = r.ok ? '' : r.error; })
    .catch(() => { ui.data[name] = null; }).finally(() => { ui.loading[name] = false; lastSig = ''; render(true); });
  return undefined;
}
const reload = (name) => { delete ui.data[name]; lastSig = ''; render(true); };
const loadingBox = (name) => `<div class="card">${ui.loading[name] || ui.data[name] === undefined ? empty('⏳', '불러오는 중…') : empty('⚠', '불러오지 못했어요', esc(ui.err?.[name] || ''))}</div>`;
const doOp = async (op, body, okMsg, after) => { const r = await svc(op, body); toast(r.ok ? okMsg : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); if (r.ok) { after?.(); refresh(); } return r; };

function pDonate() {
  const d = ensureData('goals'); if (!d) return loadingBox('goals');
  const c = calc(); const cash = c?.cash ?? 0;
  const prog = (g) => { const p = (d.progress || []).find((x) => x.goalId == g.id || x.id == g.id) || {}; const cur = num(p.currentAmount ?? p.totalAmount ?? p.total ?? p.amount ?? p.raised ?? 0); const tg = num(g.targetAmount); return { cur, tg, pct: tg ? Math.min(100, (cur / tg) * 100) : 0, n: p.donorCount ?? p.donors ?? null }; };
  return `<div class="stack view-anim">
  <div class="grid g2">${(d.goals || []).filter((g) => g.isActive !== false).map((g) => { const p = prog(g); return `<div class="card"><h2>${esc(g.rewardTitle)} ${g.isAchieved ? '<span class="pill ok">달성</span>' : ''}</h2><div class="sm mute" style="white-space:pre-wrap">${esc(g.rewardDescription || '')}</div><div class="bar" style="margin:12px 0 6px"><i style="width:${p.pct}%"></i></div><div class="row sb sm"><span><b>${won(p.cur)}</b> / ${won(p.tg)}</span><span class="mute">${p.pct.toFixed(1)}%${p.n != null ? ` · ${p.n}명` : ''}</span></div></div>`; }).join('') || `<div class="card">${empty('💝', '진행 중인 기부 목표가 없어요')}</div>`}</div>
  <div class="card"><h2>기부하기 <small>현재 현금 ${won(cash)}</small></h2>
    <div class="row"><select id="dn-goal"><option value="none">일반 기부 (목표 선택 안 함)</option>${(d.goals || []).filter((g) => g.isActive !== false).map((g) => `<option value="${g.id}">${esc(g.rewardTitle)}</option>`).join('')}</select><span class="unit"><input id="dn-amt" type="number" min="1" step="100" placeholder="금액"><em>원</em></span></div>
    <div class="row"><input id="dn-msg" class="wide" style="width:100%;max-width:420px" maxlength="60" placeholder="응원 메시지 (선택)"><label class="k"><input id="dn-anon" type="checkbox"> 익명으로</label></div>
    <div class="row"><button class="btn pri" data-act="donate">기부하기</button><span class="xs mute">기부한 돈은 돌려받을 수 없어요. 직접 누를 때만 실행됩니다.</span></div></div>
  <div class="grid g2">
    <div class="card"><h2>최근 기부</h2>${(d.recent || []).length ? `<table><tbody>${(d.recent || []).slice(0, 10).map((x) => `<tr><td><b>${esc(x.isAnonymous ? '익명' : (x.user?.name || x.donorName || x.userName || x.name || '익명'))}</b><div class="xs mute">${esc(x.message || '')}</div></td><td class="r num">${won(x.amount)}<div class="xs mute">${fd(x.createdAt)}</div></td></tr>`).join('')}</tbody></table>` : empty('🕊', '아직 기부가 없어요')}</div>
    <div class="card"><h2>기부 순위</h2>${(d.ranking || []).length ? `<table><tbody>${(d.ranking || []).slice(0, 10).map((x, i) => `<tr><td style="width:28px"><b>${i + 1}</b></td><td>${esc(x.donorName || x.userName || x.name || '익명')}</td><td class="r num">${won(x.totalDonated ?? x.totalAmount ?? x.total ?? x.amount)}</td></tr>`).join('')}</tbody></table>` : empty('🏆', '순위가 아직 없어요')}</div>
  </div></div>`;
}
function pFines() {
  const d = ensureData('fines'); if (!d) return loadingBox('fines');
  const c = calc(); const list = d.data || [];
  const total = list.reduce((s, f) => s + num(f.finalAmount ?? f.amount), 0);
  const max = Math.max(0, ...list.map((f) => num(f.finalAmount ?? f.amount)));
  const rec = Math.ceil((max || 3000) / 500) * 500;
  return `<div class="stack view-anim">
  <div class="grid g3">
    <div class="card"><div class="mute sm">내가 받은 벌금 <span class="xs">(최근 ${list.length}건)</span></div><div class="big num bad">${won(total)}</div></div>
    <div class="card"><div class="mute sm">가장 큰 벌금</div><div class="mid num">${won(max)}</div><div class="xs mute">벌금은 현금에서 바로 빠져요</div></div>
    <div class="card"><div class="mute sm">현재 현금</div><div class="mid num ${c && c.cash < 0 ? 'bad' : ''}">${won(c?.cash)}</div><div class="xs mute">남겨 둘 현금 ${won(S.cfg.cashReserve)}</div></div>
  </div>
  ${c && S.cfg.cashReserve < rec ? `<div class="callout">💡 <b>벌금 대비 안전 현금</b> — 벌금은 현금에서 바로 빠져요. 이 프로그램은 남는 현금을 예금·주식에 넣기 때문에, 현금을 비워 두면 벌금이 나올 때 <b>현금이 마이너스</b>가 될 수 있어요. 가장 큰 벌금(${won(max)})을 감당할 만큼 <b>${won(rec)}</b>을 “자동으로 쓰지 않을 현금”으로 남겨 두면 안전해요. (지금 설정: ${won(S.cfg.cashReserve)})
    <div class="row" style="margin-top:8px"><button class="btn sm pri" data-act="setreserve" data-v="${rec}">${won(rec)}로 설정</button><a class="btn sm" href="#/cfg" data-act="gocfg" data-sec="stock">설정에서 직접 바꾸기</a></div></div>` : ''}
  <div class="card"><h2>벌금 내역 <small>지각 등으로 받은 벌금</small><a class="sm" href="https://economyclass-t.replit.app/fines" target="_blank">사이트 벌금 장부 ↗</a></h2>
    ${list.length ? `<div class="tscroll"><table><thead><tr><th>날짜</th><th>항목</th><th class="r">금액</th><th>상태</th><th>메모</th></tr></thead><tbody>${list.map((f) => `<tr><td class="xs">${fdt(f.issuedAt)}</td><td><b>${esc(f.categoryName || '벌금')}</b></td><td class="r num bad">${won(f.finalAmount ?? f.amount)}${f.baseAmount && f.baseAmount !== f.finalAmount ? `<div class="xs mute">기본 ${won(f.baseAmount)} × ${num(f.assetMultiplier).toFixed(2)}</div>` : ''}</td><td>${f.status === 'paid' ? '<span class="pill gray">처리됨</span>' : f.status === 'cancelled' ? '<span class="pill gray">취소됨</span>' : `<span class="pill warn">${esc(f.status)}</span>`}</td><td class="xs mute">${esc(f.notes || '')}</td></tr>`).join('')}</tbody></table></div>` : empty('🎉', '받은 벌금이 없어요')}</div></div>`;
}
function pAuction() {
  const d = ensureData('auction'); if (!d) return loadingBox('auction');
  const sess = d.session, auctions = d.auctions || [];
  const cash = calc()?.cash ?? 0;
  return `<div class="stack view-anim"><div class="card"><h2>자리 경매 <span class="row"><button class="btn sm" data-act="reload" data-n="auction">새로고침</button><a class="sm" href="https://economyclass-t.replit.app/seat-auction" target="_blank">사이트 ↗</a></span></h2>
    ${sess && sess.id ? `<div class="row sb"><div><b>진행 중인 경매</b><div class="sm mute">상태 ${esc(sess.status)} · 현금 ${won(cash)}</div></div><span class="pill ${sess.status === 'active' ? 'ok' : 'warn'}">${esc(sess.status)}</span></div>
      ${auctions.length ? `<table style="margin-top:12px"><thead><tr><th>좌석</th><th class="r">현재가</th><th>상태</th><th></th></tr></thead><tbody>${auctions.map((a) => `<tr><td><b>#${esc(a.seatId)}</b></td><td class="r num">${won(a.currentPrice ?? a.startingPrice)}</td><td>${esc(a.status)}</td><td>${a.status === 'active' ? `<span class="row"><input type="number" id="bid-${a.id}" style="width:100px" value="${num(a.currentPrice ?? a.startingPrice) + 1000}" step="100"><button class="btn sm pri" data-act="bid" data-id="${a.id}" data-cur="${num(a.currentPrice ?? a.startingPrice)}">입찰</button></span>` : ''}</td></tr>`).join('')}</tbody></table>` : empty('🪑', '입찰할 수 있는 좌석이 아직 없어요', '선생님이 좌석 경매를 열면 여기에 나타나요.')}`
      : empty('🪑', '지금 진행 중인 자리 경매가 없어요', '경매가 열리면 알림으로 알려 드릴게요(좌석 입찰은 여기서 직접 할 수 있어요).')}
    <div class="xs mute" style="margin-top:10px">입찰은 되돌릴 수 없어요. 현재가보다 높은 금액만 가능합니다.</div></div></div>`;
}
function pBoard() {
  const d = ensureData('posts'); if (!d) return loadingBox('posts');
  const posts = d.data || [];
  return `<div class="stack view-anim"><div class="card"><h2>글쓰기</h2><textarea id="bd-text" rows="3" style="width:100%" maxlength="2000" placeholder="남기고 싶은 말을 적어 주세요"></textarea><div class="row"><button class="btn pri" data-act="post">올리기</button><span class="xs mute">모든 친구가 볼 수 있는 글이에요. 직접 누를 때만 올라가요.</span></div></div>
  <div class="card"><h2>게시판 <button class="btn sm" data-act="reload" data-n="posts">새로고침</button></h2>${posts.length ? posts.slice(0, 40).map((p) => `<div class="sug" style="display:block;margin-bottom:10px"><div class="row sb"><b>${esc(p.author?.name || p.authorId)}</b><span class="xs mute">${fdt(p.createdAt)}</span></div><div class="sm" style="white-space:pre-wrap;margin:6px 0">${esc(p.content)}</div><div class="row"><button class="btn sm ghost" data-act="like" data-id="${p.id}">👍 ${p.likeCount ?? p.likes ?? ''}</button><button class="btn sm ghost" data-act="comment" data-id="${p.id}">💬 댓글 ${p.commentCount ?? p.comments?.length ?? ''}</button></div></div>`).join('') : empty('💬', '아직 글이 없어요')}</div></div>`;
}
function transferCard() {
  const st = S.snap?.settings; const on = st && st.transferEnabled !== false;
  if (!on) return `<div class="card"><h2>송금</h2><div class="callout">지금은 선생님이 <b>송금을 막아 두었어요</b>. 열리면 여기서 보낼 수 있어요. <span class="xs mute">(수수료 ${(num(st?.transferFeeRate) * 100).toFixed(1)}%, 최소 ${won(st?.transferFeeMin)})</span></div></div>`;
  const u = ensureData('users');
  return `<div class="card"><h2>송금 <small>수수료 ${(num(st.transferFeeRate) * 100).toFixed(1)}% (최소 ${won(st.transferFeeMin)})</small></h2>${u ? `<div class="row"><select id="tf-to">${u.filter((x) => x.id !== S.snap.user.id).map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select><span class="unit"><input id="tf-amt" type="number" min="1" step="100" placeholder="금액"><em>원</em></span><button class="btn pri" data-act="transfer">보내기</button></div>` : '<div class="sm mute">친구 목록을 불러오는 중…</div>'}</div>`;
}
function itemBuy(id) {
  const c = calc(), it = (S.snap.items || []).find((x) => x.id === +id); if (!it) return;
  openModal(`<div class="row sb"><h3>${esc(it.name)}</h3><button class="btn ghost sm" data-act="mclose">✕</button></div><div class="sm mute">${esc(it.description || '')}</div>
    <div class="callout" style="margin:12px 0">가격 <b>${won(it.price)}</b> · 재고 ${it.stock}개 · 현재 현금 ${won(c.cash)}${it.isRefundable === false ? '<br><span class="bad">환불이 안 되는 아이템이에요.</span>' : ''}</div>
    <div class="row"><b class="sm">수량</b><input id="bq" type="number" min="1" max="${it.stock}" value="1" style="width:80px"><span class="sm" id="btot"></span></div>
    <div class="actions"><button class="btn" data-act="mclose">취소</button><button class="btn pri" id="bgo">구매하기</button></div>`, (m) => {
    const upd = () => { const q = Math.max(1, Math.floor(num($('#bq', m).value))); const t = q * num(it.price); $('#btot', m).innerHTML = `합계 <b>${won(t)}</b>${t > c.cash ? ' <span class="bad">· 현금 부족</span>' : ''}`; return [q, t]; };
    $('#bq', m).oninput = upd; upd();
    $('#bgo', m).onclick = async () => { const [q, t] = upd(); if (t > c.cash) return toast('현금이 부족해요', 'bad'); if (!(await confirmBox('구매할까요?', `${esc(it.name)} ×${q}<br>합계 <b>${won(t)}</b>${it.isRefundable === false ? '<br><b class="bad">환불 불가</b>' : ''}`, '구매'))) return; const r = await doOp('buy', { itemId: it.id, quantity: q }, `${it.name} ${q}개를 구매했어요`, closeModal); };
  });
}
function itemGift(purchaseId, name) {
  const u = ensureData('users');
  openModal(`<div class="row sb"><h3>🎁 선물하기</h3><button class="btn ghost sm" data-act="mclose">✕</button></div><div class="sm mute">${esc(name)}을(를) 친구에게 선물해요. 보낸 선물은 되돌릴 수 없어요.</div>
    <div class="row" style="margin-top:12px"><select id="gt">${(u || []).filter((x) => x.id !== S.snap.user.id).map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select><input id="gm" class="wide" placeholder="메시지(선택)" maxlength="60"></div>
    <div class="actions"><button class="btn" data-act="mclose">취소</button><button class="btn pri" id="ggo">보내기</button></div>`, (m) => {
    $('#ggo', m).onclick = async () => { const to = $('#gt', m).value; const nm = $('#gt', m).selectedOptions[0]?.textContent; if (!(await confirmBox('선물을 보낼까요?', `${esc(name)} → <b>${esc(nm)}</b>`, '보내기'))) return; await doOp('sendItem', { purchaseId, toUserId: to, message: $('#gm', m).value, quantity: 1 }, '선물을 보냈어요', closeModal); };
  });
}

/* ───────── 페이지: 점검 · 알림 · 내역 ───────── */
function pReg() {
  const r = S.reg;
  const G = { site: ['🌐', '경제교실 사이트 연동'], logic: ['🧮', '판단 로직'], guard: ['🛡', 'AI 안전장치'], infra: ['🔧', '프로그램 환경'] };
  return `<div class="stack view-anim"><div class="card"><h2>전체 회귀 점검 <small>읽기 전용 · ${S.cfg.selfTest.intervalMinutes}분마다 자동</small><button class="btn pri sm" data-act="runreg" ${S.regBusy ? 'disabled' : ''}>${S.regBusy ? '점검 중…' : '지금 점검'}</button></h2>
    ${r ? `<div class="row"><span class="big ${r.failed ? 'bad' : 'ok'}">${r.passed}/${r.total}</span><div><b>${r.failed ? `실패 ${r.failed}건` : '모두 통과'}</b><div class="sm mute">${fdt(r.at)} · ${esc(r.why)}</div></div></div><div class="bar" style="margin-top:12px"><i style="width:${(r.passed / r.total) * 100}%"></i></div>` : empty('🧪', '아직 점검 전입니다', '시작 2분 뒤 자동으로 첫 점검이 돌아가요.')}</div>
    ${r ? Object.entries(G).map(([g, [ic, l]]) => { const c = r.checks.filter((x) => x.group === g); return c.length ? `<div class="card"><h2>${ic} ${l} <small>${c.filter((x) => x.ok).length}/${c.length}</small></h2><table><tbody>${c.map((x) => `<tr><td style="width:30px">${x.ok ? '✅' : '❌'}</td><td><b>${esc(x.name)}</b></td><td class="sm ${x.ok ? 'mute' : 'bad'}">${esc(x.detail)}</td><td class="r xs mute">${x.ms}ms</td></tr>`).join('')}</tbody></table></div>` : ''; }).join('') : ''}</div>`;
}
const EVT = { login_lost: ['🔐', '로그아웃', 'bad'], matured: ['🏦', '예금 만기', 'ok'], order: ['🧾', '주문', 'info'], advice: ['💡', '제안', 'info'], job: ['🗓', '직업', 'warn'], site_changed: ['🔄', '사이트 변경', 'warn'], store: ['🛍', '상점', 'info'], error: ['⚠', '오류', 'bad'], action: ['⚡', '실행', 'ok'], system: ['💻', '시스템', 'info'] };
function pAlerts() {
  const items = S.log.filter((l) => l.type === 'notify').map((l) => { const m = l.msg.match(/^\[(\w+)\]\s*(.*)$/s) || [0, 'action', l.msg]; return { t: l.t, ev: m[1], text: m[2] }; });
  const shown = ui.alertType === 'all' ? items : items.filter((x) => x.ev === ui.alertType);
  return `<div class="stack view-anim"><div class="card"><h2>알림 기록 <button class="btn sm" data-act="testnoti">테스트 알림 보내기</button></h2>
    <div class="chips" style="margin-bottom:12px">${[['all', '전체'], ...Object.entries(EVT).map(([k, v]) => [k, v[1]])].map(([k, l]) => `<span class="chip ${ui.alertType === k ? 'on' : ''}" data-act="atype" data-v="${k}">${l}</span>`).join('')}</div>
    ${shown.length ? shown.map((x) => { const e = EVT[x.ev] || ['🔔', x.ev, '']; return `<div class="sug" style="margin-bottom:8px;display:flex;gap:12px;justify-content:flex-start;align-items:flex-start"><span style="font-size:20px">${e[0]}</span><div style="min-width:0"><div class="row"><span class="pill ${e[2]}">${e[1]}</span><span class="xs mute">${fdt(x.t)}</span></div><div class="sm" style="margin-top:4px;white-space:pre-wrap;word-break:break-word">${esc(x.text)}</div></div></div>`; }).join('') : empty('🔕', '알림이 없습니다')}</div></div>`;
}
const LOGC = { action: 'ok', error: 'bad', notify: 'warn', ai: 'info', change: 'warn', selftest: 'info', auth: 'bad' };
function pLog() {
  const types = [...new Set(S.log.map((l) => l.type))];
  const rows = S.log.filter((l) => (ui.logType === 'all' || l.type === ui.logType) && (!ui.logQ || l.msg.toLowerCase().includes(ui.logQ.toLowerCase())));
  return `<div class="card view-anim"><h2>활동 내역 <small>최근 ${S.log.length}건</small></h2>
    <div class="row" style="margin-bottom:12px"><div class="chips">${['all', ...types].map((k) => `<span class="chip ${ui.logType === k ? 'on' : ''}" data-act="ltype" data-v="${k}">${k === 'all' ? '전체' : k}</span>`).join('')}</div><input id="lq" type="search" placeholder="검색" value="${esc(ui.logQ)}" class="right"></div>
    <div class="log">${rows.map((l) => `<div><span class="ts">${fdt(l.t)}</span><span class="ty ${LOGC[l.type] || 'mute'}">${esc(l.type)}</span><span class="tx">${esc(l.msg)}</span></div>`).join('') || empty('📜', '내역이 없습니다')}</div></div>`;
}

/* ───────── 페이지: 설정 ───────── */
const PRESETS = {
  conservative: ['보수적', { dipPct: 6, bouncePct: 1, takeProfitPct: 6, stopLossPct: 4, maxPositionPct: 15, maxPositions: 2 }],
  balanced: ['균형', { dipPct: 4, bouncePct: 0.5, takeProfitPct: 4, stopLossPct: 6, maxPositionPct: 25, maxPositions: 3 }],
  aggressive: ['공격적', { dipPct: 3, bouncePct: 0.3, takeProfitPct: 3, stopLossPct: 8, maxPositionPct: 40, maxPositions: 4 }],
};
const NOTI = { login_lost: ['로그아웃 감지', '사이트 로그인이 풀렸을 때'], matured: ['예금 만기', '직접 만든 예금이 만기가 됐을 때'], order: ['주문 상태 변경', '주문이 체결·취소됐을 때'], advice: ['제안 발생', '승인이 필요한 제안이 생겼을 때'], job: ['직업 체크 알림', '오늘 직업이 미완료일 때'], site_changed: ['사이트·수수료·이자 변경', '설정이나 상품이 바뀌었을 때'], store: ['상점 변경·관심 상품', '관심 상품 재입고·가격 인하'], system: ['프로그램 시작·재시작', 'PC가 켜지거나 프로그램이 다시 시작됐을 때'], error: ['오류', 'AI·점검 실패 등'], action: ['자동 실행 결과', '프로그램이 자동으로 실행했을 때'] };
function linkSection(c) {
  const cl = ui.claude, sy = ui.sys;
  const clPill = !cl ? '<span class="pill gray">확인 전</span>' : cl.loggedIn ? `<span class="pill ok">로그인됨${cl.longToken ? ' · 장기 토큰 사용 중' : ''}</span>` : `<span class="pill bad">로그인 필요</span>`;
  const sw = (which, on) => `<label class="switch"><input type="checkbox" data-act-change="task" data-which="${which}" ${on ? 'checked' : ''}><i></i></label>`;
  const ka = c.system?.keepAwake || 'off';
  return `
  <div class="callout" style="margin-bottom:6px"><b>꺼져도 계속 돌아가게 하려면</b> ① 아래 <b>절전 방지</b>를 켜고 ② <b>윈도우 시작 시 자동 실행</b>과 <b>자동 복구</b>를 켜고 ③ 폰 링크(ntfy)를 저장해 두세요. 화면이 꺼져도 프로그램은 계속 돌고, 알림은 폰으로 옵니다.</div>
  <h3 style="margin:16px 0 4px;font-size:13px;color:var(--ink2)">🤖 Claude 로그인</h3>
  ${cs('', '현재 상태', 'AI 판단은 Claude 로그인이 필요해요', `<span class="row">${clPill}<button class="btn sm" data-act="claudeStatus">상태 확인</button></span>`)}
  ${cs('', '로그인 창 열기', '<code>claude auth login</code> 을 대신 실행해 줘요. 브라우저에서 승인만 누르면 됩니다', '<button class="btn sm pri" data-act="claudeLogin">로그인 열기</button>')}
  ${cs('', '오래 유지하기 (장기 토큰)', '한 번만 설정하면 매일 다시 로그인하지 않아도 돼요. 새 창이 열리면 안내를 따라 주세요', '<button class="btn sm" data-act="tokenSetup">장기 토큰 설정</button>')}
  ${cs('', '풀리면 자동으로 로그인 창 열기', '6시간에 한 번만 열고 알림으로 알려 줘요 (승인 클릭만 하면 됨)', csw('ai.autoRelogin', c.ai.autoRelogin !== false))}
  <h3 style="margin:20px 0 4px;font-size:13px;color:var(--ink2)">📱 ntfy · 폰 링크</h3>
  ${cs('', '링크', '저장하면 “폰” 칸이 켜진 알림이 이 링크로 가요', `<span class="row"><input class="wide" style="width:300px" id="ntfy-url" value="${esc(c.notify.phoneUrl || '')}" placeholder="https://ntfy.sh/내-주제-이름"><button class="btn sm" data-act="ntfySave">저장</button></span>`)}
  ${cs('', '안전한 링크 새로 만들기', '추측하기 어려운 무작위 이름으로 만들어요. 폰 ntfy 앱에서 이 이름을 구독하세요', '<button class="btn sm" data-act="ntfyNew">무작위 링크 만들기</button>')}
  ${cs('', '테스트 · 직접 보내기', '입력한 내용을 ntfy로 바로 보내 봐요', `<span class="row"><input id="ntfy-msg" style="width:260px" placeholder="보낼 메시지 (비우면 테스트)" value=""><button class="btn sm pri" data-act="ntfySend">보내기</button></span>`)}
  <h3 style="margin:20px 0 4px;font-size:13px;color:var(--ink2)">💤 절전 방지 · 백그라운드</h3>
  ${cs('', '절전 방지', '켜 두면 프로그램이 도는 동안 PC가 자동으로 잠들지 않아요. 노트북 덮개를 닫거나 직접 절전을 누르면 윈도우 설정대로 잠들 수 있어요', `<div class="seg">${[['off', '끔'], ['system', '화면은 꺼져도 OK'], ['display', '화면도 켜 둠']].map(([k, l]) => `<button data-act="setka" data-v="${k}" class="${ka === k ? 'on' : ''}">${l}</button>`).join('')}</div>`)}
  ${cs('', '윈도우 시작 시 자동 실행', '로그인하면 창 없이 백그라운드로 시작해요', sy ? sw('autostart', sy.autostart) : '<span class="mute sm">확인 중…</span>')}
  ${cs('', '자동 복구 (5분마다 확인)', '프로그램이 꺼져 있으면 다시 켜 줘요 (이미 켜져 있으면 아무 일도 안 해요)', sy ? sw('watchdog', sy.watchdog) : '<span class="mute sm">확인 중…</span>')}
  ${cs('', '프로그램 정보', '', `<span class="sm mute">${sy ? `PID ${sy.pid} · 시작 ${fdt(sy.startedAt)}` : '-'}</span>`)}`;
}
function mobileSection(c) {
  const r = c.remote || {}, st = ui.remote, dom = (localStorage.getItem('remoteDomain') || '').trim();
  const lan = st?.lan || [];
  return `
  <div class="callout" style="margin-bottom:8px"><b>휴대폰에서 이 화면을 쓰는 방법</b>
    <div class="sm" style="margin-top:6px;line-height:1.8">① <b>앱처럼 설치</b>: 휴대폰 브라우저로 접속한 뒤 메뉴 → <b>“홈 화면에 추가”</b> (아이콘이 생기고 주소창 없는 앱처럼 열려요)<br>
    ② <b>접속 경로</b>(아래 중 하나): 같은 와이파이 · <b>Tailscale</b>(무료 개인 VPN, 가장 안전) · <b>내 도메인 + Cloudflare Tunnel</b>(어디서나 https 주소)<br>
    ③ 처음 한 번 <b>“접속 링크”</b>로 들어가면 그 휴대폰은 90일 동안 로그인된 상태로 유지돼요. 링크를 아는 사람만 들어올 수 있으니 비밀번호처럼 다뤄 주세요.</div></div>
  ${cs('', '휴대폰 접속 허용', '끄면 이 PC 밖에서는 아무도 열 수 없어요(기본 꺼짐)', csw('remote.enabled', r.enabled))}
  ${cs('', '접속 허용 범위', '“이 PC만(터널/Tailscale용)”이 안전해요. “같은 와이파이”는 공유기에 연결된 다른 기기가 직접 접속하는 방식이고 프로그램을 다시 시작해야 적용돼요', csel('remote.listen', [['localhost', '이 PC만 (터널 · Tailscale 사용)'], ['all', '같은 와이파이의 기기도 (다시 시작 필요)']]))}
  ${cs('', '접속 링크', r.tokenHash ? `만든 시각 ${fdt(r.tokenAt)} · 새로 만들면 이전 링크는 바로 무효가 돼요` : '아직 링크가 없어요. 만들면 한 번만 화면에 보여 드려요', `<span class="row"><button class="btn sm pri" data-act="remoteLink">${r.tokenHash ? '새 링크 만들기' : '링크 만들기'}</button>${r.tokenHash ? '<button class="btn sm danger" data-act="remoteRevoke">링크 폐기</button>' : ''}</span>`)}
  ${ui.newLink ? `<div class="callout" style="margin:8px 0"><b>새 접속 링크 (지금만 보여요)</b>
    <div class="row" style="margin-top:8px"><span class="sm mute">내 도메인</span><input id="rm-domain" class="wide" style="width:240px" placeholder="app.내도메인.com" value="${esc(dom)}"><span class="xs mute">(없으면 비워 두세요)</span></div>
    ${[...(dom ? [`https://${dom}${ui.newLink.path}`] : []), ...lan.map((ip) => `http://${ip}:${ui.newLink.port}${ui.newLink.path}`)].map((u) => `<div class="row" style="margin-top:8px"><code style="word-break:break-all;flex:1;font-size:12px">${esc(u)}</code><button class="btn sm" data-act="copy" data-t="${esc(u)}">복사</button></div>`).join('') || '<div class="xs mute" style="margin-top:8px">도메인을 입력하거나 같은 와이파이 주소를 쓰려면 위에서 “같은 와이파이”를 고르세요. 경로만 필요하면: <code>' + esc(ui.newLink.path) + '</code></div>'}
    <div class="xs mute" style="margin-top:8px">경로 <code>${esc(ui.newLink.path)}</code> 앞에 접속 주소(https://내도메인 또는 http://PC-IP:${ui.newLink.port})를 붙이면 됩니다.</div></div>` : ''}
  ${cs('', '같은 와이파이 주소', 'PC의 내부 IP예요. “같은 와이파이” 범위로 바꾸고 다시 시작하면 이 주소로 열려요', `<span class="sm">${lan.length ? lan.map((i) => `<code>${esc(i)}:${st?.port || c.port}</code>`).join(' · ') : '확인 중…'}</span>`)}
  <div class="callout" style="margin-top:8px">🌐 <b>내 도메인으로 연결(Cloudflare Tunnel)</b>: 도메인을 Cloudflare에 두고 Zero Trust → Tunnels → 이 PC에 <code>cloudflared</code> 설치 → 공개 호스트 이름 <code>app.내도메인.com</code> → <code>http://localhost:${c.port}</code> 로 연결하면, 포트를 열지 않고도 https로 접속돼요. 자세한 순서는 <code>README-MOBILE.md</code> 에 있어요.</div>`;
}
async function loadRemote() { try { ui.remote = await api('/api/remote/status'); } catch {} lastSig = ''; render(true); }
async function loadSys() { try { ui.sys = await api('/api/system'); } catch {} lastSig = ''; render(true); }
const SOUNDS = [['none', '🔇 무음'], ['soft', '🔔 부드럽게'], ['default', '🔊 기본'], ['alert', '🚨 경고']];
const NPRESET = {
  quiet: ['조용히', { login_lost: ['p', 'alert'], error: ['p', 'alert'], job: ['p', 'soft'] }],
  normal: ['보통', null],
  all: ['모두 받기', 'all'],
};
function kindOf(u) { u = (u || '').trim(); if (!u) return null; if (/discord(app)?\.com\/api\/webhooks\//i.test(u)) return ['Discord', 'ok']; if (/hooks\.slack\.com\//i.test(u)) return ['Slack', 'ok']; if (/\/\/[^/]*ntfy[^/]*\/[^/?#]+/i.test(u)) return ['ntfy', 'ok']; return /^https?:\/\//i.test(u) ? ['일반 링크', 'info'] : ['주소 형식 아님', 'bad']; }
function notiSection(c) {
  const n = c.notify, ev = n.events || {}, kd = kindOf(n.phoneUrl);
  const rows = Object.entries(NOTI).map(([k, [l, h]]) => { const e = ev[k] || {}; return `<tr><td><b>${l}</b><div class="xs mute">${h}</div></td>
    <td class="c">${csw(`notify.events.${k}.popup`, e.popup)}</td><td class="c">${csw(`notify.events.${k}.system`, e.system)}</td>
    <td class="c"><span class="row" style="justify-content:center;flex-wrap:nowrap"><select data-set="notify.events.${k}.sound" id="snd-${k}">${SOUNDS.map(([v, lb]) => `<option value="${v}" ${e.sound === v ? 'selected' : ''}>${lb}</option>`).join('')}</select><button class="btn sm ghost" data-act="soundtest" data-k="${k}" title="미리듣기">▶</button></span></td>
    <td class="c">${csw(`notify.events.${k}.phone`, e.phone)}</td></tr>`; }).join('');
  return `
  ${cs('', '알림 전체', '끄면 어떤 알림도 보내지 않습니다 (기록은 남아요)', csw('notify.master', n.master))}
  ${cs('', '조용한 시간', '이 시간에는 소리를 끕니다 (창은 그대로 떠요)', `<span class="row"><label class="switch"><input type="checkbox" data-set="notify.quiet.enabled" ${n.quiet.enabled ? 'checked' : ''}><i></i></label><input type="time" data-set="notify.quiet.from" value="${esc(n.quiet.from)}"><em class="mute">~</em><input type="time" data-set="notify.quiet.to" value="${esc(n.quiet.to)}"></span>`)}
  ${cs('', '조용한 시간에도 긴급 알림은 소리 내기', '로그아웃·오류처럼 바로 알아야 하는 것만', csw('notify.quiet.allowUrgent', n.quiet.allowUrgent))}
  <div class="row" style="padding:14px 0 4px"><b class="sm">한 번에 설정</b><div class="seg">${Object.entries(NPRESET).map(([k, [l]]) => `<button data-act="npreset" data-v="${k}">${l}</button>`).join('')}</div><span class="xs mute">조용히 = 중요한 3가지만 · 보통 = 기본값 · 모두 받기 = 전부 켜기</span></div>
  <div class="tscroll" style="max-height:none"><table><thead><tr><th>알림 종류</th><th class="c">알림창<br><span class="xs">화면 오른쪽 아래</span></th><th class="c">윈도우 알림<br><span class="xs">알림센터에 남음</span></th><th class="c">소리</th><th class="c">폰</th></tr></thead><tbody>${rows}</tbody></table></div>
  <div class="row" style="padding:14px 0 4px"><button class="btn sm" data-act="testnoti" data-kind="popup">알림창 테스트</button><button class="btn sm" data-act="testnoti" data-kind="system">윈도우 알림 테스트</button><span class="xs mute">소리는 위에서 고른 종류별 설정을 따라요 (▶ 로 미리듣기)</span></div>
  <hr class="sep">
  <div class="callout" style="margin-bottom:12px"><b>📱 폰 알림 링크란?</b><div class="sm" style="margin-top:6px;line-height:1.75">컴퓨터가 꺼져 있거나 자리를 비웠을 때 <b>폰으로도 알림을 받는</b> 기능이에요. 프로그램이 알림을 만들 때마다 아래 주소로 <b>제목과 내용 한 통</b>을 보내고, 그 주소의 서비스(ntfy·디스코드 등)가 폰 앱으로 푸시해 줘요. 돈·비밀번호 같은 정보는 보내지 않아요.<br>
    <b>가장 쉬운 방법 (ntfy)</b> ① 폰에 <b>ntfy</b> 앱 설치 → ② 앱에서 <b>＋</b> 눌러 주제 이름 정하기 (남이 못 맞히게 길게, 예: <code>ac-내이름-48213</code>) → ③ 아래 칸에 <code>https://ntfy.sh/그이름</code> 붙여넣기 → ④ 테스트.<br>
    디스코드는 채널 설정 → 연동 → 웹후크 → 링크 복사. 이 링크는 <b>비밀번호처럼</b> 다뤄 주세요 (아는 사람은 누구나 그 채널에 글을 보낼 수 있어요).<br>
    <span class="mute">카카오톡은 개인용 공식 알림 링크가 없고(카카오 개발자 앱·토큰이 필요) 설정이 복잡해서 지원하지 않아요.</span></div></div>
  ${cs('', '폰 알림 링크', '비워 두면 폰 알림은 보내지 않아요. 위 표의 “폰” 칸이 켜진 알림만 보냅니다', `<span class="row"><input class="wide" style="width:300px" data-set="notify.phoneUrl" value="${esc(n.phoneUrl || '')}" placeholder="https://ntfy.sh/내-주제-이름"><button class="btn sm" data-act="testnoti" data-kind="phone">폰으로 테스트</button></span>${kd ? `<div style="margin-top:6px"><span class="pill ${kd[1]}">${kd[0]}${kd[1] === 'ok' ? '로 인식' : ''}</span></div>` : ''}`)}`;
}
const cs = (path, label, help, ctl) => `<div class="setrow"><div class="lbl"><b>${label}</b>${help ? `<span>${help}</span>` : ''}</div><div>${ctl}</div></div>`;
const cnum = (path, o = {}) => `<span class="unit"><input type="number" data-set="${path}" value="${esc(getPath(S.cfg, path))}" ${o.min != null ? `min="${o.min}"` : ''} ${o.max != null ? `max="${o.max}"` : ''} step="${o.step || 1}">${o.unit ? `<em>${o.unit}</em>` : ''}</span>`;
const csel = (path, opts) => `<select data-set="${path}">${opts.map(([v, l]) => `<option value="${v}" ${String(getPath(S.cfg, path)) === String(v) ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
const csw = (path, on) => `<label class="switch"><input type="checkbox" data-set="${path}" ${on ? 'checked' : ''}><i></i></label>`;
function pCfg() {
  const c = S.cfg;
  const secs = [
    ['auto', '🤖 자동화 모드', `<div class="callout" style="margin-bottom:6px"><b>끄기</b> 아무것도 안 함 · <b>제안만</b> 알림과 제안만, 실행은 내가 승인 · <b>자동</b> 안전장치 안에서 스스로 실행</div>
      ${cs('', '전체 일시정지', '켜면 감시는 하지만 어떤 동작도 하지 않습니다', csw('paused', c.paused))}
      ${cs('', 'AI 판단', '예금·주식 판단을 Claude가 맡습니다', modeSeg('ai.mode', c.ai.mode))}
      ${cs('', '주식', 'AI·규칙이 낸 매수/매도 주문을 실행할지', modeSeg('stocks.mode', c.stocks.mode))}
      ${cs('', '예금', '여유 현금 예금 가입, 자동 예금 만기 수령', modeSeg('deposits.mode', c.deposits.mode))}
      ${cs('', '직업 체크', '자동 = 급식 기록이 전원 입력된 날에만 완료 체크', modeSeg('job.mode', c.job.mode))}
      ${cs('', '상점', '상점은 자동 구매하지 않습니다 (알림만)', '<span class="pill gray">항상 수동</span>')}`],
    ['link', '🔌 연결·유지', linkSection(c)],
    ['mobile', '📱 휴대폰 접속', mobileSection(c)],
    ['ai', '🧠 AI', `${cs('', '연결 방식', 'claude-cli는 내 Claude 로그인을, api는 ANTHROPIC_API_KEY를 씁니다', csel('ai.provider', [['claude-cli', 'Claude 로그인 (claude-cli)'], ['api', 'API 키']]))}
      ${cs('', '판단 주기', '사용량을 아끼려면 길게', cnum('ai.intervalMinutes', { min: 5, max: 720, unit: '분' }))}
      ${cs('', '회차 직전 추가 판단', '거래 회차 몇 분 전에 한 번 더 판단할지', cnum('ai.preSessionMinutes', { min: 0, max: 240, unit: '분' }))}`],
    ['stock', '📈 주식 전략', `<div class="row" style="padding:10px 0"><span class="sm mute">프리셋</span><div class="seg">${Object.entries(PRESETS).map(([k, [l]]) => `<button data-act="preset" data-v="${k}">${l}</button>`).join('')}</div><span class="xs mute">누르면 아래 값이 한 번에 바뀝니다</span></div>
      ${cs('', '종목당 최대 비중', '총자산 대비 한 종목에 넣을 수 있는 최대 비율', cnum('stocks.maxPositionPct', { min: 1, max: 100, unit: '%' }))}
      ${cs('', '최대 보유 종목 수', '', cnum('stocks.maxPositions', { min: 1, max: 10, unit: '개' }))}
      ${cs('', '손절 기준', '수수료 반영 손실이 이 값을 넘으면 매도', cnum('stocks.stopLossPct', { min: 1, max: 50, unit: '%' }))}
      ${cs('', '(규칙) 고점 대비 하락', 'AI가 꺼졌을 때 쓰는 규칙 엔진 값', cnum('stocks.dipPct', { min: 1, max: 30, step: 0.5, unit: '%' }))}
      ${cs('', '(규칙) 반등 확인', '', cnum('stocks.bouncePct', { min: 0, max: 10, step: 0.1, unit: '%' }))}
      ${cs('', '(규칙) 익절', '왕복 수수료+1.5% 미만이면 자동 보정', cnum('stocks.takeProfitPct', { min: 1, max: 50, step: 0.5, unit: '%' }))}
      ${cs('', '검증된 신호만 매수 (규칙 엔진)', '외부 시세 백테스트를 통과한 규칙이 켜진 종목만 사요', csw('stocks.useSignals', c.stocks.useSignals !== false))}
      ${cs('', 'AI 제안도 검증된 신호 필요', '끄면 AI 판단만으로도 매수할 수 있어요 (권장하지 않아요)', csw('stocks.requireSignal', c.stocks.requireSignal !== false))}
      ${cs('', '최대 보유 기간', '이 날짜가 지나면 정리해서 현금을 되찾아요', cnum('stocks.maxHoldDays', { min: 1, max: 30, unit: '일' }))}
      ${cs('', '신호 없을 때 주식용 현금 비율', '검증된 매수 신호가 하나도 없으면 예금이 훨씬 유리해서, 남겨 둘 현금 비율을 이 값으로 줄여요 (0~1)', cnum('stocks.cashForStocksIdle', { min: 0, max: 1, step: 0.05 }))}
      ${cs('', '주식용으로 남길 현금 비율', '예금에 넣지 않고 주식 매수용으로 둘 비율 (0~1)', cnum('stocks.cashForStocks', { min: 0, max: 1, step: 0.05 }))}
      ${cs('', '항상 남길 현금 (자동으로 쓰지 않을 현금)', '예금·주식에 자동으로 넣지 않고 현금으로 남겨 두는 금액이에요. 벌금처럼 갑자기 돈이 빠져도 현금이 마이너스가 되지 않게 해 줘요. 예) 3,500원이면 현금이 3,500원 이하일 땐 새 예금·주식 매수를 하지 않아요. (이미 묶인 예금은 영향 없음)', cnum('cashReserve', { min: 0, step: 100, unit: '원' }))}`],
    ['dep', '🏦 예금', `${cs('', '최소 가입 금액', '', cnum('deposits.minAmount', { min: 100, step: 100, unit: '원' }))}${cs('', '가입 간격', '같은 종류 예금을 연달아 만들지 않도록', cnum('deposits.cooldownMinutes', { min: 0, unit: '분' }))}${cs('', '하루 새 예금 개수 상한', '하루에 여러 개로 쪼개 넣으면 오히려 불리할 수 있어요(함정 가능성). 상한까지만 넣고 현금은 모아서 묶어 넣어요', cnum('deposits.maxPerDay', { min: 1, max: 10, unit: '개' }))}${cs('', '모아서 넣는 최소 금액', '이 금액 이상 모이면 바로 가입, 그 전에는 모아 둬요', cnum('deposits.batchMinAmount', { min: 1000, step: 1000, unit: '원' }))}${cs('', '마지막 묶음 가입 시각', '이 시각(한국시간, 14.5 = 오후 2:30) 이후엔 그날 모인 돈을 한 번에 넣어요', cnum('deposits.flushHour', { min: 8, max: 23, step: 0.5, unit: '시' }))}${cs('', '만기 자동 수령', '자동으로 만든 예금(auto-)만 해당', csw('deposits.collectMatured', c.deposits.collectMatured))}`],
    ['job', '🗓 직업', `${cs('', '미완료 알림', '활동일에 직업 체크가 안 돼 있으면 알려요', csw('job.remind', c.job.remind))}${cs('', '알림 시작 시각', '한국시간 기준, 이후 완료될 때까지 매시간', cnum('job.remindHour', { min: 0, max: 23, unit: '시' }))}`],
    ['noti', '🔔 알림', notiSection(c)],
    ['sys', '🔧 시스템', `${cs('', '확인 주기', '사이트에 요청하는 간격입니다. 너무 짧으면 사이트에 부담이 돼요', cnum('pollSeconds', { min: 20, max: 600, unit: '초' }))}
      ${cs('', '이 프로그램의 역할', '같은 계정을 내 PC와 클라우드에서 함께 돌릴 때 하나만 “주 실행”으로 두세요. “감시만”은 지켜보고 알리기만 하고 자동 거래·예금은 하지 않아요(중복 거래 방지)', csel('role', [['primary', '주 실행 (자동으로 실행)'], ['monitor', '감시만 (자동 실행 안 함)']]))}
      ${cs('', '하루 자동 실행 상한', '안전장치', cnum('maxAutoActionsPerDay', { min: 1, max: 100, unit: '건' }))}
      ${cs('', '접속 방식', 'api: 가볍게 직접 호출 · page: 페이지 안에서 호출', csel('transport', [['api', 'api'], ['page', 'page']]))}
      ${cs('', '브라우저 창 보이기', '디버깅용. 켜면 자동화 브라우저가 화면에 보여요', csw('showBrowser', c.showBrowser))}
      ${cs('', '전체 회귀 점검 주기', '', cnum('selfTest.intervalMinutes', { min: 30, max: 1440, unit: '분' }))}
      ${cs('', '테마', '', `<div class="seg">${[['auto', '시스템'], ['light', '라이트'], ['dark', '다크']].map(([k, l]) => `<button data-act="theme" data-v="${k}" class="${(localStorage.getItem('theme') || 'auto') === k ? 'on' : ''}">${l}</button>`).join('')}</div>`)}`],
  ];
  return `<div class="setlay view-anim"><div class="setnav card" style="padding:10px">${secs.map(([k, l]) => `<a href="#/cfg" data-act="setsec" data-v="${k}" style="${ui.setSec === k ? 'background:var(--priSoft);color:var(--pri);font-weight:700' : ''}">${l}</a>`).join('')}</div>
    <div class="stack">${secs.filter(([k]) => ui.setSec === k || ui.setSec === 'all').map(([k, l, body]) => `<div class="card" id="sec-${k}"><h2>${l} <small>변경하면 바로 저장돼요</small></h2>${body}</div>`).join('')}
    <div class="row"><button class="btn sm" data-act="showall">전체 보기</button><span class="xs mute">설정 파일: data/config.json</span></div></div></div>`;
}

/* ───────── 라우터 · 렌더 ───────── */
const ROUTES = {
  home: ['📊', '개요', '내 자산과 오늘 할 일을 한눈에', pHome, '운영'],
  ai: ['🧠', 'AI 판단', 'AI가 지금 무엇을 어떻게 보고 있는지', pAI, '운영'],
  alerts: ['🔔', '알림', '받은 알림 기록', pAlerts, '운영'],
  history: ['📒', '내 내역', '전체 거래 내역', pHistory, '자산'],
  analysis: ['🔬', '시장 분석', '외부 시세 · 수수료 차감 백테스트', pAnalysis, '자산'],
  stock: ['📈', '주식', '시세 · 주문 · 보유', pStock, '자산'],
  bank: ['🏦', '예금', '가입 · 만기 · 상품 비교', pBank, '자산'],
  store: ['🛍', '상점', '아이템 · 내 아이템 · 관심 상품', pStore, '자산'],
  job: ['🗓', '직업', '직업 체크 · 급식 기록 · 직업표', pJob, '생활'],
  meals: ['🍱', '급식', '내가 먹은 급식 기록', pMeals, '생활'],
  donate: ['💝', '기부', '기부 목표에 마음 보태기', pDonate, '생활'],
  fines: ['🧾', '벌금', '받은 벌금과 현금 여유', pFines, '생활'],
  auction: ['🪑', '자리 경매', '좌석 입찰', pAuction, '생활'],
  board: ['💬', '게시판', '친구들과 이야기', pBoard, '생활'],
  reg: ['🧪', '점검', '서비스 전체 회귀 점검', pReg, '시스템'],
  log: ['📜', '내역', '프로그램이 한 일 전부', pLog, '시스템'],
  cfg: ['⚙️', '설정', '모든 동작을 여기서 조정', pCfg, '시스템'],
};
const route = () => { const r = (location.hash.replace(/^#\/?/, '') || 'home').split('/')[0]; return ROUTES[r] ? r : 'home'; };
const STATE_PILL = { ok: ['정상', 'ok'], paused: ['일시정지', 'warn'], logged_out: ['로그아웃', 'bad'], error: ['오류', 'bad'], safe_mode: ['안전모드', 'bad'], starting: ['시작 중', 'warn'] };

function renderChrome() {
  const r = route(), st = S?.status;
  const badges = { alerts: 0, reg: S?.reg?.failed || 0 };
  let last = '';
  $('#side').innerHTML = `<div class="brand"><span class="logo">₩</span>경제교실 오토</div>` + Object.entries(ROUTES).map(([k, [ic, l, , , g]]) => { const h = g !== last ? `<div class="navgrp">${g}</div>` : ''; last = g; return `${h}<a class="nav ${r === k ? 'on' : ''}" href="#/${k}"><span class="ic">${ic}</span>${l}${badges[k] ? `<span class="bd">${badges[k]}</span>` : ''}</a>`; }).join('') + `<div class="sidefoot">${S?.snap ? '갱신 ' + fdt(S.snap.at) : '연결 중…'}<br>${connErr ? '<span class="bad">서버 연결 끊김</span>' : ''}</div>`;
  $('#tabbar').innerHTML = ['home', 'stock', 'bank', 'job', 'cfg'].map((k) => `<a class="${r === k ? 'on' : ''}" href="#/${k}"><span>${ROUTES[k][0]}</span>${ROUTES[k][1]}</a>`).join('');
  const [sp, sc] = STATE_PILL[st?.state] || [st?.state || '연결 중', 'gray'];
  $('#top').innerHTML = `<h1>${ROUTES[r][1]}<span class="sub">${ROUTES[r][2]}</span></h1><span class="pill ${sc}" title="${esc(st?.detail || '')}"><i class="dot"></i>${sp}</span>
    <button class="btn sm" data-act="pause">${S?.cfg?.paused ? '▶ 재개' : '⏸ 일시정지'}</button><button class="btn sm" data-act="refresh">↻ 지금 확인</button>`;
  const b = [];
  if (connErr) b.push(['bad', '⚠', '프로그램 서버에 연결할 수 없습니다. 실행 중인지 확인해 주세요.', '']);
  else if (st?.state === 'logged_out') b.push(['bad', '🔐', '경제교실 로그인이 풀렸습니다.', '<button class="btn pri sm" data-act="login">로그인 창 열기</button>']);
  else if (st?.state === 'safe_mode') b.push(['bad', '🛑', st.detail || '사이트 형식이 바뀌어 자동 실행을 멈췄습니다.', '']);
  else if (st?.state === 'error') b.push(['warn', '⚠', '사이트 연결이 불안정합니다: ' + (st.detail || '').slice(0, 90), '']);
  else if (S?.snap && S.snap.user.balance < 0) b.push(['warn', '💸', `현금이 마이너스예요 (${won(S.snap.user.balance)}). 벌금이 현금보다 커서 생겼어요. 현금이 다시 생기면 그만큼 채워져요. 앞으로 막으려면 설정 → 주식 전략의 “항상 남길 현금(자동으로 쓰지 않을 현금)”을 늘려 두세요.`, '<a class="btn sm" href="#/cfg" data-act="gocfg" data-sec="stock">설정 열기</a>']);
  else if (S?.cfg?.paused) b.push(['warn', '⏸', '일시정지 중입니다. 감시만 하고 아무 것도 실행하지 않아요.', '<button class="btn pri sm" data-act="pause">재개</button>']);
  if (S?.snap && S.cfg.ai.mode !== 'off' && S.ai?.error && /로그인|authenticate|OAuth/i.test(S.ai.error)) b.push(['warn', '🧠', 'AI 로그인이 필요합니다. 터미널에서 claude auth login 을 실행해 주세요.', '']);
  $('#banner').innerHTML = b.map(([k, ic, t, a]) => `<div class="banner ${k}"><span>${ic}</span><b>${esc(t)}</b>${a}</div>`).join('');
}
let lastSig = '';
function renderView(force = false) {
  const r = route();
  const act = document.activeElement;
  if (!force && act && $('#view').contains(act) && ['INPUT', 'SELECT', 'TEXTAREA'].includes(act.tagName) && act.type !== 'checkbox') return; // 입력 중엔 덮어쓰지 않음
  const sig = r + JSON.stringify([S, ui]);
  if (!force && sig === lastSig) return;
  lastSig = sig;
  const view = $('#view');
  const keep = act && act.id && $('#view').contains(act) ? { id: act.id, pos: act.selectionStart } : null;
  // 입력 중이던 값(폼)이 갱신 때문에 사라지지 않게 보존
  const vals = {}; view.querySelectorAll('input[id],select[id],textarea[id]').forEach((el) => { vals[el.id] = el.type === 'checkbox' ? el.checked : el.value; });
  try {
    view.innerHTML = S ? ROUTES[r][3]() : waiting();
    view.querySelectorAll('input[id],select[id],textarea[id]').forEach((el) => { if (el.id in vals && vals[el.id] !== '' && !(el.id === 'q' || el.id === 'sq' || el.id === 'lq')) { if (el.type === 'checkbox') el.checked = vals[el.id]; else el.value = vals[el.id]; } });
  } catch (e) {
    console.error(e);
    view.innerHTML = `<div class="err"><b>이 화면을 그리는 중 오류가 났어요</b><br>${esc(e.message)}<br><span class="xs">다른 화면은 정상입니다. 새로고침 후에도 계속되면 알려 주세요.</span></div>`;
  }
  if (r === 'home' && S?.history) multiChart($('#hchart'), rangeRows(), ui.series);
  if (r === 'ai' && !ui.claudeLoaded) { ui.claudeLoaded = true; api('/api/claude/status').then((x) => { ui.claude = x; lastSig = ''; render(true); }); }
  if (r === 'cfg' && !ui.sysLoaded) { ui.sysLoaded = true; loadSys(); loadRemote(); }
  if (keep) { const el = $('#' + keep.id); if (el) { el.focus(); try { el.setSelectionRange(keep.pos, keep.pos); } catch {} } }
}
function render(force) { try { renderChrome(); } catch (e) { console.error(e); } renderView(force); }

async function refresh() {
  try {
    const r = await api('/api/state');
    if (r && r.error === 'token') { location.reload(); return; } // 서버가 다시 시작돼 토큰이 바뀐 경우
    if (!r || r.error || !r.cfg) connErr = true; else { S = r; connErr = false; }
  } catch { connErr = true; }
  render();
}
const PAGEDATA = { meals: ['meals'], donate: ['goals'], fines: ['fines'], auction: ['auction'], board: ['posts'], store: ['users'], bank: ['users'] };
window.addEventListener('hashchange', () => { for (const n of PAGEDATA[route()] || []) delete ui.data[n]; lastSig = ''; render(true); window.scrollTo(0, 0); });

/* ───────── 이벤트 ───────── */
const save = async (patch, msg = '저장됨') => { const r = await api('/api/config', patch); if (r.ok) { S.cfg = r.cfg; toast(msg, 'ok'); } else toast('저장 실패', 'bad'); lastSig = ''; render(true); };
const ACT = {
  range: (el) => { ui.range = el.dataset.v; render(true); },
  series: (el) => { const k = el.dataset.v; ui.series = ui.series.includes(k) ? ui.series.filter((x) => x !== k) : [...ui.series, k]; render(true); },
  applyrange: () => { ui.cFrom = ($('#c-from')?.value || ''); ui.cTo = ($('#c-to')?.value || ''); if (ui.cFrom && ui.cTo && ui.cFrom > ui.cTo) { [ui.cFrom, ui.cTo] = [ui.cTo, ui.cFrom]; } render(true); },
  csv: exportCsv,
  hrange: (el) => { ui.hRange = el.dataset.v; render(true); },
  htype: (el) => { ui.hType = el.dataset.v; render(true); },
  histreload: () => loadHist(false),
  histmore: () => loadHist(true),
  gocfg: (el) => { ui.setSec = el.dataset.sec || 'auto'; },
  mk: (el) => { ui.mk = el.dataset.v; render(true); }, cat: (el) => { ui.cat = el.dataset.v; render(true); },
  atype: (el) => { ui.alertType = el.dataset.v; render(true); }, ltype: (el) => { ui.logType = el.dataset.v; render(true); },
  setsec: (el, e) => { e.preventDefault(); ui.setSec = el.dataset.v; render(true); }, showall: () => { ui.setSec = 'all'; render(true); },
  stock: (el) => openStock(el.dataset.id), newdep: newDeposit,
  mclose: closeModal, maskclose: (el, e) => { if (e.target === el) closeModal(); },
  'cf-yes': () => window.__cf?.(true), 'cf-no': () => window.__cf?.(false),
  pause: async () => { await api('/api/pause', { paused: !S.cfg.paused }); refresh(); },
  refresh: async () => { await api('/api/refresh', {}); toast('확인을 요청했어요'); setTimeout(refresh, 2500); },
  login: async () => { await api('/api/login', {}); toast('로그인 창을 엽니다'); },
  think: async () => { const r = await api('/api/think', {}); toast(r.ok ? 'AI가 생각을 시작했어요 (최대 3분)' : r.error, r.ok ? 'ok' : 'bad'); setTimeout(refresh, 1500); },
  runreg: async () => { const r = await api('/api/selftest', {}); toast(r.ok ? '점검을 시작했어요' : r.error, r.ok ? 'ok' : 'bad'); setTimeout(refresh, 3500); },
  testnoti: async (el) => {
    const kind = el?.dataset?.kind || 'popup';
    const r = await api('/api/notify-test', { kind, sound: kind === 'phone' ? undefined : 'default', url: kind === 'phone' ? ($('[data-set="notify.phoneUrl"]')?.value || '').trim() : undefined });
    if (kind === 'phone') toast(r.ok ? '폰으로 테스트를 보냈어요. 폰을 확인해 보세요' : (r.error || '전송 실패'), r.ok ? 'ok' : 'bad');
    else toast(kind === 'system' ? '윈도우 알림을 보냈어요 (알림센터 확인)' : '알림창을 띄웠어요 (화면 오른쪽 아래)', 'ok');
  },
  remoteLink: async () => {
    if (ui.remote && !(S.cfg.remote || {}).enabled) { const ok = await confirmBox('휴대폰 접속이 꺼져 있어요', '링크를 만들어도 “휴대폰 접속 허용”을 켜야 열려요. 먼저 켤까요?', '켜기'); if (ok) await save({ remote: { enabled: true } }, '휴대폰 접속을 켰어요'); }
    if (!(await confirmBox('새 접속 링크를 만들까요?', '이전에 만든 링크는 바로 쓸 수 없게 돼요. 이미 로그인한 기기는 유지돼요.', '만들기'))) return;
    const r = await api('/api/remote/link', {}); if (!r.ok) return toast('실패: ' + (r.error || ''), 'bad');
    ui.newLink = r; await refresh(); loadRemote(); toast('링크를 만들었어요. 복사해서 휴대폰에서 열어 주세요', 'ok');
  },
  remoteRevoke: async () => { if (!(await confirmBox('접속 링크를 폐기할까요?', '이 링크로는 더 이상 들어올 수 없어요. 이미 로그인한 기기도 다시 링크가 필요해요.', '폐기', true))) return; await api('/api/remote/revoke', {}); ui.newLink = null; await refresh(); loadRemote(); toast('폐기했어요', 'ok'); },
  copy: async (el) => { try { await navigator.clipboard.writeText(el.dataset.t); toast('복사했어요', 'ok'); } catch { toast('복사하지 못했어요. 직접 선택해서 복사해 주세요', 'bad'); } },
  claudeStatus: async () => { toast('확인 중… (몇 초 걸려요)'); ui.claude = await api('/api/claude/status'); lastSig = ''; render(true); toast(ui.claude.loggedIn ? '로그인되어 있어요' : '로그인이 필요해요', ui.claude.loggedIn ? 'ok' : 'bad'); },
  claudeLogin: async () => { const r = await api('/api/claude/login', {}); toast(r.ok ? '로그인 창을 열었어요. 브라우저에서 승인해 주세요' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); },
  tokenSetup: async () => { const r = await api('/api/claude/token-setup', {}); toast(r.ok ? '새 창이 열렸어요. 안내에 따라 진행해 주세요' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); },
  setka: (el) => save({ system: { keepAwake: el.dataset.v } }, { off: '절전 방지를 껐어요', system: '이제 PC가 잠들지 않아요 (화면은 꺼질 수 있음)', display: '화면도 켜 둡니다' }[el.dataset.v]),
  ntfySave: async () => { const v = ($('#ntfy-url')?.value || '').trim(); await save({ notify: { phoneUrl: v } }, v ? '폰 링크를 저장했어요' : '폰 링크를 지웠어요'); },
  ntfyNew: async () => { const r = await api('/api/ntfy/new-link'); if (r.url) { await save({ notify: { phoneUrl: r.url } }, '새 링크를 만들어 저장했어요 — 폰 ntfy 앱에서 이 이름을 구독하세요'); } },
  ntfySend: async () => { const m = ($('#ntfy-msg')?.value || '').trim(); const url = ($('#ntfy-url')?.value || '').trim(); const r = await api('/api/ntfy/send', { url, title: '경제교실 오토', message: m || '테스트 메시지입니다 🎉' }); toast(r.ok ? 'ntfy로 보냈어요. 폰을 확인해 보세요' : (r.error || '전송 실패'), r.ok ? 'ok' : 'bad'); },
  soundtest: async (el) => { const s = $('#snd-' + el.dataset.k)?.value || 'default'; if (s === 'none') return toast('무음으로 설정돼 있어요'); await api('/api/notify-test', { kind: 'popup', sound: s }); },
  npreset: async (el) => {
    const k = el.dataset.v, keys = Object.keys(NOTI), ev = {};
    const base = { login_lost: { popup: true, system: true, phone: true, sound: 'alert' }, error: { popup: true, system: false, phone: true, sound: 'alert' }, job: { popup: true, system: true, phone: true, sound: 'default' }, matured: { popup: true, system: false, phone: false, sound: 'soft' }, order: { popup: true, system: false, phone: false, sound: 'soft' }, advice: { popup: true, system: false, phone: false, sound: 'soft' }, site_changed: { popup: true, system: true, phone: true, sound: 'default' }, store: { popup: true, system: false, phone: false, sound: 'none' }, action: { popup: true, system: false, phone: false, sound: 'none' }, system: { popup: false, system: false, phone: true, sound: 'none' } };
    for (const e of keys) {
      if (k === 'normal') ev[e] = base[e];
      else if (k === 'all') ev[e] = { popup: true, system: true, phone: true, sound: e === 'store' || e === 'action' ? 'soft' : base[e].sound === 'none' ? 'soft' : base[e].sound };
      else { const on = NPRESET.quiet[1][e]; ev[e] = on ? { popup: true, system: false, phone: e !== 'job', sound: on[1] } : { popup: false, system: false, phone: false, sound: 'none' }; }
    }
    await save({ notify: { events: ev } }, NPRESET[k][0] + ' 알림 설정을 적용했어요');
  },
  apply: async (el) => { const r = await api('/api/apply', { key: el.dataset.key }); toast(r.ok ? '실행했어요' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); refresh(); },
  dismiss: async (el) => { await api('/api/dismiss', { key: el.dataset.key }); refresh(); },
  term: async (el) => { const m = el.dataset.m === '1'; if (!(await confirmBox(m ? '만기 수령' : '중도 해지', m ? '원금과 이자를 받습니다.' : '<b class="bad">중도 해지하면 이자를 받지 못합니다.</b> 계속할까요?', m ? '수령' : '해지', !m))) return; const r = await api('/api/manual', { kind: 'terminate', id: +el.dataset.id }); toast(r.ok ? '완료했어요' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); refresh(); },
  cancel: async (el) => { if (!(await confirmBox('주문 취소', '이 주문을 취소할까요?', '취소하기', true))) return; const r = await api('/api/manual', { kind: 'cancel', id: el.dataset.id }); toast(r.ok ? '취소했어요' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); refresh(); },
  reconsider: async (el) => {
    if (!(await confirmBox('이 예금을 해지하고 AI가 다시 판단하게 할까요?', '방금 가입한 예금이라 해지해도 잃는 이자가 거의 없어요. 원금이 현금으로 돌아오고, AI가 예금·주식 중 더 나은 쪽을 다시 판단합니다.', '해지하고 재판단'))) return;
    const r = await api('/api/manual', { kind: 'terminate', id: +el.dataset.id });
    if (!r.ok) return toast('실패: ' + (r.error || ''), 'bad');
    toast('해지했어요. AI가 다시 판단합니다 (최대 3분)', 'ok'); await api('/api/think', {}); setTimeout(refresh, 1500);
  },
  buyitem: (el) => itemBuy(el.dataset.id),
  giftitem: (el) => itemGift(+el.dataset.id, el.dataset.n),
  useitem: async (el) => { if (!(await confirmBox('아이템을 사용할까요?', `<b>${esc(el.dataset.n)}</b> 1개를 사용해요. 사용하면 되돌릴 수 없어요.`, '사용'))) return; doOp('useItem', { purchaseId: +el.dataset.id, quantity: 1 }, `${el.dataset.n}을(를) 사용했어요`); },
  refunditem: async (el) => { if (!(await confirmBox('환불할까요?', `<b>${esc(el.dataset.n)}</b>을(를) 환불해요. (환불이 안 되는 아이템은 실패해요)`, '환불', true))) return; doOp('refundItem', { purchaseId: +el.dataset.id }, '환불했어요'); },
  donate: async () => {
    const amt = Math.floor(num($('#dn-amt')?.value)); if (amt < 1) return toast('기부 금액을 입력해 주세요', 'bad');
    const cash = calc()?.cash ?? 0; if (amt > cash) return toast('현금이 부족해요 (현재 ' + won(cash) + ')', 'bad');
    const gsel = $('#dn-goal'); const gname = gsel?.selectedOptions[0]?.textContent;
    if (!(await confirmBox('기부할까요?', `<b>${won(amt)}</b> → ${esc(gname)}<br><span class="bad">기부한 돈은 돌려받을 수 없어요.</span>`, '기부'))) return;
    doOp('donate', { amount: amt, goalId: gsel?.value, message: $('#dn-msg')?.value || '', isAnonymous: !!$('#dn-anon')?.checked }, '기부했어요. 고마워요 💝', () => reload('goals'));
  },
  bid: async (el) => {
    const id = el.dataset.id, amt = Math.floor(num($('#bid-' + id)?.value)), cur = num(el.dataset.cur);
    if (amt <= cur) return toast('현재가(' + won(cur) + ')보다 높게 입력해 주세요', 'bad');
    if (!(await confirmBox('입찰할까요?', `<b>${won(amt)}</b>으로 입찰해요. 입찰은 되돌릴 수 없어요.`, '입찰'))) return;
    doOp('bid', { seatAuctionId: +id, amount: amt }, '입찰했어요', () => reload('auction'));
  },
  post: async () => { const t = ($('#bd-text')?.value || '').trim(); if (!t) return toast('내용을 입력해 주세요', 'bad'); if (!(await confirmBox('글을 올릴까요?', '모든 친구가 볼 수 있어요.', '올리기'))) return; doOp('post', { content: t }, '글을 올렸어요', () => reload('posts')); },
  like: async (el) => { const r = await svc('like', { postId: +el.dataset.id }); toast(r.ok ? '좋아요!' : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); reload('posts'); },
  comment: (el) => { const id = +el.dataset.id; openModal(`<div class="row sb"><h3>댓글 쓰기</h3><button class="btn ghost sm" data-act="mclose">✕</button></div><textarea id="cm-text" rows="3" style="width:100%;margin-top:10px" maxlength="500" placeholder="댓글을 적어 주세요"></textarea><div class="actions"><button class="btn" data-act="mclose">취소</button><button class="btn pri" id="cm-go">올리기</button></div>`, (m) => { $('#cm-go', m).onclick = async () => { const t = $('#cm-text', m).value.trim(); if (!t) return; await doOp('comment', { postId: id, content: t }, '댓글을 올렸어요', () => { closeModal(); reload('posts'); }); }; }); },
  transfer: async () => {
    const to = $('#tf-to')?.value, amt = Math.floor(num($('#tf-amt')?.value)); if (!to || amt < 1) return toast('받는 사람과 금액을 입력해 주세요', 'bad');
    const st = S.snap.settings, fee = Math.round(Math.max(amt * num(st.transferFeeRate || 0.01), num(st.transferFeeMin || 100)));
    if (!(await confirmBox('송금할까요?', `${esc($('#tf-to').selectedOptions[0].textContent)}에게 <b>${won(amt)}</b><br>수수료 ${won(fee)} → 합계 <b>${won(amt + fee)}</b>`, '송금'))) return;
    doOp('transfer', { toUserId: to, amount: amt }, '송금했어요');
  },
  markjob: async (el) => { if (!(await confirmBox('오늘 직업을 완료로 체크할까요?', '<b>일을 실제로 마쳤을 때만</b> 눌러 주세요. 사이트의 완료 버튼과 같은 동작이에요.', '완료 체크'))) return; doOp('markJob', { date: el.dataset.date, completed: true }, '직업을 완료로 체크했어요'); },
  setreserve: (el) => save({ cashReserve: +el.dataset.v }, `항상 남길 현금을 ${won(el.dataset.v)}으로 설정했어요`),
  reload: (el) => reload(el.dataset.n),
  wish: async (el) => { const id = +el.dataset.id, w = new Set(S.cfg.store.wishlist || []); w.has(id) ? w.delete(id) : w.add(id); await save({ store: { wishlist: [...w] } }, w.has(id) ? '관심 상품에 추가' : '관심 상품에서 뺐어요'); },
  setmode: (el) => save(patchOf(el.dataset.path, el.dataset.v), '모드를 바꿨어요'),
  preset: (el) => save({ stocks: PRESETS[el.dataset.v][1] }, PRESETS[el.dataset.v][0] + ' 프리셋 적용'),
  theme: (el) => { localStorage.setItem('theme', el.dataset.v); applyTheme(); render(true); },
};
document.addEventListener('click', (e) => { const el = e.target.closest('[data-act]'); if (el && ACT[el.dataset.act]) ACT[el.dataset.act](el, e); });
document.addEventListener('change', (e) => {
  const t = e.target;
  if (t.dataset.actChange === 'task') {
    const on = t.checked;
    api('/api/system/task', { which: t.dataset.which, on }).then((r) => { toast(r.ok ? (on ? '등록했어요' : '해제했어요') : '실패: ' + (r.error || ''), r.ok ? 'ok' : 'bad'); loadSys(); });
  }
  else if (t.dataset.actChange === 'sort') { ui.sort = t.value; render(true); }
  else if (t.dataset.actChange === 'storeSort') { ui.storeSort = t.value; render(true); }
  else if (t.dataset.set) {
    const p = t.dataset.set; let v = t.type === 'checkbox' ? t.checked : t.type === 'number' ? num(t.value) : t.value;
    if (t.type === 'number') { const mn = t.min !== '' ? +t.min : -Infinity, mx = t.max !== '' ? +t.max : Infinity; if (v < mn || v > mx) { toast(`${mn}~${mx} 사이로 입력해 주세요`, 'bad'); t.value = getPath(S.cfg, p); return; } }
    if (p === 'paused') return save({ paused: v }, v ? '일시정지' : '재개');
    save(patchOf(p, v));
  }
});
document.addEventListener('input', (e) => {
  if (e.target.id === 'rm-domain') { localStorage.setItem('remoteDomain', e.target.value.trim().replace(/^https?:\/\//, '').replace(/\/+$/, '')); return; }
  if (e.target.id === 'q') { ui.q = e.target.value; render(true); }
  else if (e.target.id === 'sq') { ui.storeQ = e.target.value; render(true); }
  else if (e.target.id === 'lq') { ui.logQ = e.target.value; render(true); }
  else if (e.target.id === 'hq') { ui.hQ = e.target.value; render(true); }
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
function applyTheme() { const t = localStorage.getItem('theme') || 'auto'; if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t); if (t === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches) document.documentElement.setAttribute('data-theme', 'dark'); }
applyTheme();
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', applyTheme);
window.addEventListener('resize', () => { lastSig = ''; });
refresh(); setInterval(refresh, 4000);

/* ───────── 페이지: 시장 분석 (외부 시세 + 수수료 차감 백테스트) ───────── */
function pAnalysis() {
  const a = S.snap?.analysis;
  if (!a) return `<div class="card">${empty('📊', '시세 분석을 준비하는 중이에요', '시작 직후 외부 시세(야후)를 받아 분석해요. 몇 초~1분 걸려요.')}</div>`;
  const byId = new Map((S.snap.investments || []).map((i) => [i.id, i]));
  const rows = Object.entries(a.stocks).map(([id, s]) => ({ id: +id, inv: byId.get(+id), ...s })).filter((x) => x.inv)
    .sort((x, y) => (y.passing.length - x.passing.length) || (num(y.expectedNetPct) - num(x.expectedNetPct)) || (num(y.ret5) - num(x.ret5)));
  const ix = a.indices || {};
  const c = (v) => (v == null ? '<span class="mute">-</span>' : `<span class="${v < 0 ? 'bad' : 'ok'}">${pct(v, 1)}</span>`);
  const passN = a.rules.filter((r) => r.pass).length;
  return `<div class="stack view-anim">
  <div class="grid g4">
    <div class="card"><div class="mute sm">분석 기준</div><div class="b">${fdt(a.at)}</div><div class="xs mute">${a.universe}종목 · 일봉 1년</div></div>
    <div class="card"><div class="mute sm">검증 통과 규칙</div><div class="mid ${passN ? 'ok' : 'warn'}">${passN} / ${a.rules.length}</div><div class="xs mute">수수료 왕복 ${a.roundTripPct}% 차감 후</div></div>
    <div class="card"><div class="mute sm">지금 매수 신호</div><div class="mid ${a.signalsNow ? 'ok' : ''}">${a.signalsNow}종목</div><div class="xs mute">검증된 규칙이 켜진 종목</div></div>
    <div class="card"><div class="mute sm">시장 분위기 (20일)</div><div class="sm" style="margin-top:4px">코스피 ${c(ix.kospi?.ret20)} · S&amp;P ${c(ix.sp500?.ret20)} · 나스닥 ${c(ix.nasdaq?.ret20)}</div></div>
  </div>
  <div class="callout">📐 <b>이 분석은 “예측”이 아니라 “검증”이에요.</b> 외부 시세로 지난 1년 동안 각 규칙으로 샀다면 <b>왕복 수수료를 뺀 뒤에도</b> 이득이었는지 확인하고, <b>통계적으로 이득이었던 규칙이 지금 켜진 종목만</b> 사요. 통과한 규칙이 없으면 프로그램은 “오늘은 살 근거가 없다”고 판단하고 사지 않아요. 과거 통계가 미래를 보장하지는 않아요.</div>
  ${(() => { const d = S.snap.dividend; if (!d?.enabled) return ''; const fee = (a.roundTripPct || 1); const net = d.ratePct - fee; const nextAt = d.nextAt ? Date.parse(d.nextAt) : null; const deadline = nextAt ? nextAt - 168 * 3600e3 : null;
    return `<div class="card"><h2>배당 계산기 <small>교실 배당 ${d.ratePct}% · 취득 후 ${d.holdHoursRequired}시간(7일) 이상 보유해야 받아요</small></h2>
    <div class="grid g3" style="gap:10px"><div class="tile"><div class="xs mute">다음 배당 기준 시각</div><div class="b">${nextAt ? fdt(nextAt) : '-'}</div><div class="xs mute">${nextAt ? left(nextAt) : ''}</div></div>
      <div class="tile"><div class="xs mute">받으려면 매수 마감</div><div class="b ${deadline && deadline < Date.now() ? 'bad' : ''}">${deadline ? fdt(deadline) : '-'}</div><div class="xs mute">${deadline ? (deadline < Date.now() ? '이번 배당은 이미 늦었어요' : left(deadline)) : ''}</div></div>
      <div class="tile"><div class="xs mute">배당 − 왕복 수수료</div><div class="b ${net >= 0 ? 'ok' : 'bad'}">${net >= 0 ? '+' : ''}${net.toFixed(2)}%</div><div class="xs mute">주가 변동 제외 · 7일 이상 보유</div></div></div>
    <div class="callout" style="margin-top:12px">💡 같은 7일 동안 <b>7일 예금은 +3%</b>, 30일 예금은 +10%(만기까지)예요. 배당만 노리면 순 <b>+${net.toFixed(1)}%</b>라서 예금보다 불리해요. 그래서 배당은 “검증된 매수 신호”가 있을 때 <b>보너스</b>로만 고려하고, 배당만으로는 사지 않아요.</div></div>`; })()}
  <div class="card"><h2>규칙별 백테스트 <small>5거래일 보유 · 수수료 차감 · 종목 전체 합산</small></h2><div class="tscroll"><table><thead><tr><th>규칙</th><th class="r">표본</th><th class="r">평균 순수익</th><th class="r">승률</th><th class="r">t값</th><th class="r">전반/후반</th><th class="r">아무때나 산 기준선</th><th>결과</th></tr></thead><tbody>${a.rules.map((r) => `<tr><td><b>${esc(r.label)}</b></td><td class="r">${r.n}</td><td class="r num ${r.meanNetPct < 0 ? 'bad' : 'ok'}">${pct(r.meanNetPct)}</td><td class="r">${r.hitPct}%</td><td class="r">${r.t}</td><td class="r xs">${r.halves.map((h) => pct(h, 1)).join(' / ')}</td><td class="r xs">${pct(r.baselinePct)}</td><td>${r.pass ? '<span class="pill ok">통과</span>' : '<span class="pill gray">미달</span>'}</td></tr>`).join('')}</tbody></table></div>
    <div class="xs mute" style="margin-top:8px">통과 조건: 표본 25회 이상 · 평균 순수익 +0.4% 초과 · t값 2 이상 · 전반·후반 모두 이득 · 기준선보다 +0.2%p 이상 우수. 규칙을 일부러 4개만 둬서 “우연히 맞은 조건 찾기”를 줄였어요.</div></div>
  <div class="card"><h2>종목별 상태 <small>신호가 켜진 종목을 위로</small></h2><div class="tscroll"><table><thead><tr><th>종목</th><th class="r">1일</th><th class="r">5일</th><th class="r">20일</th><th class="r">RSI</th><th>켜진 규칙</th><th>검증된 신호</th><th class="r">기대(순)</th></tr></thead><tbody>${rows.map((x) => `<tr><td><b>${esc(x.inv.name)}</b><div class="xs mute">${esc(x.symbol)}${S.snap.rt?.quotes?.[x.id] && !S.snap.rt.quotes[x.id].valid ? ' · 🔒 시세 잠김' : ''}</div></td><td class="r">${c(x.ret1)}</td><td class="r">${c(x.ret5)}</td><td class="r">${c(x.ret20)}</td><td class="r">${x.rsi ?? '-'}</td><td class="xs">${x.firing.map((f) => `<span class="tag">${f}</span>`).join('') || '<span class="mute">-</span>'}</td><td>${x.passing.length ? `<span class="pill ok">${x.passing.join('+')}</span>` : '<span class="mute">-</span>'}</td><td class="r num">${x.expectedNetPct != null ? `<b class="ok">${pct(x.expectedNetPct)}</b> <span class="xs mute">(승률 ${x.hitPct}%)</span>` : '-'}</td></tr>`).join('')}</tbody></table></div>
    ${a.errors?.length ? `<div class="xs warn" style="margin-top:8px">일부 종목은 외부 시세를 못 받았어요: ${esc(a.errors.join(' · '))}</div>` : ''}</div></div>`;
}

if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {}); // 앱 설치(PWA)용
