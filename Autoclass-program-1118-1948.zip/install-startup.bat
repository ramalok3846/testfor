@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-tasks.ps1" -Which autostart
echo.
echo Done. (Auto start at Windows logon; runs on battery, no time limit.)
echo Old task EconomyClassAuto, if present, can be removed with: schtasks /Delete /TN EconomyClassAuto /F  (run as administrator)
pause
