' Run hidden in background (no console window)
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(fso.GetAbsolutePathName(WScript.ScriptFullName))
q = Chr(34)
sh.CurrentDirectory = dir
sh.Run "cmd /c " & q & q & dir & "\run.bat" & q & " >> " & q & dir & "\data\console.log" & q & " 2>&1" & q, 0, False
