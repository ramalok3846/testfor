# Registers/removes the Windows scheduled tasks for EconomyClassAuto.
# Unlike schtasks defaults, these tasks keep running on battery, have no time limit,
# and start late if the PC was off at the scheduled time.
param(
  [ValidateSet('autostart', 'watchdog', 'both')][string]$Which = 'both',
  [switch]$Remove
)
$ErrorActionPreference = 'Stop'
$vbs = Join-Path $PSScriptRoot 'start-hidden.vbs'
$user = "$env:USERDOMAIN\$env:USERNAME"

function Set-Task([string]$name, $trigger) {
  $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument ('"' + $vbs + '"')
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -Hidden
  $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
  Register-ScheduledTask -TaskName $name -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
}

$targets = @()
if ($Which -in 'autostart', 'both') { $targets += 'AutoclassAuto' }
if ($Which -in 'watchdog', 'both') { $targets += 'AutoclassWatchdog' }

foreach ($n in $targets) {
  if ($Remove) {
    if (Get-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue) { try { Unregister-ScheduledTask -TaskName $n -Confirm:$false -ErrorAction Stop } catch { Write-Output ('could not remove ' + $n + ': ' + $_.Exception.Message) } }
    Write-Output "removed $n"
  } elseif ($n -eq 'AutoclassAuto') {
    Set-Task $n (New-ScheduledTaskTrigger -AtLogOn -User $user)
    Write-Output "registered $n (at logon)"
  } else {
    $t = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
    Set-Task $n $t
    Write-Output "registered $n (every 5 minutes)"
  }
}
