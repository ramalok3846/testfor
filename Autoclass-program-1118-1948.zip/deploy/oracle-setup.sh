#!/usr/bin/env bash
# 경제교실 오토 — Oracle Cloud(Ubuntu) 한 번에 설치 스크립트
# 사용: autoclass-cloud.zip 과 이 파일을 같은 폴더(홈)에 올린 뒤  bash oracle-setup.sh
set -euo pipefail

APP_DIR=/opt/autoclass
ZIP="$(ls -1 autoclass-cloud*.zip 2>/dev/null | head -n1 || true)"
[ -n "$ZIP" ] || { echo "autoclass-cloud.zip 이 이 폴더에 없어요. 먼저 올려 주세요."; exit 1; }

echo "== 1/6  기본 도구 · Docker 설치"
sudo apt-get update -y
sudo apt-get install -y unzip curl ca-certificates
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sudo sh
fi
sudo systemctl enable --now docker

echo "== 2/6  메모리가 작으면 스왑 만들기"
MEM_MB=$(free -m | awk '/Mem:/ {print $2}')
if [ "$MEM_MB" -lt 2000 ] && [ ! -f /swapfile ]; then
  sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
  echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
  echo "스왑 2GB 추가 (메모리 ${MEM_MB}MB)"
fi

echo "== 3/6  프로그램 파일 배치 ($APP_DIR)"
sudo mkdir -p "$APP_DIR"
sudo chown "$USER":"$USER" "$APP_DIR"
unzip -oq "$ZIP" -d "$APP_DIR"
cd "$APP_DIR"

echo "== 4/6  비밀 설정(.env) 만들기 — 입력한 값은 화면에 안 보이고, 이 서버의 .env 파일에만 저장돼요"
if [ -f .env ]; then
  echo ".env 가 이미 있어요. 그대로 사용합니다 (바꾸려면 nano .env)"
else
  read -rp  "경제교실 아이디: " ECO_USER
  read -rsp "경제교실 비밀번호: " ECO_PASS; echo
  while true; do
    read -rsp "대시보드 접속 암호(8자 이상, 새로 정하세요): " DASH_PASS; echo
    [ "${#DASH_PASS}" -ge 8 ] && break || echo "8자 이상이어야 해요."
  done
  read -rsp "Claude 장기 토큰(sk-ant-oat01-...; 없으면 그냥 Enter): " CLAUDE_TOKEN; echo
  RAND="$(head -c 10 /dev/urandom | od -An -tx1 | tr -d ' \n')"
  PHONE="https://ntfy.sh/autoclass-${RAND}"
  umask 077
  {
    echo "ECONOMY_USERNAME=${ECO_USER}"
    echo "ECONOMY_PASSWORD=${ECO_PASS}"
    echo "DASHBOARD_PASSWORD=${DASH_PASS}"
    echo "CLAUDE_CODE_OAUTH_TOKEN=${CLAUDE_TOKEN}"
    echo "PHONE_URL=${PHONE}"
  } > .env
  chmod 600 .env
  echo
  echo ">>> 폰 알림 주소: ${PHONE}"
  echo ">>> 폰에 ntfy 앱을 설치하고 '${PHONE##*/}' 이름으로 구독하세요."
fi

echo "== 5/6  빌드 · 실행 (처음엔 몇 분 걸려요)"
sudo docker compose up -d --build

echo "== 6/6  확인"
sleep 20
sudo docker compose ps
if sudo docker compose logs --tail 30 autoclass 2>&1 | grep -q "클라우드 모드에는"; then
  echo "대시보드 암호 설정에 문제가 있어요. nano .env 를 확인하세요."
fi
cat <<'MSG'

✅ 설치 끝!
- 이 서버는 외부에 열지 않았어요(안전). 내 컴퓨터에서 아래 명령으로 연결한 뒤 브라우저에서 http://localhost:8080 을 여세요.
    ssh -L 8080:localhost:8080 -i <내_키파일> ubuntu@<서버_공인IP>
  접속하면 아이디는 아무거나, 비밀번호는 방금 정한 '대시보드 접속 암호'를 입력.
- ⚠ 꼭 하세요: 내 PC 프로그램의 설정 → 시스템 → '이 프로그램의 역할'을 '감시만'으로 바꾸기
  (같은 계정을 두 곳이 동시에 자동 거래하면 안 돼요). 서버가 '주 실행'입니다.
- 로그 보기:  cd /opt/autoclass && sudo docker compose logs -f --tail 100
- 업데이트:   새 zip 을 올리고 bash oracle-setup.sh 를 다시 실행 (.env 와 기록은 유지돼요)
MSG
