#!/usr/bin/env bash
# 서버(Oracle VM 등)에서 저장소의 최신 코드를 받아 다시 빌드·실행. 설정(.env)과 기록(/data 볼륨)은 그대로 유지돼요.
# 처음 한 번:  git clone <내 비공개 저장소 주소> /opt/autoclass   (그 안에 .env 를 만들어 두기)
# 업데이트:    bash /opt/autoclass/deploy/update.sh
set -euo pipefail
cd "$(dirname "$0")/.."
git pull --ff-only
sudo docker compose up -d --build
sleep 15
sudo docker compose ps
echo "업데이트 완료: $(git log -1 --format='%h %s')"
